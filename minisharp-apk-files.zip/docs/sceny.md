# Sceny: edytor sceny, komponenty, komunikacja

Karta **Scena** (obok Kod / Graf / Gra) to mały edytor w stylu Unity: obiekty na dwóch ekranach, hierarchia, inspektor
i skrypty (kod albo graf) podpięte do obiektów. Działa w przeglądarce i w aplikacji na Androida. Scena zamienia się w zwykły kod
MiniSharp, więc kompilator, VM i 3DS nic o scenach nie wiedzą: plik sceny skompiluje się wszędzie, gdzie jest `Scene.cs`.

| Plik | Co robi |
|---|---|
| `web/lib/Scene.cs` | runtime w MiniSharp: `GameObject`, `Behaviour`, `Msg`, `Scene`, `SceneDef`, `Scenes`, `Vars` (dodaje się sam z pierwszą sceną) |
| `web/scene.js` | model sceny, generator scena → kod, informacje o klasach dla inspektora (`MSScene`) |
| `web/sceneeditor.js` | edytor: widok, hierarchia, inspektor, wybór klatki sprite'a, cofanie (`MSSceneEditor`) |
| `web/graph.js` | graf jako komponent: `base` (klasa bazowa), węzły sceny i węzły dziedziczone |
| `tests/web/scene.test.js` | generator, klasy, graf z bazą i całość przez prawdziwy kompilator |
| `tests/web/jsdom/scene_web.test.js` | karta Scena na stronie: nowa scena, obiekt, skrypt, graf, zapis, wczytanie |

## Plik sceny

Scena to plik `Nazwa.scene.cs`: wygenerowany kod (klasa `Scene_Nazwa : SceneDef`) i scena jako JSON w ostatniej linii
`// @scene {...}` (jak `// @graph` w plikach z grafem). Na karcie Kod jest tylko do czytania.

- **Zapisz** zapisuje scenę do pliku (zmiany do tego czasu są tylko w edytorze; „Zapisz ●” = niezapisane). ▶ zapisuje sam.
- **Mapa ▾** (nazwa sceny) = wczytaj inną scenę albo **+ Nowa scena**; przy niezapisanych zmianach pyta, czy zapisać.
- **⋯**: Zapisz jako (kopia pod nową nazwą), Wczytaj zapisaną (porzuć zmiany), Pokaż kod sceny, Usuń scenę, siatka, nazwy.
- Zakładka **Scena** w panelu: nazwa (zmienia nazwę pliku), *scena startowa* (od niej zaczyna się gra; tylko jedna), kolory tła
  obu ekranów i **zmienne sceny**.
- Klasa sceny rejestruje się w swoim `static void Main()` (hook: każda klasa może mieć własny), więc runtime zna wszystkie sceny
  projektu bez refleksji.

```csharp
class Scene_Walka : SceneDef {
    static void Main() { Scenes.Register(new Scene_Walka(), false); }
    public Scene_Walka() { name = "Walka"; bgTop = 0x000000; bgBottom = 0x4B692F; }
    public override void Build(Scene s) {
        GameObject o2 = s.Spawn("Bohater", 58.3f, 37.5f);
        o2.tag = "gracz"; o2.layer = 38; o2.image = "glyphs.png"; o2.Frame(0, 0, 8, 8); o2.scale = 1.25f; o2.anchor = 1;
        UnitStack o2c1 = (UnitStack)o2.Add(new UnitStack(), "UnitStack");
        o2c1.type = 0; o2c1.count = 1;
        // odwołania między obiektami: po utworzeniu wszystkich
        ...
    }
}
// @scene {"name":"Walka", ...}
```

## Obiekt i inspektor

Obiekt: nazwa, tag, pozycja `x, y` w pikselach swojego ekranu (górny 400×240 albo dolny, dotykowy 320×240), warstwa
(większa = na wierzchu), aktywny, sprite (obrazek z projektu, klatka `sx sy sw sh` z wyborem na siatce, skala, odbicie,
punkt zaczepienia: środek / stopy / róg) albo kolorowy prostokąt `w × h`, *rysuj w grze* (wyłącz, gdy obiekt rysuje komponent,
a sprite ma być tylko podglądem w edytorze). Obiekty przesuwa się palcem w widoku (także na drugi ekran), 🔍 powiększa.

**Komponenty**: dowolna klasa projektu, która dziedziczy po `Behaviour` (wprost albo przez inną klasę), z kodu albo z grafu.
Inspektor pokazuje jej publiczne pola (`int float bool string char GameObject`, razem z polami klas bazowych, oznaczonymi ↑)
z wartością domyślną z kodu jako podpowiedzią. Wpisana wartość nadpisuje domyślną tylko w tym obiekcie. Pole typu `GameObject`
wybiera inny obiekt sceny (w kodzie `s.Find("Nazwa")` po utworzeniu wszystkich obiektów). „+ Komponent” proponuje też
**Nowy skrypt (kod)** i **Nowy graf**; „Edytuj” otwiera kod klasy albo jej graf.

## Komponent (`Behaviour`)

```csharp
class Ruch : Behaviour {
    public float speed = 1;                       // widać w inspektorze
    public override void Start() { }             // raz, przed pierwszym Update obiektu
    public override void Update() { go.x += speed; }
    public override void Draw() { }              // ekran obiektu jest już wybrany
    public override void OnEvent(Msg m) { }      // wiadomość
    public override void OnTouch(float x, float y) { }   // dotknięto obiekt (dolny ekran)
    public override void OnDestroy() { }         // obiekt usunięty albo zmiana sceny
}
```

Kolejność w klatce: `Scenes.Update` (zmiana sceny, `Start` nowych komponentów, dotyk → `OnTouch`, `Update` obiektów w kolejności
hierarchii, usuwanie zniszczonych), potem `Update` innych klas; `Scenes.Draw` (tło, obiekty według warstwy: sprite i `Draw`),
potem `Draw` innych klas (np. HUD w zwykłym kodzie). `Scenes` ma `[Order(-1000)]`.

## Graf jako komponent i dziedziczenie z kodu

W menu ⋯ grafu: **Klasa bazowa** = `Behaviour` albo dowolna klasa komponentu z projektu (kod albo inny graf). Wtedy:

- klasa grafu to `class SmokGraf : UnitStack`, robi się z niej obiekty (każdy obiekt sceny ma własne zmienne grafu),
- zdarzenia **Start**, **Update**, **Draw**, **Na wiadomość (OnEvent)** i **Kliknięcie obiektu (OnTouch)** to `override`,
  które najpierw wołają wersję z klasy bazowej (`base.Start();`), więc kod bazowy działa dalej, a graf tylko dokłada,
- węzeł **Metoda** o nazwie metody wirtualnej z bazy (`OnDeath`) ją **nadpisuje** (bez wołania bazy),
- pola klasy bazowej są zmiennymi grafu (Pobierz / Ustaw zmienną), a jej publiczne metody i pola są w palecie
  w kategorii „Dziedziczone: Klasa”,
- węzły sceny: Ten obiekt (`go`), `go.x`, `go.y`, `go.name`, ... (pobierz / ustaw), Zniszcz ten obiekt, Wyślij do obiektu,
- zmienne grafu są `public`, więc widać je w inspektorze i każdy obiekt może mieć inne wartości.

Tak każdy obiekt może mieć własny graf, a wspólna logika zostaje w klasie z kodu.

## Komunikacja

| Kto → kto | Jak |
|---|---|
| obiekt → obiekt | `Send(cel, "nazwa", wartość)` w komponencie albo `Scenes.Send(od, do, "nazwa", wartość)`; odbiorca dostaje `OnEvent(Msg m)` od razu (`m.name`, `m.value`, `m.text`, `m.from`, `m.obj`); `Scenes.SendFull` z tekstem i obiektem |
| obiekt → grupa | `Scenes.SendTag(od, "wrog", "nazwa", wartość)` |
| obiekt → wszyscy i gra | `Scenes.Broadcast(od, "nazwa", wartość)`: każdy obiekt sceny i słuchacze `Scenes.Listen("nazwa", m => ...)` w kodzie gry |
| odwołanie | pole `GameObject` ustawione w inspektorze, `Scenes.Find("Nazwa")`, `Scenes.FindTag("tag")`, `go.Comp("Klasa")` |
| stan sceny | zmienne sceny `Scenes.Num/SetNum/Text/SetText` (wartości startowe w edytorze, wracają przy każdym wczytaniu) |
| stan gry | `Vars.Num/SetNum/AddNum/Text/SetText/Has` (przeżywają zmianę sceny: złoto, wynik, kto walczy) |
| zmiana sceny | `Scenes.Load("Walka")` (na początku następnej klatki), `Scenes.Reload()`; korutyny się zatrzymują |

Wszystkie metody `static` z `Scenes` i `Vars` są też węzłami grafu (kategoria „Kod: Scenes” / „Kod: Vars”).

## Ograniczenia (na teraz)

- Generator grafu w C (`src/fgraph.c`, edytor grafów na 3DS) nie zna jeszcze `base`; plik wygenerowany w przeglądarce
  kompiluje się na 3DS normalnie, ale edycja takiego grafu na konsoli dałaby klasę bez bazy.
- Widok sceny pokazuje sprite'y i prostokąty, nie uruchamia `Draw` komponentów (to, co rysuje kod, widać dopiero w grze).
- Brak prefabów, zagnieżdżania obiektów (rodzic/dziecko) i zapisu stanu gry na dysk.
