// Particles.cs - efekty czasteczkowe i czary dla MiniSharp. Dodaj z menu (+ dodaj > Efekty czasteczkowe): wskoczy ten plik
// i arkusz sprite'ow particles.png (6 sprite'ow w 11 kolorach: iskra, kleb, plomien, odlamek lodu, gwiazdka, pierscien).
// Czastki to sprite'y, nie pojedyncze piksele: kazda to jedno Gfx.ImagePartEx ze skala i obrotem.
// Zanikanie czastek robi rampa kolorow (zolty, pomaranczowy, czerwony, dym), kurczenie i krycie (Gfx.Alpha: pole fadeStart).
//
//   // Main:
//   Particles.Init(Gfx.LoadImage("particles.png"));
//   // Update():
//   Particles.Update(Clock.Dt());          // Clock jest w Anim.cs; bez niego: Particles.Update(1f / 60)
//   // Draw():
//   Particles.Draw();                      // po narysowaniu swiata, przed napisami
//   // czary (pozycje w pikselach ekranu):
//   Magic.Fireball(80, 150, 240, 140, () => Magic.Explosion(240, 140));   // pocisk z ogonem, po trafieniu wybuch
//   Magic.IceBurst(240, 140);
//   Magic.Lightning(240, 20, 240, 140);
//   Magic.Heal(80, 150);
//   Emitter aura = Magic.Aura(80, 150, Magic.MagicRamp);   // ciagly efekt; aura.x/y mozna zmieniac co klatke, aura.Stop() konczy
//
// Wlasne efekty: new Emitter(), ustaw pola, Particles.Add(e), e.Burst(20) (wybuch) albo e.rate = 40 (ciagle).
// Koszt: kazda czastka to jedno wywolanie rysowania. Emitter ma limit `max` (domyslnie 64), a calosc lepiej trzymac
// ponizej ok. 300 czastek naraz.
//
// Wlasny arkusz (np. z narzedzia "Glify -> PNG"): Particles.Setup(obraz, CW, CH, COLS, GAP, VARS, gw, gh)
// ze stalymi z okna narzedzia; numery glifow i wariantow podajesz wtedy sam.

// Kazdy efekt ma Update, Draw i Dead (do usuniecia). Particles.Add dodaje, Particles.Update / Draw obsluguje wszystkie.
interface IEffect {
    void Update(float dt);
    void Draw();
    bool Dead();
}

class Particle {
    public float x, y, vx, vy, life, maxLife, rot, spin;
}

// Zarzadca: lista efektow, pula czastek (zeby nie tworzyc ich co klatke) i rysowanie sprite'a z arkusza.
class Particles {
    // glify wbudowanego arkusza particles.png
    public const int Spark = 0;
    public const int Puff = 1;
    public const int Flame = 2;
    public const int Shard = 3;
    public const int Star = 4;
    public const int Ring = 5;

    // warianty koloru wbudowanego arkusza
    public const int FireY = 0;
    public const int FireO = 1;
    public const int FireR = 2;
    public const int SmokeD = 3;
    public const int SmokeL = 4;
    public const int IceW = 5;
    public const int IceC = 6;
    public const int IceB = 7;
    public const int MagicC = 8;
    public const int HealC = 9;
    public const int White = 10;

    public static float scale = 1;          // globalny mnoznik rozmiaru (np. 2, gdy gra jest rysowana w podwojnej skali)
    public static int count = 0;            // ile czastek zyje (do licznika kosztu)

    static int img = -1;
    static int cw = 16;
    static int ch = 16;
    static int cols = 11;
    static int gap = 0;
    static int vars = 11;
    static int[] gw = new int[] { 5, 8, 6, 5, 7, 16 };
    static int[] gh = new int[] { 5, 8, 8, 9, 7, 16 };
    static List<IEffect> effects = new List<IEffect>();
    static List<Particle> pool = new List<Particle>();

    // wbudowany arkusz particles.png
    public static void Init(int image) {
        img = image;
        cw = 16;
        ch = 16;
        cols = 11;
        gap = 0;
        vars = 11;
        gw = new int[] { 5, 8, 6, 5, 7, 16 };
        gh = new int[] { 5, 8, 8, 9, 7, 16 };
    }

    // wlasny arkusz: stale z narzedzia "Glify -> PNG"
    public static void Setup(int image, int cellW, int cellH, int columns, int gapPx, int variants, int[] glyphW, int[] glyphH) {
        img = image;
        cw = cellW;
        ch = cellH;
        cols = columns;
        gap = gapPx;
        vars = variants;
        gw = glyphW;
        gh = glyphH;
    }

    public static void Add(IEffect e) { effects.Add(e); }

    public static void Clear() {
        effects.Clear();
        count = 0;
    }

    public static int Effects() { return effects.Count; }

    public static void Update(float dt) {
        if (dt > 0.1f) dt = 0.1f;
        count = 0;
        for (int i = effects.Count - 1; i >= 0; i--) {
            IEffect e = effects[i];
            e.Update(dt);
            if (e.Dead()) effects.RemoveAt(i);
        }
    }

    public static void Draw() {
        for (int i = 0; i < effects.Count; i++) effects[i].Draw();
    }

    public static Particle Take() {
        if (pool.Count > 0) {
            Particle p = pool[pool.Count - 1];
            pool.RemoveAt(pool.Count - 1);
            return p;
        }
        return new Particle();
    }

    public static void Release(Particle p) {
        if (pool.Count < 256) pool.Add(p);
    }

    // sprite `glyph` w kolorze `variant` ze srodkiem w (x, y), skala s i obrotem rot (stopnie)
    public static void DrawSprite(int glyph, int variant, float x, float y, float s, float rot) {
        if (img < 0 || s <= 0) return;
        int n = glyph * vars + variant;
        int sx = (n % cols) * (cw + gap);
        int sy = (n / cols) * (ch + gap);
        float k = s * scale;
        float w = gw[glyph] * k;
        float h = gh[glyph] * k;
        Gfx.ImagePartEx(img, x - w / 2, y - h / 2, sx, sy, gw[glyph], gh[glyph], k, k, rot);
    }
}

// Zrodlo czastek. Ustaw pola, dodaj przez Particles.Add, potem Burst(n) (naraz) i/albo rate (ciagle).
class Emitter : IEffect {
    public float x = 0;
    public float y = 0;
    public float radius = 0;                // czastki rodza sie losowo w kole o tym promieniu wokol (x, y)
    public int glyph = 1;                   // Particles.Puff itd.
    public int[] ramp = new int[] { 0 };    // kolory (warianty) po kolei w ciagu zycia czastki: np. { FireY, FireO, FireR, SmokeD }
    public float rate = 0;                  // czastek na sekunde (0 = tylko Burst)
    public float duration = 0;              // jak dlugo emituje ciagle (0 = bez konca, dopoki rate > 0)
    public float life0 = 0.4f;              // czas zycia czastki: od ... do ... sekund
    public float life1 = 0.8f;
    public float speed0 = 20;               // predkosc poczatkowa: od ... do ... px/s
    public float speed1 = 60;
    public float angle = -90;               // kierunek w stopniach: 0 w prawo, -90 w gore, 90 w dol (y rosnie w dol)
    public float spread = 180;              // polowa rozrzutu kata: 180 = we wszystkie strony, 20 = waski stozek
    public float gx = 0;                    // przyspieszenie (px/s^2): gy > 0 opada, gy < 0 unosi sie jak dym
    public float gy = 0;
    public float drag = 0;                  // tlumienie predkosci, 0..5
    public float size0 = 1;                 // skala na starcie i na koncu zycia (0 = znika)
    public float size1 = 0;
    public float rotMin = 0;                // poczatkowy obrot losowo od ... do ... stopni
    public float rotMax = 0;
    public float spin = 0;                  // obrot w stopniach na sekunde (losowy znak)
    public int max = 64;                    // ile czastek naraz co najwyzej
    public float fadeStart = 1;             // od jakiego momentu zycia (0..1) czastka robi sie przezroczysta; 1 = nigdy, 0.5 = w drugiej polowie

    float time = 0;
    float acc = 0;
    List<Particle> ps = new List<Particle>();

    public int Count() { return ps.Count; }

    // i-ta zywa czastka (do wlasnego rysowania albo testow)
    public Particle At(int i) { return ps[i]; }

    // konczy emisje ciagla; czastki, ktore juz leca, dogasaja same
    public void Stop() { rate = 0; }

    bool Emitting() { return rate > 0 && (duration <= 0 || time <= duration); }

    public bool Dead() { return !Emitting() && ps.Count == 0; }

    public void Burst(int n) {
        for (int i = 0; i < n; i++) Spawn();
    }

    void Spawn() {
        if (ps.Count >= max) return;
        Particle p = Particles.Take();
        float a = (angle + (Random.Float() * 2 - 1) * spread) * Mathf.Deg2Rad;
        float s = speed0 + (speed1 - speed0) * Random.Float();
        float px = x;
        float py = y;
        if (radius > 0) {
            float ra = Random.Float() * 2 * Mathf.PI;
            float rr = Mathf.Sqrt(Random.Float()) * radius;
            px += Mathf.Cos(ra) * rr;
            py += Mathf.Sin(ra) * rr;
        }
        p.x = px;
        p.y = py;
        p.vx = Mathf.Cos(a) * s;
        p.vy = Mathf.Sin(a) * s;
        p.life = 0;
        p.maxLife = life0 + (life1 - life0) * Random.Float();
        p.rot = rotMin + (rotMax - rotMin) * Random.Float();
        p.spin = spin * (Random.Float() < 0.5f ? -1 : 1);
        ps.Add(p);
    }

    public void Update(float dt) {
        time += dt;
        if (Emitting()) {
            acc += rate * dt;
            while (acc >= 1) {
                acc -= 1;
                Spawn();
            }
        }
        for (int i = ps.Count - 1; i >= 0; i--) {
            Particle p = ps[i];
            p.life += dt;
            if (p.life >= p.maxLife) {
                Particles.Release(p);
                int last = ps.Count - 1;
                ps[i] = ps[last];
                ps.RemoveAt(last);
                continue;
            }
            p.vx += gx * dt;
            p.vy += gy * dt;
            if (drag > 0) {
                float k = 1 - drag * dt;
                if (k < 0) k = 0;
                p.vx *= k;
                p.vy *= k;
            }
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.rot += p.spin * dt;
        }
        Particles.count += ps.Count;
    }

    // numer koloru z rampy dla czastki w danym momencie zycia
    public int VariantAt(float f) {
        int i = (int)(f * ramp.Length);
        if (i >= ramp.Length) i = ramp.Length - 1;
        if (i < 0) i = 0;
        return ramp[i];
    }

    // krycie czastki w momencie zycia f (0..1)
    public float AlphaAt(float f) {
        if (fadeStart >= 1 || f <= fadeStart) return 1;
        float a = (1 - f) / (1 - fadeStart);
        return a < 0 ? 0 : a;
    }

    public void Draw() {
        float cur = 1;
        for (int i = 0; i < ps.Count; i++) {
            Particle p = ps[i];
            float f = p.life / p.maxLife;
            float s = size0 + (size1 - size0) * f;
            if (s <= 0.05f) continue;
            float a = AlphaAt(f);
            if (a != cur) { Gfx.Alpha(a); cur = a; }
            Particles.DrawSprite(glyph, VariantAt(f), p.x, p.y, s, p.rot);
        }
        if (cur != 1) Gfx.Alpha(1);
    }
}

// Pocisk: leci z (x1, y1) do (x2, y2) lukiem, zostawia ogon (trail) i po dotarciu wola onHit.
class Shot : IEffect {
    public float x1, y1, x2, y2;
    public float duration = 0.6f;
    public float arc = 20;                  // wygiecie toru w gore (px)
    public float curve = 1.3f;              // 1 = rowno, > 1 przyspiesza ku koncowi
    public int glyph = 1;                   // sprite glowy pocisku
    public int variant = 0;
    public float size = 1.5f;
    public float spin = 0;                  // obrot glowy (stopnie na sekunde)
    public Emitter trail;                   // ogon: emituje w miejscu pocisku
    public Action onHit;                    // po dotarciu do celu
    public float x, y;
    public float progress = 0;              // 0..1
    float rot = 0;
    bool hit = false;

    public bool Hit() { return hit; }

    public void Update(float dt) {
        if (!hit) {
            progress += dt / duration;
            float t = progress > 1 ? 1 : progress;
            float k = Mathf.Pow(t, curve);
            x = x1 + (x2 - x1) * k;
            y = y1 + (y2 - y1) * k - Mathf.Sin(k * Mathf.PI) * arc;
            rot += spin * dt;
            if (trail != null) {
                trail.x = x;
                trail.y = y;
            }
            if (progress >= 1) {
                hit = true;
                if (trail != null) trail.Stop();
                onHit?.Invoke();
            }
        }
        if (trail != null) trail.Update(dt);
    }

    public void Draw() {
        if (trail != null) trail.Draw();
        if (!hit) Particles.DrawSprite(glyph, variant, x, y, size, rot);
    }

    public bool Dead() { return hit && (trail == null || trail.Dead()); }
}

// Piorun: postrzepiona linia z (x1, y1) do (x2, y2), co chwile losowana od nowa (migotanie). Rysowany liniami.
class Bolt : IEffect {
    public float x1, y1, x2, y2;
    public float duration = 0.35f;
    public float jag = 9;                   // jak mocno linia sie rzuca na boki (px)
    public int segs = 8;                    // ile odcinkow
    public int coreColor = 0xFFFFFF;
    public int glowColor = 0x73EFF7;
    public float flicker = 0.04f;           // co ile sekund losuje nowy ksztalt
    public int flareVariant = 10;           // kolor gwiazdki na koncu
    float time = 0;
    float next = 0;
    public float[] px;                      // punkty linii (px[0], py[0] to poczatek, ostatni to koniec)
    public float[] py;

    public static Bolt Make(float x1, float y1, float x2, float y2) {
        Bolt b = new Bolt();
        b.x1 = x1;
        b.y1 = y1;
        b.x2 = x2;
        b.y2 = y2;
        b.Reshape();
        return b;
    }

    void Reshape() {
        px = new float[segs + 1];
        py = new float[segs + 1];
        float dx = x2 - x1;
        float dy = y2 - y1;
        float len = Mathf.Sqrt(dx * dx + dy * dy);
        if (len < 1) len = 1;
        float nx = -dy / len;
        float ny = dx / len;
        for (int i = 0; i <= segs; i++) {
            float t = (float)i / segs;
            float off = (i == 0 || i == segs) ? 0 : (Random.Float() * 2 - 1) * jag;
            px[i] = x1 + dx * t + nx * off;
            py[i] = y1 + dy * t + ny * off;
        }
    }

    public void Update(float dt) {
        time += dt;
        next -= dt;
        if (next <= 0 && time < duration) {
            Reshape();
            next = flicker;
        }
    }

    public void Draw() {
        if (time >= duration || px == null) return;
        float f = time / duration;
        if (f > 0.6f) Gfx.Alpha((1 - f) / 0.4f);       // pod koniec piorun gasnie
        for (int i = 0; i < segs; i++) {
            Gfx.Line(px[i] - 1, py[i], px[i + 1] - 1, py[i + 1], glowColor);
            Gfx.Line(px[i] + 1, py[i], px[i + 1] + 1, py[i + 1], glowColor);
            Gfx.Line(px[i], py[i], px[i + 1], py[i + 1], coreColor);
        }
        float s = 1.5f + 0.5f * (((int)(time * 40)) % 2);
        Particles.DrawSprite(Particles.Star, flareVariant, x2, y2, s, 0);
        Particles.DrawSprite(Particles.Star, flareVariant, x1, y1, s * 0.7f, 0);
        if (f > 0.6f) Gfx.Alpha(1);
    }

    public bool Dead() { return time >= duration; }
}

// Gotowe czary. Kazda funkcja dodaje efekt do Particles i zwraca go (np. do zmiany pola albo Stop()).
class Magic {
    public static int[] FireRamp = new int[] { 0, 1, 1, 2, 3 };       // zolty, pomaranczowy, czerwony, dym
    public static int[] IceRamp = new int[] { 5, 6, 7 };
    public static int[] MagicRamp = new int[] { 8, 8, 10 };
    public static int[] HealRamp = new int[] { 9, 9, 10 };
    public static int[] SmokeRamp = new int[] { 3, 4 };

    // pocisk ognia z ogonem; onHit mozna podac jako lambde albo null
    public static Shot Fireball(float x1, float y1, float x2, float y2, Action onHit) {
        Shot s = new Shot();
        s.x1 = x1;
        s.y1 = y1;
        s.x2 = x2;
        s.y2 = y2;
        s.x = x1;
        s.y = y1;
        s.glyph = Particles.Puff;
        s.variant = Particles.FireY;
        s.size = 2.1f;
        s.arc = 24;
        s.curve = 1.2f;
        s.duration = 0.6f;
        s.onHit = onHit;
        Emitter t = new Emitter();
        t.x = x1;
        t.y = y1;
        t.glyph = Particles.Flame;
        t.ramp = FireRamp;
        t.rate = 90;
        t.radius = 3;
        t.life0 = 0.25f;
        t.life1 = 0.5f;
        t.speed0 = 5;
        t.speed1 = 25;
        t.angle = -90;
        t.spread = 80;
        t.gy = -30;
        t.size0 = 1.7f;
        t.size1 = 0.3f;
        t.max = 48;
        s.trail = t;
        Particles.Add(s);
        return s;
    }

    // wybuch: dym (na spodzie), plomienie rozlatujace sie na boki, iskry, blysk na wierzchu i fala uderzeniowa.
    // Kolejnosc dodawania to kolejnosc rysowania: pozniejsze zakrywaja wczesniejsze.
    public static void Explosion(float x, float y) {
        Emitter smoke = new Emitter();
        smoke.x = x;
        smoke.y = y;
        smoke.radius = 8;
        smoke.glyph = Particles.Puff;
        smoke.ramp = SmokeRamp;
        smoke.life0 = 0.8f;
        smoke.life1 = 1.4f;
        smoke.speed0 = 8;
        smoke.speed1 = 30;
        smoke.angle = -90;
        smoke.spread = 70;
        smoke.gy = -25;
        smoke.size0 = 1.4f;
        smoke.size1 = 3f;
        smoke.fadeStart = 0.3f;
        Particles.Add(smoke);
        smoke.Burst(7);

        Emitter fire = new Emitter();
        fire.x = x;
        fire.y = y;
        fire.glyph = Particles.Puff;
        fire.ramp = FireRamp;
        fire.life0 = 0.35f;
        fire.life1 = 0.7f;
        fire.speed0 = 30;
        fire.speed1 = 120;
        fire.drag = 2.5f;
        fire.gy = -20;
        fire.size0 = 2.6f;
        fire.size1 = 0.4f;
        fire.fadeStart = 0.7f;
        Particles.Add(fire);
        fire.Burst(22);

        Emitter sparks = new Emitter();
        sparks.x = x;
        sparks.y = y;
        sparks.glyph = Particles.Spark;
        sparks.ramp = new int[] { 10, 0, 1 };
        sparks.life0 = 0.4f;
        sparks.life1 = 0.9f;
        sparks.speed0 = 60;
        sparks.speed1 = 180;
        sparks.gy = 160;
        sparks.drag = 0.8f;
        sparks.size0 = 1.6f;
        sparks.size1 = 0.4f;
        sparks.fadeStart = 0.6f;
        Particles.Add(sparks);
        sparks.Burst(16);

        Emitter flash = new Emitter();
        flash.x = x;
        flash.y = y;
        flash.glyph = Particles.Puff;
        flash.ramp = new int[] { 10, 0 };
        flash.life0 = 0.14f;
        flash.life1 = 0.2f;
        flash.speed0 = 0;
        flash.speed1 = 0;
        flash.size0 = 4.2f;
        flash.size1 = 2f;
        Particles.Add(flash);
        flash.Burst(1);

        Ring(x, y, Particles.FireO, 0.35f, 5f);
    }

    // fala uderzeniowa: pierscien rosnacy od 0 do `grow` razy swojego rozmiaru
    public static Emitter Ring(float x, float y, int variant, float life, float grow) {
        Emitter r = new Emitter();
        r.x = x;
        r.y = y;
        r.glyph = Particles.Ring;
        r.ramp = new int[] { variant };
        r.life0 = life;
        r.life1 = life;
        r.speed0 = 0;
        r.speed1 = 0;
        r.size0 = 0.3f;
        r.size1 = grow;
        r.fadeStart = 0.25f;
        Particles.Add(r);
        r.Burst(1);
        return r;
    }

    // lod: odlamki rozbiegaja sie i opadaja, lsniace gwiazdki, pierscien
    public static void IceBurst(float x, float y) {
        Emitter shards = new Emitter();
        shards.x = x;
        shards.y = y;
        shards.glyph = Particles.Shard;
        shards.ramp = IceRamp;
        shards.life0 = 0.5f;
        shards.life1 = 0.9f;
        shards.speed0 = 50;
        shards.speed1 = 120;
        shards.gy = 220;
        shards.drag = 0.6f;
        shards.size0 = 1.9f;
        shards.size1 = 0.6f;
        shards.fadeStart = 0.7f;
        shards.rotMin = 0;
        shards.rotMax = 360;
        shards.spin = 360;
        Particles.Add(shards);
        shards.Burst(14);

        Emitter glints = new Emitter();
        glints.x = x;
        glints.y = y;
        glints.radius = 14;
        glints.glyph = Particles.Star;
        glints.ramp = new int[] { 10, 5, 6 };
        glints.life0 = 0.4f;
        glints.life1 = 0.9f;
        glints.speed0 = 0;
        glints.speed1 = 12;
        glints.size0 = 1.9f;
        glints.size1 = 0;
        glints.fadeStart = 0.4f;
        glints.rate = 40;
        glints.duration = 0.35f;
        Particles.Add(glints);

        Ring(x, y, Particles.IceC, 0.3f, 4f);
    }

    // piorun z (x1, y1) do (x2, y2) z iskrami przy celu
    public static Bolt Lightning(float x1, float y1, float x2, float y2) {
        Bolt b = Bolt.Make(x1, y1, x2, y2);
        Particles.Add(b);
        Emitter sp = new Emitter();
        sp.x = x2;
        sp.y = y2;
        sp.glyph = Particles.Spark;
        sp.ramp = new int[] { 10, 0 };
        sp.life0 = 0.2f;
        sp.life1 = 0.5f;
        sp.speed0 = 40;
        sp.speed1 = 120;
        sp.gy = 120;
        sp.size0 = 1.6f;
        sp.size1 = 0.4f;
        sp.rate = 70;
        sp.duration = 0.3f;
        Particles.Add(sp);
        return b;
    }

    // leczenie: zielone gwiazdki unosza sie w gore, pierscien
    public static void Heal(float x, float y) {
        Emitter e = new Emitter();
        e.x = x;
        e.y = y + 6;
        e.radius = 12;
        e.glyph = Particles.Star;
        e.ramp = HealRamp;
        e.life0 = 0.7f;
        e.life1 = 1.2f;
        e.speed0 = 20;
        e.speed1 = 45;
        e.angle = -90;
        e.spread = 15;
        e.size0 = 1.8f;
        e.size1 = 0.3f;
        e.fadeStart = 0.5f;
        e.rate = 28;
        e.duration = 0.8f;
        Particles.Add(e);
        Ring(x, y + 8, Particles.HealC, 0.5f, 3f);
    }

    // ciagly efekt przy postaci (aura, ogien, dym); zwraca emiter: zmieniaj x i y, Stop() konczy
    public static Emitter Aura(float x, float y, int[] ramp) {
        Emitter e = new Emitter();
        e.x = x;
        e.y = y;
        e.radius = 10;
        e.glyph = Particles.Puff;
        e.ramp = ramp;
        e.life0 = 0.5f;
        e.life1 = 1.0f;
        e.speed0 = 6;
        e.speed1 = 24;
        e.angle = -90;
        e.spread = 35;
        e.gy = -20;
        e.size0 = 1.3f;
        e.size1 = 0;
        e.fadeStart = 0.5f;
        e.rate = 22;
        Particles.Add(e);
        return e;
    }
}
