// Scene.cs - sceny, obiekty i komponenty w stylu Unity dla MiniSharp. Edytor sceny (karta "Scena") dodaje ten plik sam.
//
//   GameObject  obiekt sceny: nazwa, tag, pozycja na ekranie (x, y, screen), warstwa, sprite i lista komponentow.
//   Behaviour   komponent (skrypt) podpiety do obiektu: Start, Update, Draw, OnEvent (wiadomosci), OnTouch (dotyk).
//               Skrypt z kodu: class Ruch : Behaviour { public override void Update() { go.x += 1; } }
//               Skrypt z grafu: graf z klasa bazowa Behaviour (albo dowolna klasa kodu, ktora po niej dziedziczy).
//   Msg         wiadomosc: name, value, text, from (nadawca), obj (dowolny obiekt).
//   Scenes      wczytywanie scen (Load), szukanie obiektow (Find, FindTag), wiadomosci (Send, SendTag, Broadcast, Listen),
//               zmienne sceny (Num, SetNum, Text, SetText: znikaja przy zmianie sceny).
//   Vars        zmienne gry (Num, SetNum, AddNum, Text, SetText): przezywaja zmiane sceny.
//   SceneDef    scena zrobiona w edytorze (plik Nazwa.scene.cs, kod powstaje sam z JSON-a w ostatniej linii).
//
// Kolejnosc w klatce: Scenes.Update (nowa scena, jesli Load; Start nowych komponentow; dotyk -> OnTouch; Update
// wszystkich komponentow; usuwanie zniszczonych), potem Update innych klas; Scenes.Draw (tlo, obiekty wg warstwy:
// sprite i Draw komponentow), potem Draw innych klas (np. HUD na wierzchu). Scenes ma [Order(-1000)], wiec idzie pierwsze.
// Zmiana sceny zatrzymuje korutyny (jak zniszczenie obiektow w Unity).

// Wiadomosc miedzy obiektami (albo od gry). Dostaje ja OnEvent kazdego komponentu odbiorcy.
class Msg {
    public string name = "";
    public float value = 0;
    public string text = "";
    public GameObject from = null;   // nadawca (null: gra albo kod spoza sceny)
    public GameObject to = null;     // odbiorca (null przy Broadcast do sluchaczy)
    public GameObject obj = null;    // dodatkowy obiekt, np. cel ataku
}

// Komponent obiektu. Nadpisz tylko to, czego potrzebujesz.
abstract class Behaviour {
    public GameObject go = null;     // obiekt, do ktorego komponent jest podpiety
    public bool enabled = true;      // false: bez Update, Draw, OnEvent i OnTouch
    public string kind = "";         // nazwa klasy (ustawia edytor sceny i GameObject.Add)
    public bool started = false;

    public virtual void Start() { }
    public virtual void Update() { }
    public virtual void Draw() { }
    public virtual void OnEvent(Msg m) { }
    // dotyk na obszarze obiektu (dolny ekran); x, y wzgledem pozycji obiektu
    public virtual void OnTouch(float x, float y) { }
    public virtual void OnDestroy() { }

    // skroty dla kodu komponentu
    public void Send(GameObject to, string name, float value) { Scenes.Send(go, to, name, value); }
    public void Broadcast(string name, float value) { Scenes.Broadcast(go, name, value); }
    public GameObject Find(string name) { return Scenes.Find(name); }
}

class GameObject {
    public string name = "";
    public string tag = "";
    public float x = 0;
    public float y = 0;
    public int screen = 1;           // 0 gorny, 1 dolny (Screen.Top / Screen.Bottom)
    public int layer = 0;            // wieksza warstwa rysuje sie pozniej (na wierzchu)
    public bool active = true;       // false: obiekt spi (bez Update, Draw i wiadomosci)
    public bool show = true;         // rysuj sprite (komponenty i tak dostaja Draw)
    public bool dead = false;

    // sprite: wycinek obrazka (sw = 0: caly obrazek), skala, odbicie, punkt zaczepienia
    public string image = "";
    public int img = -1;
    public int sx = 0;
    public int sy = 0;
    public int sw = 0;
    public int sh = 0;
    public float scale = 1;
    public bool flip = false;
    public int anchor = 0;           // 0 srodek, 1 srodek dolu (stopy), 2 lewy gorny rog
    public int color = -1;           // bez obrazka: prostokat w tym kolorze (-1 nic)
    public float w = 16;             // rozmiar obszaru bez obrazka (dotyk, prostokat)
    public float h = 16;

    public List<Behaviour> comps = new List<Behaviour>();

    public GameObject(string name, float x, float y) {
        this.name = name;
        this.x = x;
        this.y = y;
    }

    // podpina komponent (kind = nazwa klasy, do szukania przez Comp)
    public Behaviour Add(Behaviour b, string kind) {
        b.go = this;
        b.kind = kind;
        comps.Add(b);
        return b;
    }

    // pierwszy komponent danej klasy albo null: var u = (UnitStack)go.Comp("UnitStack");
    public Behaviour Comp(string kind) {
        foreach (Behaviour b in comps) if (b.kind == kind) return b;
        return null;
    }

    public void Frame(int sx, int sy, int sw, int sh) {
        this.sx = sx;
        this.sy = sy;
        this.sw = sw;
        this.sh = sh;
    }

    // szerokosc i wysokosc na ekranie
    public float Width() {
        if (img >= 0) return (sw > 0 ? sw : Gfx.ImageWidth(img)) * scale;
        return w;
    }
    public float Height() {
        if (img >= 0) return (sh > 0 ? sh : Gfx.ImageHeight(img)) * scale;
        return h;
    }
    public float Left() {
        if (anchor == 2) return x;
        return x - Width() / 2;
    }
    public float Top() {
        if (anchor == 2) return y;
        if (anchor == 1) return y - Height();
        return y - Height() / 2;
    }
    public bool Contains(float px, float py) {
        float l = Left();
        float t = Top();
        return px >= l && px < l + Width() && py >= t && py < t + Height();
    }

    public void Send(string name, float value) { Scenes.Send(null, this, name, value); }
    public void Destroy() { dead = true; }

    public void DrawSprite() {
        if (!show) return;
        if (img < 0 && image != "") img = Scenes.Image(image);
        if (img >= 0) {
            int w0 = sw > 0 ? sw : Gfx.ImageWidth(img);
            int h0 = sh > 0 ? sh : Gfx.ImageHeight(img);
            Gfx.ImagePartEx(img, Left(), Top(), sx, sy, w0, h0, flip ? -scale : scale, scale, 0);
        } else if (color >= 0) {
            Gfx.Rect(Left(), Top(), w, h, color);
        }
    }
}

// Scena w trakcie gry: obiekty i zmienne sceny.
class Scene {
    public string name = "";
    public int bgTop = 0;
    public int bgBottom = 0;
    public List<GameObject> objects = new List<GameObject>();
    public Dictionary<string, float> nums = new Dictionary<string, float>();
    public Dictionary<string, string> texts = new Dictionary<string, string>();

    // nowy obiekt w tej scenie
    public GameObject Spawn(string name, float x, float y) {
        GameObject o = new GameObject(name, x, y);
        objects.Add(o);
        return o;
    }

    public GameObject Find(string name) {
        foreach (GameObject o in objects) if (!o.dead && o.name == name) return o;
        return null;
    }
}

// Scena z edytora: kod Build powstaje z pliku sceny.
abstract class SceneDef {
    public string name = "";
    public int bgTop = 0;
    public int bgBottom = 0;
    public abstract void Build(Scene s);
}

// Zmienne gry: przezywaja zmiane sceny (zloto, wynik, ktora armia zaatakowala).
class Vars {
    // @node hide
    static Dictionary<string, float> nums = new Dictionary<string, float>();
    // @node hide
    static Dictionary<string, string> texts = new Dictionary<string, string>();

    // liczba zmiennej gry (0, gdy jej nie ma)
    public static float Num(string name) {
        float v;
        if (nums.TryGetValue(name, out v)) return v;
        return 0;
    }
    public static void SetNum(string name, float value) { nums[name] = value; }
    public static void AddNum(string name, float value) { nums[name] = Num(name) + value; }
    // tekst zmiennej gry ("" gdy jej nie ma)
    public static string Text(string name) {
        string v;
        if (texts.TryGetValue(name, out v)) return v;
        return "";
    }
    public static void SetText(string name, string value) { texts[name] = value; }
    public static bool Has(string name) { return nums.ContainsKey(name) || texts.ContainsKey(name); }
    public static void Clear() { nums.Clear(); texts.Clear(); }
}

[Order(-1000)]
class Scenes {
    // @node hide
    public static Scene current = null;
    // @node hide
    static Dictionary<string, SceneDef> defs = new Dictionary<string, SceneDef>();
    // @node hide
    static string first = "";
    // @node hide
    static string next = "";
    // @node hide
    static Dictionary<string, int> images = new Dictionary<string, int>();
    // @node hide
    static Dictionary<string, List<Action<Msg>>> listeners = new Dictionary<string, List<Action<Msg>>>();
    // @node hide
    static List<GameObject> drawList = new List<GameObject>();
    // @node hide
    static bool touchPrev = false;

    // @node hide
    public static void Register(SceneDef d, bool isStart) {
        defs[d.name] = d;
        if (isStart || first == "") first = d.name;
    }

    // Zmienia scene na koncu tej klatki (obiekty starej znikaja, zmienne gry zostaja).
    public static void Load(string name) {
        if (!defs.ContainsKey(name)) { Console.WriteLine("Scenes.Load: nie ma sceny " + name); return; }
        next = name;
    }

    // Wczytuje te sama scene od nowa.
    public static void Reload() { if (current != null) next = current.name; }

    // nazwa biezacej sceny
    public static string Name() { return current != null ? current.name : ""; }

    // obiekt sceny o tej nazwie albo null
    public static GameObject Find(string name) {
        if (current == null) return null;
        return current.Find(name);
    }

    // wszystkie zywe obiekty z tym tagiem
    public static List<GameObject> FindTag(string tag) {
        List<GameObject> r = new List<GameObject>();
        if (current == null) return r;
        foreach (GameObject o in current.objects) if (!o.dead && o.tag == tag) r.Add(o);
        return r;
    }

    // nowy obiekt w biezacej scenie (komponenty dodaj przez o.Add(...))
    public static GameObject Spawn(string name, float x, float y) {
        if (current == null) return new GameObject(name, x, y);
        return current.Spawn(name, x, y);
    }

    // obrazek po nazwie pliku, wczytany raz
    public static int Image(string file) {
        int v;
        if (images.TryGetValue(file, out v)) return v;
        v = Gfx.LoadImage(file);
        images[file] = v;
        return v;
    }

    // ---------------------------------------------------------------- wiadomosci

    // Wysyla wiadomosc do obiektu `to`: od razu dostaje ja OnEvent kazdego jego komponentu.
    public static void Send(GameObject from, GameObject to, string name, float value) {
        Msg m = new Msg();
        m.name = name;
        m.value = value;
        m.from = from;
        m.to = to;
        Deliver(m);
    }

    // Wiadomosc z tekstem i dodatkowym obiektem.
    public static void SendFull(GameObject from, GameObject to, string name, float value, string text, GameObject obj) {
        Msg m = new Msg();
        m.name = name;
        m.value = value;
        m.text = text;
        m.from = from;
        m.to = to;
        m.obj = obj;
        Deliver(m);
    }

    // @node hide
    public static void Deliver(Msg m) {
        GameObject to = m.to;
        if (to == null || to.dead || !to.active) return;
        for (int i = 0; i < to.comps.Count; i++) {
            Behaviour b = to.comps[i];
            if (b.enabled) b.OnEvent(m);
        }
    }

    // Do wszystkich obiektow z tagiem.
    public static void SendTag(GameObject from, string tag, string name, float value) {
        foreach (GameObject o in FindTag(tag)) Send(from, o, name, value);
    }

    // Do wszystkich obiektow sceny i do sluchaczy z Listen (kod gry spoza sceny).
    public static void Broadcast(GameObject from, string name, float value) {
        Msg m = new Msg();
        m.name = name;
        m.value = value;
        m.from = from;
        if (current != null) {
            List<GameObject> all = new List<GameObject>(current.objects);
            foreach (GameObject o in all) {
                m.to = o;
                Deliver(m);
            }
        }
        m.to = null;
        List<Action<Msg>> ls;
        if (listeners.TryGetValue(name, out ls)) {
            List<Action<Msg>> copy = new List<Action<Msg>>(ls);
            foreach (Action<Msg> f in copy) f(m);
        }
    }

    // @node hide
    // Kod gry slucha wiadomosci z Broadcast: Scenes.Listen("wygrana", m => { ... });
    public static void Listen(string name, Action<Msg> fn) {
        if (!listeners.ContainsKey(name)) listeners[name] = new List<Action<Msg>>();
        listeners[name].Add(fn);
    }

    // ---------------------------------------------------------------- zmienne sceny (znikaja przy zmianie sceny)

    // liczba zmiennej sceny (0, gdy jej nie ma)
    public static float Num(string name) {
        float v;
        if (current != null && current.nums.TryGetValue(name, out v)) return v;
        return 0;
    }
    public static void SetNum(string name, float value) { if (current != null) current.nums[name] = value; }
    public static string Text(string name) {
        string v;
        if (current != null && current.texts.TryGetValue(name, out v)) return v;
        return "";
    }
    public static void SetText(string name, string value) { if (current != null) current.texts[name] = value; }

    // ---------------------------------------------------------------- petla

    // @node hide
    static void Open(string name) {
        if (current != null) {
            foreach (GameObject o in current.objects) {
                foreach (Behaviour b in o.comps) b.OnDestroy();
            }
        }
        StopAllCoroutines();
        SceneDef d = defs[name];
        Scene s = new Scene();
        s.name = d.name;
        s.bgTop = d.bgTop;
        s.bgBottom = d.bgBottom;
        current = s;
        d.Build(s);
    }

    // @node hide
    static void StartNew() {
        for (int i = 0; i < current.objects.Count; i++) {
            GameObject o = current.objects[i];
            if (o.dead || !o.active) continue;
            for (int j = 0; j < o.comps.Count; j++) {
                Behaviour b = o.comps[j];
                if (!b.started && b.enabled) {
                    b.started = true;
                    b.Start();
                }
            }
        }
    }

    // @node hide
    static void Touch() {
        bool t = Input.Touching();
        bool pressed = t && !touchPrev;
        touchPrev = t;
        if (!pressed) return;
        float px = Input.TouchX();
        float py = Input.TouchY();
        GameObject best = null;
        foreach (GameObject o in current.objects) {
            if (o.dead || !o.active || o.screen != 1 || o.comps.Count == 0) continue;
            if (o.img < 0 && o.image != "") o.img = Image(o.image);
            if (!o.Contains(px, py)) continue;
            if (best == null || o.layer >= best.layer) best = o;
        }
        if (best == null) return;
        foreach (Behaviour b in best.comps) if (b.enabled) b.OnTouch(px - best.x, py - best.y);
    }

    static void Update() {
        if (next != "") {
            string n = next;
            next = "";
            Open(n);
        } else if (current == null && first != "") {
            Open(first);
        }
        if (current == null) return;
        StartNew();
        Touch();
        for (int i = 0; i < current.objects.Count; i++) {
            GameObject o = current.objects[i];
            if (o.dead || !o.active) continue;
            for (int j = 0; j < o.comps.Count; j++) {
                Behaviour b = o.comps[j];
                if (!b.enabled) continue;
                if (!b.started) { b.started = true; b.Start(); }
                b.Update();
            }
        }
        for (int i = current.objects.Count - 1; i >= 0; i--) {
            GameObject o = current.objects[i];
            if (!o.dead) continue;
            foreach (Behaviour b in o.comps) b.OnDestroy();
            current.objects.RemoveAt(i);
        }
    }

    static void Draw() {
        if (current == null) return;
        if (current.bgTop >= 0) { Gfx.Screen(Screen.Top); Gfx.Clear(current.bgTop); }
        if (current.bgBottom >= 0) { Gfx.Screen(Screen.Bottom); Gfx.Clear(current.bgBottom); }
        drawList.Clear();
        foreach (GameObject o in current.objects) if (!o.dead && o.active) drawList.Add(o);
        drawList.Sort((a, b) => a.layer - b.layer);      // stabilne: rowne warstwy w kolejnosci sceny
        foreach (GameObject o in drawList) {
            Gfx.Screen(o.screen);
            o.DrawSprite();
            for (int j = 0; j < o.comps.Count; j++) {
                Behaviour b = o.comps[j];
                if (b.enabled && b.started) {
                    Gfx.Screen(o.screen);
                    b.Draw();
                }
            }
        }
        Gfx.Screen(Screen.Top);
    }
}
