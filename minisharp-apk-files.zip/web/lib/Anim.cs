// Anim.cs - biblioteka animacji sprite'ow dla MiniSharp. Wrzuc ten plik do projektu (+ dodaj > Biblioteka animacji):
// wszystkie pliki .cs projektu kompiluja sie razem, wiec klasy ponizej widac od razu.
//
// Dwa rodzaje animacji, ktore mozna mieszac:
//  1. KLATKI: kilka rysunkow jednego sprite'a pokazywanych po kolei (cykl chodu, ogien). Klatki to osobne glify
//     z narzedzia "Glify -> PNG" (np. walk_0, walk_1, walk_2), a Clip mowi, w jakiej kolejnosci i jak szybko.
//  2. RUCH: jeden rysunek, ktory sie rusza, rosnie, obraca i odbija (skok, oddech, trzesienie, odbicie od ziemi).
//     Tego nie trzeba rysowac klatka po klatce: tekstowemu modelowi AI wystarczy jedna dobra klatka.
//
// Klasy: Ease (wygladzanie), Clip i Animator (klatki), Tween (plynna zmiana liczby), Motion (gotowe wzory ruchu),
//        Sheet i Sprite (rysowanie wycinka arkusza ze skala, obrotem i odbiciem), Clock (czas klatki dt).
//
//   // Main: arkusz z narzedzia (stale CW, CH, COLS, GAP, VARS z okna "Glify -> PNG"):
//   sheet = Sheet.Make(Gfx.LoadImage("glyphs.png"), 8, 10, 2, 0, 2);
//   walk = Clip.Make(new int[] { 0, 1, 2, 1 }, 8, Clip.Loop);   // glify 0, 1, 2, 1 po kolei, 8 klatek na sekunde
//   hero = new Sprite(); anim = new Animator(); anim.Play(walk);
//   // Update():
//   float dt = Clock.Dt(); anim.Update(dt); sheet.Apply(hero, anim.Frame(), 0);
//   // Draw():
//   hero.x = 100; hero.y = 120; hero.scaleX = 3; hero.scaleY = 3; hero.Draw();

// Wygladzanie: zamienia postep t (0..1) na postep ruchu (0..1). OutBack i OutBounce wychodza lekko poza 0..1.
class Ease {
    public const int Linear = 0;
    public const int InQuad = 1;        // zaczyna wolno
    public const int OutQuad = 2;       // konczy wolno
    public const int InOutQuad = 3;
    public const int OutCubic = 4;
    public const int OutBack = 5;       // przeskakuje cel i wraca
    public const int OutBounce = 6;     // odbija sie jak pilka

    public static float Apply(int kind, float t) {
        if (t < 0) t = 0;
        if (t > 1) t = 1;
        if (kind == InQuad) return t * t;
        if (kind == OutQuad) return t * (2 - t);
        if (kind == InOutQuad) return t < 0.5f ? 2 * t * t : -1 + (4 - 2 * t) * t;
        if (kind == OutCubic) {
            float u = 1 - t;
            return 1 - u * u * u;
        }
        if (kind == OutBack) {
            float c1 = 1.70158f;
            float u = t - 1;
            return 1 + (c1 + 1) * u * u * u + c1 * u * u;
        }
        if (kind == OutBounce) {
            float n1 = 7.5625f;
            float d1 = 2.75f;
            if (t < 1 / d1) return n1 * t * t;
            if (t < 2 / d1) { t -= 1.5f / d1; return n1 * t * t + 0.75f; }
            if (t < 2.5f / d1) { t -= 2.25f / d1; return n1 * t * t + 0.9375f; }
            t -= 2.625f / d1;
            return n1 * t * t + 0.984375f;
        }
        return t;
    }
}

// Sekwencja klatek: numery glifow w arkuszu, predkosc i tryb.
class Clip {
    public const int Once = 0;          // raz, zostaje na ostatniej klatce
    public const int Loop = 1;          // w kolko
    public const int PingPong = 2;      // tam i z powrotem (0 1 2 1 0 1 2 ...)

    public int[] frames;
    public float fps = 8;
    public int mode = 1;

    public static Clip Make(int[] frames, float fps, int mode) {
        Clip c = new Clip();
        c.frames = frames;
        c.fps = fps;
        c.mode = mode;
        return c;
    }

    // klatki first, first + 1, ..., first + count - 1
    public static Clip Range(int first, int count, float fps, int mode) {
        int[] f = new int[count];
        for (int i = 0; i < count; i++) f[i] = first + i;
        return Make(f, fps, mode);
    }

    // ile sekund trwa jeden obieg
    public float Length() {
        if (mode == PingPong && frames.Length > 1) return (frames.Length * 2 - 2) / fps;
        return frames.Length / fps;
    }

    // czy klip trybu Once doszedl do konca
    public bool Finished(float time) { return mode == Once && time >= frames.Length / fps; }

    // numer klatki (wartosc z frames) po `time` sekundach od startu
    public int FrameAt(float time) {
        int n = frames.Length;
        if (n == 1 || fps <= 0) return frames[0];
        int i = (int)Mathf.Floor(time * fps);
        if (i < 0) i = 0;
        if (mode == Once) {
            if (i >= n) i = n - 1;
        } else if (mode == Loop) {
            i = i % n;
        } else {
            int period = n * 2 - 2;
            i = i % period;
            if (i >= n) i = period - i;
        }
        return frames[i];
    }
}

// Odtwarza klipy: Play zmienia klip (ten sam klip nie zaczyna sie od nowa), Update(dt) idzie do przodu.
class Animator {
    public Clip clip;
    public float time = 0;
    public float speed = 1;             // 2 = dwa razy szybciej
    public bool paused = false;

    public void Play(Clip c) {
        if (clip != c) { clip = c; time = 0; }
    }

    public void Restart(Clip c) { clip = c; time = 0; }

    public void Update(float dt) {
        if (!paused) time += dt * speed;
    }

    public int Frame() { return clip.FrameAt(time); }

    public bool Done() { return clip.Finished(time); }
}

// Plynna zmiana liczby od `from` do `to` w `duration` sekund z wygladzaniem. Wartosc czytasz przez Value().
//   Tween t = Tween.Make(0, 200, 1.5f, Ease.OutBounce); ... t.Update(dt); sprite.y = t.Value();
class Tween {
    public float from = 0;
    public float to = 1;
    public float duration = 1;
    public float delay = 0;             // czekanie przed startem
    public float time = 0;
    public int ease = 0;
    public bool loop = false;

    public static Tween Make(float from, float to, float duration, int ease) {
        Tween t = new Tween();
        t.from = from;
        t.to = to;
        t.duration = duration;
        t.ease = ease;
        return t;
    }

    public void Reset() { time = 0; }

    public void Update(float dt) { time += dt; }

    public bool Done() { return !loop && time >= delay + duration; }

    public float Value() {
        float t = (time - delay) / duration;
        if (loop && time > delay) t = Mathf.Repeat(time - delay, duration) / duration;
        return from + (to - from) * Ease.Apply(ease, t);
    }
}

// Czas jednej klatki w sekundach, z Time.Millis (zabezpieczony przed dlugimi przerwami). Wolaj raz na klatke w Update:
//   float dt = Clock.Dt();
class Clock {
    static int last = -1;

    public static float Dt() {
        int now = Time.Millis();
        if (last < 0) { last = now; return 0; }
        float dt = (now - last) / 1000f;
        last = now;
        if (dt > 0.1f) dt = 0.1f;
        return dt;
    }
}

// Gotowe wzory ruchu liczone z czasu (w sekundach). Dodaj wynik do pozycji albo skali.
class Motion {
    // kolysanie w gore i w dol: amp pikseli, hz razy na sekunde
    public static float Bob(float time, float amp, float hz) {
        return amp * Mathf.Sin(time * hz * 2 * Mathf.PI);
    }

    // skok po paraboli: t od 0 do 1 daje wysokosc od 0 przez `height` z powrotem do 0 (odejmij od y)
    public static float Hop(float t, float height) {
        if (t < 0 || t > 1) return 0;
        return 4 * height * t * (1 - t);
    }

    // oddech: skala Y okolo 1 (np. 0.95..1.05). Skala X = 1 / skala Y zachowuje "objetosc" (squash and stretch)
    public static float Breathe(float time, float amount, float hz) {
        return 1 + amount * Mathf.Sin(time * hz * 2 * Mathf.PI);
    }

    // trzesienie, ktore wygasa: zacznij od time = 0 w chwili uderzenia (decay ok. 5..10)
    public static float Shake(float time, float amp, float hz, float decay) {
        return amp * Mathf.Sin(time * hz * 2 * Mathf.PI) * Mathf.Exp(-decay * time);
    }

    // miganie: true i false na przemian, hz razy na sekunde (niewidzialnosc po ranie)
    public static bool Blink(float time, float hz) {
        return ((int)Mathf.Floor(time * hz * 2)) % 2 == 0;
    }
}

// Arkusz z narzedzia "Glify -> PNG": zna rozmiar komorki, liczbe kolumn i wariantow (stale z okna narzedzia).
class Sheet {
    public int img, cw, ch, cols, gap, vars;

    public static Sheet Make(int img, int cw, int ch, int cols, int gap, int vars) {
        Sheet s = new Sheet();
        s.img = img;
        s.cw = cw;
        s.ch = ch;
        s.cols = cols;
        s.gap = gap;
        s.vars = vars;
        return s;
    }

    // numer ramki glifu w danym wariancie (kolor strony, blysk...)
    public int N(int glyph, int variant) { return glyph * vars + variant; }

    // ustawia wycinek sprite'a na cala komorke glifu
    public void Apply(Sprite s, int glyph, int variant) { ApplyWH(s, glyph, variant, cw, ch); }

    // to samo, ale wycinek jest mniejszy niz komorka (glif wezszy od najwiekszego w arkuszu)
    public void ApplyWH(Sprite s, int glyph, int variant, int w, int h) {
        int n = N(glyph, variant);
        s.img = img;
        s.sx = (n % cols) * (cw + gap);
        s.sy = (n / cols) * (ch + gap);
        s.sw = w;
        s.sh = h;
    }
}

// Wycinek obrazu z pozycja, skala, obrotem, odbiciem i kryciem (alpha; zanikanie: sprite.alpha = tween.Value()). (x, y) to punkt zaczepienia: domyslnie srodek dolnej krawedzi
// (stopy), wiec skok i skalowanie nie odrywaja postaci od ziemi. Obrot idzie wokol srodka sprite'a.
class Sprite {
    public int img, sx, sy, sw, sh;
    public float x, y;
    public float scaleX = 1;
    public float scaleY = 1;
    public float angle = 0;             // stopnie
    public bool flip = false;           // odbicie w poziomie (postac idzie w lewo)
    public float pivotX = 0.5f;         // 0 = lewa krawedz, 1 = prawa
    public float pivotY = 1;            // 0 = gora, 1 = dol
    public bool snap = true;            // pozycja do calych pikseli (ostry pixel art)
    public float alpha = 1;             // krycie 0..1 (zanikanie, duch); < 1 ustawia Gfx.Alpha na czas rysowania, potem wraca do 1

    public static Sprite Make(int img, int sx, int sy, int sw, int sh) {
        Sprite s = new Sprite();
        s.img = img;
        s.sx = sx;
        s.sy = sy;
        s.sw = sw;
        s.sh = sh;
        return s;
    }

    public void Draw() {
        float w = sw * scaleX;
        float h = sh * scaleY;
        float dx = x - w * pivotX;
        float dy = y - h * pivotY;
        if (snap) {
            dx = Mathf.Floor(dx + 0.5f);
            dy = Mathf.Floor(dy + 0.5f);
        }
        if (alpha < 1) Gfx.Alpha(alpha);
        Gfx.ImagePartEx(img, dx, dy, sx, sy, sw, sh, flip ? -scaleX : scaleX, scaleY, angle);
        if (alpha < 1) Gfx.Alpha(1);
    }
}
