/* MiniSharp scene editor (the "Scena" tab): scene view, hierarchy and inspector, like a small Unity.
 * The model and the generator are in scene.js (MSScene), the runtime in lib/Scene.cs. The app (app.js) owns the files:
 * it loads a scene into the editor and writes it back on "Zapisz".
 *
 *   const ed = MSSceneEditor.create(host, {
 *     leading: [elements before the tools],        // the scene chip (list of scenes, new, load, save as)
 *     info: () => MSScene.classInfo(files),         // component classes and their fields
 *     media: () => project.media,                   // name -> bytes (images for the view)
 *     onChange(scene, dirty), onSave(scene),        // every edit / the "Zapisz" button
 *     addComponent(obj, done),                      // "+ Komponent": the app shows the menu (also new script / new graph)
 *     openClass(cls),                               // "Edytuj": code or graph of the component
 *     menu(title, items), prompt(msg, def), notify(text) });
 *   ed.load(scene, dirty); ed.getScene(); ed.isDirty(); ed.markSaved(); ed.refresh();
 */
(function (root) {
"use strict";

const TOP_W = 400, BOT_W = 320, H = 240, GAP = 10;
const BOT_X = (TOP_W - BOT_W) / 2, BOT_Y = H + GAP, VIEW_H = H * 2 + GAP;
const IDENT = /^[A-Za-z_]\w*$/;

function el(tag, cls, text) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== undefined && text !== null) e.textContent = text;
  return e;
}
const clone = (x) => JSON.parse(JSON.stringify(x));
const num = (v, d) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
function cssColor(v, fallback) {
  if (v === undefined || v === null || v === "" || String(v) === "-1") return fallback;
  const s = String(v).trim();
  if (/^#[0-9a-f]{6}$/i.test(s)) return s;
  if (/^0x[0-9a-f]+$/i.test(s)) return "#" + s.slice(2).padStart(6, "0").slice(-6);
  if (/^\d+$/.test(s)) return "#" + Number(s).toString(16).padStart(6, "0").slice(-6);
  return fallback;
}

function create(host, opts) {
  const ask = opts.prompt || ((m, d) => window.prompt(m, d));
  const notify = opts.notify || (() => {});
  let scene = null, dirty = false, sel = null, tab = "insp", info = { classes: new Map() };
  let zoom = 1, pan = { x: 0, y: 0 }, grid = 1, names = true;
  const undo = [];

  host.innerHTML = "";
  host.classList.add("sedit");
  // ---------------------------------------------------------------- tools
  const tools = el("div", "stools");
  const btnSave = el("button", "ssave", "Zapisz"); btnSave.type = "button";
  const btnAdd = el("button", "", "+ Obiekt"); btnAdd.type = "button";
  const btnDup = el("button", "", "Duplikuj"); btnDup.type = "button";
  const btnDel = el("button", "danger", "Usuń"); btnDel.type = "button";
  const btnUndo = el("button", "", "↶"); btnUndo.type = "button"; btnUndo.title = "Cofnij";
  const btnZoom = el("button", "", "🔍 1×"); btnZoom.type = "button"; btnZoom.title = "Powiększenie widoku (przeciągnij tło, żeby przesunąć)";
  const btnMore = el("button", "", "⋯"); btnMore.type = "button";
  tools.append(...(opts.leading || []), btnSave, btnAdd, btnDup, btnDel, btnUndo, btnZoom, btnMore);

  const viewBox = el("div", "sview");
  const cv = el("canvas", "scv");
  viewBox.append(cv);
  const panel = el("div", "spanel");
  const tabs = el("div", "stabs");
  const tabBtns = {};
  for (const [k, t] of [["hier", "Hierarchia"], ["insp", "Inspektor"], ["scene", "Scena"]]) {
    const b = el("button", "", t); b.type = "button"; b.onclick = () => { tab = k; renderPanel(); };
    tabBtns[k] = b; tabs.append(b);
  }
  const body = el("div", "sbody");
  panel.append(tabs, body);
  host.append(tools, viewBox, panel);

  // ---------------------------------------------------------------- state changes
  function snapshot() { if (scene) { undo.push(JSON.stringify(scene)); if (undo.length > 60) undo.shift(); } }
  function changed(keepPanel) {
    dirty = true;
    updateTools();
    draw();
    if (!keepPanel) renderPanel();
    if (opts.onChange) opts.onChange(scene, dirty);
  }
  function edit(fn, keepPanel) { snapshot(); fn(); changed(keepPanel); }
  const objById = (id) => (scene ? scene.objects.find((o) => o.id === id) : null);
  const selected = () => objById(sel);
  function select(id) { sel = id; updateTools(); draw(); renderPanel(); }

  function updateTools() {
    btnSave.textContent = dirty ? "Zapisz ●" : "Zapisz";
    btnSave.classList.toggle("dirty", dirty);
    btnDup.disabled = btnDel.disabled = !selected();
    btnUndo.disabled = !undo.length;
    btnZoom.textContent = `🔍 ${zoom}×`;
    for (const [k, b] of Object.entries(tabBtns)) b.classList.toggle("active", k === tab);
  }

  // ---------------------------------------------------------------- images
  const images = new Map();          // name -> { bytes, bmp, loading }
  function image(name) {
    if (!name) return null;
    const media = opts.media ? opts.media() : {};
    const bytes = media[name];
    if (!bytes) return null;
    let e = images.get(name);
    if (e && e.bytes === bytes) return e.bmp;
    e = { bytes, bmp: null };
    images.set(name, e);
    const type = /\.png$/i.test(name) ? "image/png" : /\.bmp$/i.test(name) ? "image/bmp" : "image/jpeg";
    if (typeof createImageBitmap === "function") {
      createImageBitmap(new Blob([bytes], { type })).then((b) => { if (images.get(name) === e) { e.bmp = b; draw(); if (tab === "insp") renderPanel(); } }).catch(() => {});
    }
    return null;
  }
  const imageNames = () => Object.keys(opts.media ? opts.media() : {}).filter((n) => /\.(png|jpe?g|bmp)$/i.test(n)).sort();

  // object rectangle on its screen (x, y of the screen), as the runtime computes it
  function objRect(o) {
    const bmp = o.image ? image(o.image) : null;
    const sc = num(o.scale, 1);
    let w, h;
    if (o.image) {
      const fr = Array.isArray(o.frame) && num(o.frame[2], 0) > 0 ? o.frame : null;
      w = (fr ? num(fr[2], 0) : bmp ? bmp.width : 16) * sc;
      h = (fr ? num(fr[3], 0) : bmp ? bmp.height : 16) * sc;
    } else { w = num(o.w, 16); h = num(o.h, 16); }
    const x = num(o.x, 0), y = num(o.y, 0), a = num(o.anchor, 0);
    const l = a === 2 ? x : x - w / 2;
    const t = a === 2 ? y : a === 1 ? y - h : y - h / 2;
    return { l, t, w, h, bmp };
  }
  const screenOf = (o) => (num(o.screen, 1) === 0 ? 0 : 1);
  const origin = (s) => (s === 0 ? { x: 0, y: 0 } : { x: BOT_X, y: BOT_Y });

  // ---------------------------------------------------------------- the view
  let scale = 1, dpr = 1;
  function fitCanvas() {
    const w = viewBox.clientWidth || 320;
    const maxH = Math.max(200, (host.clientHeight || 600) * 0.5);
    const s = Math.min(w / TOP_W, maxH / VIEW_H);
    const cssW = Math.round(TOP_W * s), cssH = Math.round(VIEW_H * s);
    dpr = window.devicePixelRatio || 1;
    cv.style.width = cssW + "px"; cv.style.height = cssH + "px";
    cv.width = Math.round(cssW * dpr); cv.height = Math.round(cssH * dpr);
    scale = s;
    draw();
  }
  function draw() {
    const c = cv.getContext("2d");
    if (!c) return;
    c.setTransform(1, 0, 0, 1, 0, 0);
    c.fillStyle = "#0b0d12";
    c.fillRect(0, 0, cv.width, cv.height);
    if (!scene) return;
    const k = scale * dpr * zoom;
    c.setTransform(k, 0, 0, k, -pan.x * k, -pan.y * k);
    c.imageSmoothingEnabled = false;
    const bgs = [cssColor(scene.bgTop, "#000000"), cssColor(scene.bgBottom, "#000000")];
    for (const s of [0, 1]) {
      const o = origin(s), w = s === 0 ? TOP_W : BOT_W;
      c.fillStyle = bgs[s];
      c.fillRect(o.x, o.y, w, H);
      if (grid >= 4 && zoom >= 2) {
        c.strokeStyle = "rgba(255,255,255,.07)"; c.lineWidth = 1 / k;
        c.beginPath();
        for (let x = 0; x <= w; x += grid) { c.moveTo(o.x + x, o.y); c.lineTo(o.x + x, o.y + H); }
        for (let y = 0; y <= H; y += grid) { c.moveTo(o.x, o.y + y); c.lineTo(o.x + w, o.y + y); }
        c.stroke();
      }
    }
    // objects: by layer, equal layers in scene order (as the runtime)
    const list = scene.objects.map((o, i) => [o, i]).sort((a, b) => num(a[0].layer, 0) - num(b[0].layer, 0) || a[1] - b[1]).map((x) => x[0]);
    for (const s of [0, 1]) {
      const o0 = origin(s), w = s === 0 ? TOP_W : BOT_W;
      c.save();
      c.beginPath(); c.rect(o0.x, o0.y, w, H); c.clip();
      for (const o of list) {
        if (screenOf(o) !== s) continue;
        const r = objRect(o);
        const x = o0.x + r.l, y = o0.y + r.t;
        c.globalAlpha = o.active === false ? 0.3 : o.show === false ? 0.55 : 1;
        if (o.image && r.bmp) {
          const fr = Array.isArray(o.frame) && num(o.frame[2], 0) > 0 ? o.frame.map((v) => num(v, 0)) : [0, 0, r.bmp.width, r.bmp.height];
          c.save();
          if (o.flip) { c.translate(x + r.w, y); c.scale(-1, 1); c.drawImage(r.bmp, fr[0], fr[1], fr[2], fr[3], 0, 0, r.w, r.h); }
          else c.drawImage(r.bmp, fr[0], fr[1], fr[2], fr[3], x, y, r.w, r.h);
          c.restore();
        } else if (!o.image && cssColor(o.color, null)) {
          c.fillStyle = cssColor(o.color, "#fff");
          c.fillRect(x, y, r.w, r.h);
        } else {
          c.strokeStyle = "rgba(255,255,255,.55)"; c.lineWidth = 1 / k; c.setLineDash([3 / k, 3 / k]);
          c.strokeRect(x + 0.5 / k, y + 0.5 / k, r.w - 1 / k, r.h - 1 / k);
          c.setLineDash([]);
        }
        c.globalAlpha = 1;
        if (names || o.id === sel) {
          const fs = 9 / Math.max(1, zoom * 0.7);
          c.font = `${fs}px system-ui, sans-serif`;
          c.textAlign = "center";
          c.fillStyle = "rgba(0,0,0,.6)";
          const tw = c.measureText(o.name).width;
          c.fillRect(o0.x + num(o.x, 0) - tw / 2 - 2, y + r.h + 1, tw + 4, fs + 2);
          c.fillStyle = o.id === sel ? "#ffd479" : "#dfe5ee";
          c.fillText(o.name, o0.x + num(o.x, 0), y + r.h + fs);
        }
      }
      c.restore();
    }
    const o = selected();
    if (o) {
      const r = objRect(o), o0 = origin(screenOf(o));
      c.strokeStyle = "#ffd479"; c.lineWidth = 2 / k;
      c.strokeRect(o0.x + r.l - 1 / k, o0.y + r.t - 1 / k, r.w + 2 / k, r.h + 2 / k);
      const px = o0.x + num(o.x, 0), py = o0.y + num(o.y, 0), a = 4 / Math.sqrt(zoom);
      c.beginPath(); c.moveTo(px - a, py); c.lineTo(px + a, py); c.moveTo(px, py - a); c.lineTo(px, py + a); c.stroke();
    }
    c.setTransform(1, 0, 0, 1, 0, 0);
    c.font = `${11 * dpr}px system-ui, sans-serif`;
    c.textAlign = "left";
    c.fillStyle = "rgba(223,229,238,.5)";
    c.fillText("górny 400×240", 4 * dpr, 12 * dpr);
  }

  // view coordinates (canvas CSS px) -> scene space (0..400, 0..490)
  function toSpace(e) {
    const b = cv.getBoundingClientRect();
    return { x: (e.clientX - b.left) / (scale * zoom) + pan.x, y: (e.clientY - b.top) / (scale * zoom) + pan.y };
  }
  function screenAt(p) {
    if (p.y < H + GAP / 2) return 0;
    return 1;
  }
  function hit(p) {
    if (!scene) return null;
    const list = scene.objects.map((o, i) => [o, i]).sort((a, b) => num(b[0].layer, 0) - num(a[0].layer, 0) || b[1] - a[1]).map((x) => x[0]);
    for (const o of list) {
      const s = screenOf(o), o0 = origin(s), r = objRect(o);
      const pad = 4 / (scale * zoom);
      const x = p.x - o0.x, y = p.y - o0.y;
      if (x >= r.l - pad && x < r.l + r.w + pad && y >= r.t - pad && y < r.t + r.h + pad) return o;
    }
    return null;
  }
  const snap = (v) => (grid > 1 ? Math.round(v / grid) * grid : Math.round(v));
  let drag = null;
  cv.addEventListener("pointerdown", (e) => {
    if (!scene) return;
    cv.setPointerCapture(e.pointerId);
    const p = toSpace(e), o = hit(p);
    if (o) {
      if (sel !== o.id) select(o.id);
      drag = { kind: "obj", id: o.id, start: p, ox: num(o.x, 0), oy: num(o.y, 0), os: screenOf(o), moved: false, snap: JSON.stringify(scene) };
    } else {
      drag = { kind: "pan", start: { x: e.clientX, y: e.clientY }, pan: { ...pan }, moved: false };
    }
    e.preventDefault();
  });
  cv.addEventListener("pointermove", (e) => {
    if (!drag) return;
    if (drag.kind === "pan") {
      const dx = e.clientX - drag.start.x, dy = e.clientY - drag.start.y;
      if (Math.abs(dx) + Math.abs(dy) > 4) drag.moved = true;
      if (zoom > 1) { pan.x = drag.pan.x - dx / (scale * zoom); pan.y = drag.pan.y - dy / (scale * zoom); clampPan(); draw(); }
      return;
    }
    const p = toSpace(e), o = objById(drag.id);
    if (!o) return;
    const dx = p.x - drag.start.x, dy = p.y - drag.start.y;
    if (!drag.moved && Math.abs(dx) + Math.abs(dy) < 3 / (scale * zoom)) return;
    drag.moved = true;
    // the point in scene space -> the screen under it (an object can move to the other screen)
    const o0 = origin(drag.os);
    const ax = o0.x + drag.ox + dx, ay = o0.y + drag.oy + dy;
    const s = screenAt({ x: ax, y: ay }), o1 = origin(s);
    o.screen = s;
    o.x = snap(ax - o1.x); o.y = snap(ay - o1.y);
    draw();
  });
  function endDrag() {
    if (!drag) return;
    const d = drag;
    drag = null;
    if (d.kind === "pan") { if (!d.moved && sel) select(null); return; }
    if (d.moved) {
      undo.push(d.snap); if (undo.length > 60) undo.shift();
      changed();
    }
  }
  cv.addEventListener("pointerup", endDrag);
  cv.addEventListener("pointercancel", endDrag);
  function clampPan() {
    const vw = TOP_W / zoom, vh = VIEW_H / zoom;
    pan.x = Math.max(0, Math.min(TOP_W - vw, pan.x));
    pan.y = Math.max(0, Math.min(VIEW_H - vh, pan.y));
  }
  btnZoom.onclick = () => {
    const o = selected();
    const cx = o ? origin(screenOf(o)).x + num(o.x, 0) : TOP_W / 2, cy = o ? origin(screenOf(o)).y + num(o.y, 0) : VIEW_H / 2;
    zoom = zoom >= 4 ? 1 : zoom * 2;
    pan.x = cx - TOP_W / zoom / 2; pan.y = cy - VIEW_H / zoom / 2;
    clampPan(); updateTools(); draw();
  };

  // ---------------------------------------------------------------- objects
  function newObject() {
    if (!scene) return;
    const name = ask("Nazwa obiektu:", "Obiekt" + (scene.objects.length + 1));
    if (name === null) return;
    const vis = zoom > 1 ? { x: pan.x + TOP_W / zoom / 2, y: pan.y + VIEW_H / zoom / 2 } : { x: TOP_W / 2, y: BOT_Y + H / 2 };
    const s = screenAt(vis), o0 = origin(s);
    const o = { id: MSScene.nextObjectId(scene), name: name.trim() || "Obiekt", tag: "", x: snap(vis.x - o0.x), y: snap(vis.y - o0.y), screen: s, layer: 0,
      active: true, show: true, image: "", frame: [0, 0, 0, 0], scale: 1, flip: false, anchor: 0, color: "#7FB2FF", w: 16, h: 16, comps: [] };
    edit(() => scene.objects.push(o), true);
    sel = o.id; tab = "insp";
    updateTools(); draw(); renderPanel();
  }
  btnAdd.onclick = newObject;
  btnDup.onclick = () => {
    const o = selected();
    if (!o) return;
    const c = clone(o);
    c.id = MSScene.nextObjectId(scene);
    let base = o.name.replace(/\d+$/, ""), n = 2;
    while (scene.objects.some((x) => x.name === base + n)) n++;
    c.name = base + n;
    c.x = num(c.x, 0) + 8; c.y = num(c.y, 0) + 8;
    edit(() => scene.objects.splice(scene.objects.indexOf(o) + 1, 0, c), true);
    select(c.id);
  };
  btnDel.onclick = () => {
    const o = selected();
    if (!o) return;
    edit(() => { scene.objects = scene.objects.filter((x) => x !== o); }, true);
    select(null);
  };
  btnUndo.onclick = () => {
    if (!undo.length) return;
    scene = JSON.parse(undo.pop());
    if (!objById(sel)) sel = null;
    changed();
  };
  btnSave.onclick = () => { if (scene && opts.onSave) opts.onSave(scene); };
  btnMore.onclick = () => {
    const items = [
      { title: `Siatka: ${grid === 1 ? "brak" : grid + " px"}`, note: "przyciąganie przy przesuwaniu", fn: () => { grid = grid >= 16 ? 1 : grid === 1 ? 4 : grid * 2; draw(); } },
      { title: names ? "Ukryj nazwy obiektów" : "Pokaż nazwy obiektów", note: "podpisy w widoku sceny", fn: () => { names = !names; draw(); } },
      ...((opts.extraMenu && opts.extraMenu()) || []),
    ];
    opts.menu("Scena", items);
  };

  // ---------------------------------------------------------------- panel: hierarchy, inspector, scene settings
  function row(label, input, note) {
    const r = el("label", "srow");
    r.append(el("span", "slabel", label), input);
    if (note) r.append(el("small", "snote", note));
    return r;
  }
  function textInput(value, onCommit, placeholder, type) {
    const i = el("input");
    i.type = type || "text";
    i.value = value === undefined || value === null ? "" : String(value);
    if (placeholder !== undefined) i.placeholder = placeholder;
    i.autocapitalize = "off"; i.spellcheck = false; i.autocomplete = "off";
    if (type === "number") i.inputMode = "decimal";
    i.addEventListener("change", () => onCommit(i.value));
    i.addEventListener("keydown", (e) => { if (e.key === "Enter") i.blur(); });
    return i;
  }
  function check(value, onCommit) {
    const i = el("input"); i.type = "checkbox"; i.checked = !!value;
    i.addEventListener("change", () => onCommit(i.checked));
    return i;
  }
  function selectInput(options, value, onCommit) {
    const s = el("select");
    for (const [v, t] of options) { const o = el("option", "", t); o.value = v; if (String(v) === String(value)) o.selected = true; s.append(o); }
    s.addEventListener("change", () => onCommit(s.value));
    return s;
  }
  const setO = (o, key, v, keep) => edit(() => { o[key] = v; }, keep);

  function renderPanel() {
    updateTools();
    body.innerHTML = "";
    if (!scene) return;
    if (tab === "hier") renderHierarchy();
    else if (tab === "scene") renderSceneProps();
    else renderInspector();
  }

  function renderHierarchy() {
    if (!scene.objects.length) body.append(el("p", "snone", "Scena jest pusta. „+ Obiekt” dodaje pierwszy."));
    const list = el("div", "shier");
    scene.objects.forEach((o, i) => {
      const r = el("div", "shitem" + (o.id === sel ? " sel" : "") + (o.active === false ? " off" : ""));
      const b = el("button", "shname"); b.type = "button";
      b.append(el("span", "", (screenOf(o) === 0 ? "▲ " : "▼ ") + o.name));
      const meta = [o.tag ? "#" + o.tag : "", num(o.layer, 0) ? "warstwa " + o.layer : "", (o.comps || []).map((c) => c.cls).join(", ")].filter(Boolean).join(" · ");
      if (meta) b.append(el("small", "", meta));
      b.onclick = () => { sel = o.id; tab = "insp"; draw(); renderPanel(); };
      const up = el("button", "smini", "↑"); up.type = "button"; up.title = "Wyżej (wcześniej w Update)";
      up.disabled = i === 0;
      up.onclick = () => edit(() => { scene.objects.splice(i, 1); scene.objects.splice(i - 1, 0, o); });
      const dn = el("button", "smini", "↓"); dn.type = "button"; dn.title = "Niżej";
      dn.disabled = i === scene.objects.length - 1;
      dn.onclick = () => edit(() => { scene.objects.splice(i, 1); scene.objects.splice(i + 1, 0, o); });
      r.append(b, up, dn);
      list.append(r);
    });
    body.append(list);
    body.append(el("p", "snote2", "Kolejność na liście = kolejność Start i Update. Rysowanie: według warstwy, równe warstwy w tej kolejności. ▲ górny ekran, ▼ dolny."));
  }

  function renderSceneProps() {
    const box = el("div", "sform");
    box.append(row("Nazwa", textInput(scene.name, (v) => {
      v = v.trim();
      if (!IDENT.test(v)) { notify("Nazwa sceny: litery, cyfry i _, jak nazwa w kodzie (np. Walka)."); renderPanel(); return; }
      if (opts.rename) opts.rename(scene, v); else edit(() => { scene.name = v; });
    }), "plik " + scene.name + ".scene.cs"));
    box.append(row("Scena startowa", check(scene.start, (v) => setO(scene, "start", v)), "od niej zaczyna się gra"));
    const color = (key, label) => {
      const i = el("input"); i.type = "color"; i.value = cssColor(scene[key], "#000000");
      i.addEventListener("change", () => setO(scene, key, i.value.toUpperCase()));
      return row(label, i);
    };
    box.append(color("bgTop", "Tło górnego"), color("bgBottom", "Tło dolnego"));
    body.append(box);
    body.append(el("h4", "shead", "Zmienne sceny"));
    body.append(el("p", "snote2", "Scenes.Num(\"nazwa\") / Scenes.Text(\"nazwa\") w kodzie i węzłach. Wracają do tych wartości przy każdym wczytaniu sceny. Zmienne całej gry (przeżywają zmianę sceny) to Vars.Num / Vars.SetNum."));
    const vl = el("div", "sform");
    (scene.vars || []).forEach((v, i) => {
      const r = el("div", "svar");
      r.append(textInput(v.name, (x) => {
        if (!IDENT.test(x.trim())) { notify("Nazwa zmiennej: litery, cyfry i _."); renderPanel(); return; }
        setO(v, "name", x.trim());
      }, "nazwa"));
      r.append(selectInput([["float", "liczba"], ["string", "tekst"]], v.type || "float", (x) => setO(v, "type", x)));
      r.append(textInput(v.init, (x) => setO(v, "init", x), "wartość"));
      const del = el("button", "smini danger", "×"); del.type = "button";
      del.onclick = () => edit(() => scene.vars.splice(i, 1));
      r.append(del);
      vl.append(r);
    });
    const add = el("button", "sbig", "+ Zmienna sceny"); add.type = "button";
    add.onclick = () => edit(() => { if (!scene.vars) scene.vars = []; scene.vars.push({ name: "zmienna" + (scene.vars.length + 1), type: "float", init: "0" }); });
    vl.append(add);
    body.append(vl);
  }

  function renderInspector() {
    const o = selected();
    if (!o) {
      body.append(el("p", "snone", "Dotknij obiekt w widoku albo w Hierarchii. „+ Obiekt” dodaje nowy."));
      return;
    }
    const box = el("div", "sform");
    const nm = textInput(o.name, (v) => setO(o, "name", v.trim() || o.name));
    box.append(row("Nazwa", nm));
    box.append(row("Tag", textInput(o.tag, (v) => setO(o, "tag", v.trim()), "np. wrog")));
    const pos = el("div", "spair");
    pos.append(textInput(o.x, (v) => setO(o, "x", num(v, o.x)), "x", "number"), textInput(o.y, (v) => setO(o, "y", num(v, o.y)), "y", "number"));
    box.append(row("Pozycja x, y", pos));
    box.append(row("Ekran", selectInput([[0, "górny (400×240)"], [1, "dolny, dotykowy (320×240)"]], screenOf(o), (v) => setO(o, "screen", Number(v)))));
    box.append(row("Warstwa", textInput(o.layer || 0, (v) => setO(o, "layer", Math.trunc(num(v, 0))), "0", "number"), "większa = na wierzchu"));
    box.append(row("Aktywny", check(o.active !== false, (v) => setO(o, "active", v))));
    body.append(box);

    // sprite
    body.append(el("h4", "shead", "Sprite"));
    const sp = el("div", "sform");
    const imgs = imageNames();
    sp.append(row("Obrazek", selectInput([["", "(brak)"], ...imgs.map((n) => [n, n]), ...(o.image && !imgs.includes(o.image) ? [[o.image, o.image + " (brak pliku)"]] : [])], o.image || "",
      (v) => setO(o, "image", v))));
    if (o.image) {
      const fr = Array.isArray(o.frame) ? o.frame : [0, 0, 0, 0];
      const four = el("div", "squad");
      ["sx", "sy", "sw", "sh"].forEach((k, i) => four.append(textInput(fr[i], (v) => edit(() => { const f = Array.isArray(o.frame) ? o.frame.slice() : [0, 0, 0, 0]; f[i] = Math.max(0, Math.trunc(num(v, 0))); o.frame = f; }), k, "number")));
      sp.append(row("Klatka", four, "sw = 0: cały obrazek"));
      const pick = el("button", "sbig", "Wybierz klatkę na obrazku…"); pick.type = "button";
      pick.onclick = () => framePicker(o);
      sp.append(pick);
      sp.append(row("Skala", textInput(o.scale === undefined ? 1 : o.scale, (v) => setO(o, "scale", num(v, 1)), "1", "number")));
      sp.append(row("Odbicie", check(o.flip, (v) => setO(o, "flip", v))));
      sp.append(row("Punkt x, y", selectInput([[0, "środek"], [1, "środek dołu (stopy)"], [2, "lewy górny róg"]], num(o.anchor, 0), (v) => setO(o, "anchor", Number(v)))));
    } else {
      const hasCol = !!cssColor(o.color, null);
      const ci = el("input"); ci.type = "color"; ci.value = cssColor(o.color, "#7fb2ff");
      ci.addEventListener("change", () => setO(o, "color", ci.value.toUpperCase()));
      const cc = el("div", "spair");
      cc.append(check(hasCol, (v) => setO(o, "color", v ? ci.value.toUpperCase() : -1)), ci);
      sp.append(row("Prostokąt", cc, "bez obrazka: kolorowy prostokąt albo nic"));
      const wh = el("div", "spair");
      wh.append(textInput(o.w === undefined ? 16 : o.w, (v) => setO(o, "w", num(v, 16)), "w", "number"), textInput(o.h === undefined ? 16 : o.h, (v) => setO(o, "h", num(v, 16)), "h", "number"));
      sp.append(row("Rozmiar w, h", wh, "też obszar dotyku (OnTouch)"));
      sp.append(row("Punkt x, y", selectInput([[0, "środek"], [1, "środek dołu (stopy)"], [2, "lewy górny róg"]], num(o.anchor, 0), (v) => setO(o, "anchor", Number(v)))));
    }
    sp.append(row("Rysuj w grze", check(o.show !== false, (v) => setO(o, "show", v)), "wyłącz, gdy komponent rysuje obiekt sam (sprite zostaje w edytorze)"));
    body.append(sp);

    // components
    body.append(el("h4", "shead", "Komponenty (skrypty)"));
    if (!(o.comps || []).length) body.append(el("p", "snote2", "Brak. Komponent to klasa dziedzicząca po Behaviour (kod albo graf): Start, Update, Draw, OnEvent, OnTouch."));
    (o.comps || []).forEach((c, ci) => body.append(compCard(o, c, ci)));
    const add = el("button", "sbig primary", "+ Komponent"); add.type = "button";
    add.onclick = () => opts.addComponent(o, (cls) => {
      if (!cls) return;
      info = opts.info ? opts.info() : info;       // the class may be new (a new script or graph)
      edit(() => { if (!o.comps) o.comps = []; o.comps.push({ cls, on: true, fields: {} }); });
    });
    body.append(add);
  }

  function compCard(o, c, ci) {
    const card = el("div", "scomp");
    const k = info.classes.get(c.cls);
    const head = el("div", "schead");
    const on = check(c.on !== false, (v) => setO(c, "on", v));
    on.title = "włączony (enabled)";
    const title = el("span", "sctitle", c.cls);
    if (k) title.append(el("small", "", (k.isGraph ? " ◇ graf" : " { } kod") + (k.chain.length ? " : " + k.chain[0] : "")));
    else title.append(el("small", "sbad", " brak klasy w projekcie"));
    const editB = el("button", "smini", "Edytuj"); editB.type = "button";
    editB.disabled = !k;
    editB.onclick = () => opts.openClass && opts.openClass(c.cls);
    const up = el("button", "smini", "↑"); up.type = "button"; up.disabled = ci === 0;
    up.onclick = () => edit(() => { o.comps.splice(ci, 1); o.comps.splice(ci - 1, 0, c); });
    const del = el("button", "smini danger", "×"); del.type = "button"; del.title = "Odepnij komponent";
    del.onclick = () => edit(() => o.comps.splice(ci, 1));
    head.append(on, title, editB, up, del);
    card.append(head);
    if (!k) return card;
    // only values the scene can hold: numbers, text, bool, char and references to objects of the scene
    const fields = MSScene.componentFields(info, c.cls).filter((f) => /^(int|float|double|bool|string|char|GameObject)$/.test(f.type));
    if (!fields.length) card.append(el("p", "snote2", "Brak publicznych pól (public int hp = 10; pokaże się tutaj)."));
    const objNames = scene.objects.filter((x) => x !== o).map((x) => x.name);
    for (const f of fields) {
      const val = (c.fields || {})[f.name];
      const setF = (v) => edit(() => {
        if (!c.fields) c.fields = {};
        if (v === "" || v === undefined || v === null) delete c.fields[f.name]; else c.fields[f.name] = v;
      });
      let input;
      if (f.type === "GameObject") {
        const cur = val && typeof val === "object" ? val.ref : "";
        input = selectInput([["", "(null)"], ...objNames.map((n) => [n, n]), ...(cur && !objNames.includes(cur) ? [[cur, cur + " (brak)"]] : [])], cur, (v) => setF(v ? { ref: v } : ""));
      } else if (f.type === "bool") {
        input = selectInput([["", `domyślnie (${f.init || "false"})`], ["true", "true"], ["false", "false"]], val || "", setF);
      } else {
        const def = f.init ? f.init.replace(/^"(.*)"$/, "$1").replace(/f$/, "") : f.type === "string" ? "" : "0";
        input = textInput(typeof val === "string" ? val.replace(/^"(.*)"$/, "$1") : "", (v) => setF(v.trim()), def, /^(int|float|double)$/.test(f.type) ? "number" : "text");
      }
      const label = f.name + (f.from !== c.cls ? " ↑" : "");
      const r = row(label, input, f.type + (f.from !== c.cls ? " z " + f.from : "") + (f.doc ? " · " + f.doc : ""));
      if (val !== undefined && val !== "") r.classList.add("set");
      card.append(r);
    }
    return card;
  }

  // the frame picker: the image with a grid; a tap takes the cell under the finger
  function framePicker(o) {
    const bmp = image(o.image);
    if (!bmp) { notify("Obrazek jeszcze się wczytuje albo go nie ma."); return; }
    const dlg = el("dialog", "gdialog sframe");
    const head = el("div", "ghead");
    const x = el("button", "", "×"); x.type = "button"; x.onclick = () => dlg.close();
    head.append(el("strong", "", "Klatka: " + o.image), x);
    const fr = Array.isArray(o.frame) && num(o.frame[2], 0) > 0 ? o.frame.slice() : [0, 0, bmp.width, bmp.height];
    let cw = fr[2] || 16, ch = fr[3] || 16;
    const ctl = el("div", "sframectl");
    const iw = textInput(cw, (v) => { cw = Math.max(1, Math.trunc(num(v, cw))); paint(); }, "W", "number");
    const ih = textInput(ch, (v) => { ch = Math.max(1, Math.trunc(num(v, ch))); paint(); }, "H", "number");
    ctl.append(el("span", "", "Komórka"), iw, el("span", "", "×"), ih);
    const wrap = el("div", "sframeimg");
    const c = el("canvas");
    wrap.append(c);
    const info2 = el("p", "snote2", "");
    const okB = el("button", "sbig primary", "Użyj tej klatki"); okB.type = "button";
    dlg.append(head, ctl, wrap, info2, okB);
    const z = Math.max(1, Math.min(8, Math.floor(Math.min(560, window.innerWidth - 40) / bmp.width)));
    c.width = bmp.width * z; c.height = bmp.height * z;
    function paint() {
      const g = c.getContext("2d");
      g.imageSmoothingEnabled = false;
      g.fillStyle = "#2a3342"; g.fillRect(0, 0, c.width, c.height);
      for (let yy = 0; yy < c.height; yy += 8) for (let xx = (yy / 8) % 2 ? 8 : 0; xx < c.width; xx += 16) { g.fillStyle = "#222a36"; g.fillRect(xx, yy, 8, 8); }
      g.drawImage(bmp, 0, 0, c.width, c.height);
      g.strokeStyle = "rgba(255,255,255,.25)"; g.lineWidth = 1;
      g.beginPath();
      for (let xx = 0; xx <= bmp.width; xx += cw) { g.moveTo(xx * z + 0.5, 0); g.lineTo(xx * z + 0.5, c.height); }
      for (let yy = 0; yy <= bmp.height; yy += ch) { g.moveTo(0, yy * z + 0.5); g.lineTo(c.width, yy * z + 0.5); }
      g.stroke();
      g.strokeStyle = "#ffd479"; g.lineWidth = 2;
      g.strokeRect(fr[0] * z + 1, fr[1] * z + 1, fr[2] * z - 2, fr[3] * z - 2);
      info2.textContent = `sx ${fr[0]}, sy ${fr[1]}, sw ${fr[2]}, sh ${fr[3]}. Dotknij komórkę; rozmiar komórki zmienisz wyżej (szerokość klatki możesz potem poprawić w inspektorze).`;
    }
    c.addEventListener("pointerdown", (e) => {
      const b = c.getBoundingClientRect();
      const px = (e.clientX - b.left) / (b.width / bmp.width), py = (e.clientY - b.top) / (b.height / bmp.height);
      fr[0] = Math.floor(px / cw) * cw; fr[1] = Math.floor(py / ch) * ch; fr[2] = cw; fr[3] = ch;
      paint();
    });
    okB.onclick = () => { dlg.close(); setO(o, "frame", fr.map((v) => Math.trunc(v))); };
    dlg.addEventListener("close", () => dlg.remove());
    document.body.append(dlg);
    paint();
    dlg.showModal();
  }

  const ro = typeof ResizeObserver !== "undefined" ? new ResizeObserver(() => fitCanvas()) : null;
  if (ro) ro.observe(host);
  window.addEventListener("resize", fitCanvas);

  return {
    load(s, isDirty) {
      scene = s; dirty = !!isDirty; undo.length = 0;
      if (!objById(sel)) sel = null;
      info = opts.info ? opts.info() : info;
      updateTools(); fitCanvas(); renderPanel();
    },
    refresh() { info = opts.info ? opts.info() : info; draw(); renderPanel(); },
    getScene: () => scene,
    isDirty: () => dirty,
    markSaved() { dirty = false; updateTools(); },
    select, fit: fitCanvas,
    edit: (fn) => edit(fn),
    // for tests
    _state: () => ({ sel, tab, zoom, pan, undo: undo.length, dirty }),
    _canvas: cv,
  };
}

root.MSSceneEditor = { create };
})(typeof window !== "undefined" ? window : globalThis);
