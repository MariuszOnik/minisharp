// Folders on the phone. Inside the Android app (WebView) the page gets window.MiniSharpNative from the Java side;
// this file turns it into a project store: every project is a real folder with its .cs files and its images and
// sounds next to them. In a normal browser window.MiniSharpNative does not exist and everything here does nothing.
(function (root) {
"use strict";

const CODE = /^[A-Za-z0-9_][A-Za-z0-9_.\-]*\.cs$/;          // same rule as validName() in app.js
const MEDIA = /\.(png|jpe?g|bmp|wav)$/i;                   // same list as the "+ obrazek / dźwięk" button
const MAX_DEPTH = 4, MAX_MEDIA = 500;                      // how deep and how many images and sounds are read from subfolders

function toB64(bytes) {
  let s = "";
  for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(s);
}
function fromB64(s) {
  const b = atob(s), a = new Uint8Array(b.length);
  for (let i = 0; i < b.length; i++) a[i] = b.charCodeAt(i);
  return a;
}
const safeName = (name) => (String(name).replace(/[\\\/:*?"<>|\u0000-\u001f]/g, "_").replace(/^\.+/, "_").trim().slice(0, 60)) || "projekt";

function make(N) {
  // per folder: what we last wrote or read. Only names in `known` may be deleted from the folder, so a file that
  // someone dropped in with a file manager is never removed just because this page has not seen it yet.
  const states = new Map();
  const state = (dir) => { let s = states.get(dir); if (!s) states.set(dir, s = { known: new Set(), text: new Map(), media: new Map() }); return s; };
  const list = (path) => { try { const r = JSON.parse(N.list(path)); return Array.isArray(r) ? r : null; } catch (e) { return null; } };

  const api = {
    available: !!N,
    active() { try { return !!N && N.hasRoot(); } catch (e) { return false; } },
    rootName() { try { return N.rootName() || ""; } catch (e) { return ""; } },
    pick() { N.pickRoot(); },
    exists(path) { return !!N && N.exists(path); },

    // a folder name for a project: the project's name, made safe, and different from every other project's folder
    freshDir(name, metas, self) {
      const base = safeName(name);
      const taken = new Set(metas.filter((m) => m !== self && m.dir).map((m) => m.dir.toLowerCase()));
      let d = base, i = 2;
      while (taken.has(d.toLowerCase()) || (!(self && self.dir === d) && N.exists(d))) d = `${base} (${i++})`;
      return d;
    },

    // folders in the chosen folder that hold at least one .cs file
    listProjects() {
      const out = [];
      for (const it of list("") || []) {
        if (!it.d) continue;
        const kids = list(it.n);
        if (kids && kids.some((k) => !k.d && CODE.test(k.n))) out.push(it.n);
      }
      return out.sort();
    },

    // writes the project into its folder (changed files only). false when something could not be written
    save(project, meta, metas) {
      if (!api.active()) return true;
      if (!meta.dir) meta.dir = api.freshDir(meta.name, metas, meta);
      const dir = meta.dir, st = state(dir);
      if (!N.mkdirs(dir)) return false;
      let ok = true;
      for (const [name, text] of Object.entries(project.files)) {
        if (st.known.has(name) && st.text.get(name) === text) continue;
        if (N.writeText(dir + "/" + name, text)) { st.known.add(name); st.text.set(name, text); } else ok = false;
      }
      for (const [name, bytes] of Object.entries(project.media)) {
        if (st.known.has(name) && st.media.get(name) === bytes) continue;
        if (N.writeBase64(dir + "/" + name, toB64(bytes))) { st.known.add(name); st.media.set(name, bytes); } else ok = false;
      }
      for (const name of [...st.known]) {         // removed in the editor, so remove from the folder too
        if (project.files[name] !== undefined || project.media[name] !== undefined) continue;
        if (N.remove(dir + "/" + name)) { st.known.delete(name); st.text.delete(name); st.media.delete(name); }
      }
      return ok;
    },

    // the project as it is in its folder: { files, media } or null when the folder is missing or has no .cs file.
    // .cs files are read from the project folder itself; images and sounds from it and from its subfolders, under
    // their relative path ("img/hero.png"), which is also how a program asks for them: Gfx.LoadImage("img/hero.png")
    read(meta) {
      if (!api.active() || !meta.dir || !list(meta.dir)) return null;
      const files = {}, media = {}, st = { known: new Set(), text: new Map(), media: new Map() };
      const walk = (rel, depth) => {
        for (const it of list(rel ? meta.dir + "/" + rel : meta.dir) || []) {
          const name = rel ? rel + "/" + it.n : it.n, path = meta.dir + "/" + name;
          if (it.d) {
            if (depth < MAX_DEPTH && !it.n.startsWith(".")) walk(name, depth + 1);
          } else if (!rel && CODE.test(it.n)) {
            const t = N.readText(path);
            if (t !== null && t !== undefined) { files[name] = t; st.known.add(name); st.text.set(name, t); }
          } else if (MEDIA.test(it.n) && Object.keys(media).length < MAX_MEDIA) {
            const b = N.readBase64(path);
            if (b !== null && b !== undefined) { const bytes = fromB64(b); media[name] = bytes; st.known.add(name); st.media.set(name, bytes); }
          }
        }
      };
      walk("", 0);
      if (!Object.keys(files).length) return null;
      states.set(meta.dir, st);
      return { files, media };
    },

    // the project was renamed: rename its folder as well (meta.name is already the new name)
    rename(meta, metas) {
      if (!api.active() || !meta.dir) return true;
      const nd = api.freshDir(meta.name, metas, meta);
      if (nd === meta.dir) return true;
      if (!N.rename(meta.dir, nd)) return false;
      const st = states.get(meta.dir);
      if (st) { states.delete(meta.dir); states.set(nd, st); }
      meta.dir = nd;
      return true;
    },

    // the project was deleted: delete its folder
    remove(meta) {
      if (!api.active() || !meta.dir) return true;
      states.delete(meta.dir);
      return N.remove(meta.dir);
    },
  };
  return api;
}

root.NativeStore = make(root.MiniSharpNative);
root.NativeStore.make = make;                              // for the tests: a store over a fake bridge
if (typeof module !== "undefined" && module.exports) module.exports = root.NativeStore;
})(typeof window !== "undefined" ? window : globalThis);
