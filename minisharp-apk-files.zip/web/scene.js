/* MiniSharp scenes: the scene model, the scene -> code generator and the class info the inspector needs.
 *
 * Pure functions, no DOM (web/sceneeditor.js is the editor on top of this). Runtime: web/lib/Scene.cs.
 *
 *   MSScene.generate(scene, info)          -> { code, warnings, errors }   (code ends with "// @scene {json}")
 *   MSScene.extract(code)                  -> the scene back out of a generated file, or null
 *   MSScene.classInfo(files)               -> { classes: Map name -> {name, bases, file, isGraph, fields, chain, isBehaviour} }
 *   MSScene.componentFields(info, cls)     -> public instance fields of the class and its bases (up to Behaviour)
 *
 * Scene (plain JSON, stored in the last line of "<Name>.scene.cs"):
 *   { name: "Walka", start: true, bgTop: "0x000000", bgBottom: "0x4B692F",
 *     vars: [{ name: "fala", type: "float"|"string", init: "1" }],              // scene variables (Scenes.Num / Scenes.Text)
 *     objects: [{ id: "o1", name: "Smok", tag: "wrog", x: 200, y: 120, screen: 1, layer: 0, active: true, show: true,
 *                 image: "glyphs.png", frame: [12, 48, 12, 8], scale: 2, flip: false, anchor: 1, color: -1, w: 16, h: 16,
 *                 comps: [{ cls: "UnitStack", on: true, fields: { count: "1", cel: { ref: "Rycerz" } } }] }] }
 *   A field value is a raw C# expression (as the graph's defaults) or { ref: "object name" } for GameObject fields.
 *   Fields not in "fields" keep the default from the class.
 *
 * The generated class registers itself in its own static Main (a hook: every class may have one), so the runtime
 * knows every scene of the project without reflection. */
(function (root) {
"use strict";

const IDENT = /^[A-Za-z_]\w*$/;
const HOOKS = ["Start", "Update", "Draw", "OnEvent", "OnTouch", "OnDestroy"];

function emptyScene(name) {
  return { name: name || "Scena", start: false, bgTop: "0x000000", bgBottom: "0x000000", vars: [], objects: [] };
}
const sceneClass = (name) => "Scene_" + String(name || "").replace(/[^A-Za-z0-9_]/g, "_");
const sceneFile = (name) => `${name}.scene.cs`;
const isSceneText = (t) => /^\/\/ @scene /m.test(t || "");

function serialize(scene) {
  return "// @scene " + JSON.stringify(scene).replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");
}
function extract(code) {
  const m = /^\/\/ @scene (.+)$/m.exec(code || "");
  if (!m) return null;
  try {
    const s = JSON.parse(m[1]);
    return s && Array.isArray(s.objects) ? s : null;
  } catch (e) { return null; }
}

// ---------------------------------------------------------------- classes of the project (for the inspector)
function stripComments(t) {
  return t.replace(/\/\*[\s\S]*?\*\//g, (m) => m.replace(/[^\n]/g, " ")).replace(/\/\/[^\n]*/g, (m) => " ".repeat(m.length));
}
// modifiers and initial value of a field, read from the class body (complete.js gives names and types only)
function fieldDecl(body, type, name) {
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const re = new RegExp(`(^|[;{}])([^;{}]*?)\\b${esc(type).replace(/\s+/g, "\\s*")}\\s+([^;{}()]*?\\b)?${esc(name)}\\s*(=\\s*([^;{}]+?))?\\s*[;,]`, "m");
  const m = re.exec(body);
  if (!m) return { isPublic: false, init: "" };
  let init = (m[5] || "").trim();
  // "int a = 1, b = 2": the value of "a" stops at the comma (not inside brackets)
  let d = 0, cut = init.length;
  for (let i = 0; i < init.length; i++) {
    const c = init[i];
    if ("([{<".includes(c)) d++; else if (")]}>".includes(c)) d--; else if (c === "," && d === 0) { cut = i; break; }
  }
  init = init.slice(0, cut).trim();
  return { isPublic: /\bpublic\b/.test(m[2]), init };
}
function methodMods(body, type, name) {
  const esc = (x) => x.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const re = new RegExp(`(^|[;{}])([^;{}]*?)\\b${esc(type).replace(/\s+/g, "\\s*")}\\s+${name}\\s*\\(`, "m");
  const m = re.exec(body);
  return m ? m[2] : "";
}

function classInfo(files) {
  const MSC = root.MSComplete || (typeof require !== "undefined" ? require("./complete.js") : null);
  const classes = new Map();
  for (const f of files) {
    if (isSceneText(f.text)) continue;
    let list;
    try { list = MSC.parseClasses(f.text); } catch (e) { continue; }
    const clean = stripComments(f.text);
    for (const c of list) {
      if (c.kind !== "class") continue;
      const body = clean.slice(c.bodyStart, c.bodyEnd);
      const fields = [], methods = [];
      for (const m of c.members) {
        if (m.kind === "field" && !m.isStatic) {
          const d = fieldDecl(body, m.type, m.name);
          fields.push({ name: m.name, type: m.type, init: d.init, isPublic: d.isPublic, readOnly: !!m.readOnly, doc: (m.docLines || []).join(" ") });
        } else if (m.kind === "method" && !m.isStatic) {
          const mods = methodMods(body, m.type, m.name);
          methods.push({ name: m.name, type: m.type, params: (m.params || "").trim(), isVirtual: /\b(virtual|abstract|override)\b/.test(mods),
            isPublic: /\bpublic\b/.test(mods), doc: (m.docLines || []).join(" ") });
        }
      }
      classes.set(c.name, { name: c.name, bases: c.bases || [], file: f.name, isGraph: /^\/\/ @graph /m.test(f.text), isAbstract: !!c.isAbstract,
        fields, methods, doc: (c.docLines || []).join(" ") });
    }
  }
  // the chain of bases (classes of the project only) and "is a Behaviour"
  for (const c of classes.values()) {
    const chain = [];
    let cur = c, guard = 0;
    while (cur && guard++ < 20) {
      const b = (cur.bases || []).find((x) => /^[A-Z]/.test(x) && !/^I[A-Z]/.test(x)) || (cur.bases || [])[0];
      if (!b) break;
      chain.push(b);
      cur = classes.get(b);
    }
    c.chain = chain;
    c.isBehaviour = c.name !== "Behaviour" && chain.includes("Behaviour");
  }
  return { classes };
}

// public instance fields of `cls` and of its bases, the class's own first; Behaviour's own fields are not shown
function componentFields(info, cls) {
  const out = [], seen = new Set();
  let cur = info.classes.get(cls), guard = 0;
  while (cur && cur.name !== "Behaviour" && guard++ < 20) {
    for (const f of cur.fields) {
      if (!f.isPublic || f.readOnly || seen.has(f.name)) continue;
      seen.add(f.name);
      out.push({ ...f, from: cur.name });
    }
    cur = info.classes.get(cur.chain[0]);
  }
  return out;
}
const behaviourClasses = (info) => [...info.classes.values()].filter((c) => c.isBehaviour && !c.isAbstract).sort((a, b) => a.name.localeCompare(b.name));

// ---------------------------------------------------------------- values
function colorCode(v, fallback) {
  if (v === undefined || v === null || v === "") return fallback;
  const s = String(v).trim();
  if (/^#[0-9a-f]{6}$/i.test(s)) return "0x" + s.slice(1).toUpperCase();
  if (/^-?\d+$/.test(s) || /^0x[0-9a-f]+$/i.test(s)) return s;
  return fallback;
}
const csString = (s) => '"' + String(s).replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, "\\n") + '"';
const num = (v, d) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
function fnum(v) {           // a float literal MiniSharp accepts
  const n = Math.round(num(v, 0) * 1000) / 1000;
  return Number.isInteger(n) ? String(n) : n + "f";
}
// a value typed into the inspector -> C# (strings get quotes, as in the graph editor)
function fieldCode(type, raw) {
  const s = String(raw).trim();
  if (type === "string") {
    if (/^".*"$/.test(s) || s === "null") return s;
    return csString(s);
  }
  if (type === "float" || type === "double") {
    if (/^-?\d+(\.\d+)?$/.test(s)) return s.includes(".") ? s + "f" : s;
    return s || "0";
  }
  if (type === "bool") return s === "true" || s === "1" ? "true" : s === "false" || s === "0" || !s ? "false" : s;
  if (type === "char" && s.length === 1) return `'${s}'`;
  return s || "0";
}

// ---------------------------------------------------------------- the generator
function generate(scene, info) {
  info = info || { classes: new Map() };
  const warnings = [], errors = [];
  const warn = (obj, message) => warnings.push({ obj: obj || null, message });
  const fail = (obj, message) => errors.push({ obj: obj || null, message });
  const name = String(scene.name || "");
  if (!IDENT.test(name)) fail(null, `nazwa sceny „${name}” musi być jak nazwa w kodzie (litery, cyfry, _)`);
  const cls = sceneClass(name);

  const lines = [];
  const put = (t) => lines.push("        " + t);
  const names = new Map();
  for (const o of scene.objects || []) {
    if (names.has(o.name)) warn(o.id, `dwa obiekty mają nazwę „${o.name}” (Find znajdzie pierwszy)`);
    names.set(o.name, o);
  }
  const refs = [];
  (scene.objects || []).forEach((o, i) => {
    const v = `o${i + 1}`;
    put(`GameObject ${v} = s.Spawn(${csString(o.name || "Obiekt")}, ${fnum(o.x)}, ${fnum(o.y)});`);
    const set = [];
    if (o.tag) set.push(`${v}.tag = ${csString(o.tag)};`);
    if (num(o.screen, 1) !== 1) set.push(`${v}.screen = ${num(o.screen, 1) ? 1 : 0};`);
    if (num(o.layer, 0)) set.push(`${v}.layer = ${Math.trunc(num(o.layer, 0))};`);
    if (o.active === false) set.push(`${v}.active = false;`);
    if (o.show === false) set.push(`${v}.show = false;`);
    if (o.image) {
      set.push(`${v}.image = ${csString(o.image)};`);
      const fr = Array.isArray(o.frame) ? o.frame.map((x) => Math.trunc(num(x, 0))) : null;
      if (fr && fr[2] > 0 && fr[3] > 0) set.push(`${v}.Frame(${fr.join(", ")});`);
    }
    if (num(o.scale, 1) !== 1) set.push(`${v}.scale = ${fnum(o.scale)};`);
    if (o.flip) set.push(`${v}.flip = true;`);
    if (num(o.anchor, 0)) set.push(`${v}.anchor = ${Math.trunc(num(o.anchor, 0))};`);
    const col = colorCode(o.color, "-1");
    if (col !== "-1") set.push(`${v}.color = ${col};`);
    if (num(o.w, 16) !== 16) set.push(`${v}.w = ${fnum(o.w)};`);
    if (num(o.h, 16) !== 16) set.push(`${v}.h = ${fnum(o.h)};`);
    if (set.length) put(set.join(" "));
    (o.comps || []).forEach((c, j) => {
      const k = info.classes.get(c.cls);
      if (!IDENT.test(c.cls || "")) { fail(o.id, `„${o.name}”: komponent bez poprawnej nazwy klasy`); return; }
      if (info.classes.size && !k) { fail(o.id, `„${o.name}”: nie ma klasy „${c.cls}” w projekcie (usunięta albo zmieniona nazwa?)`); return; }
      if (k && !k.isBehaviour) { fail(o.id, `„${o.name}”: klasa „${c.cls}” nie dziedziczy po Behaviour, więc nie może być komponentem`); return; }
      const cv = `${v}c${j + 1}`;
      put(`${c.cls} ${cv} = (${c.cls})${v}.Add(new ${c.cls}(), ${csString(c.cls)});`);
      if (c.on === false) put(`${cv}.enabled = false;`);
      const types = new Map(k ? componentFields(info, c.cls).map((f) => [f.name, f.type]) : []);
      for (const [fname, val] of Object.entries(c.fields || {})) {
        if (!IDENT.test(fname)) continue;
        if (k && !types.has(fname)) { warn(o.id, `„${o.name}”: ${c.cls} nie ma już publicznego pola „${fname}” (pominięte)`); continue; }
        if (val && typeof val === "object") {
          if (val.ref) {
            if (!names.has(val.ref)) warn(o.id, `„${o.name}”: ${c.cls}.${fname} wskazuje na obiekt „${val.ref}”, którego nie ma w scenie`);
            refs.push(`${cv}.${fname} = s.Find(${csString(val.ref)});`);
          }
          continue;
        }
        if (val === "" || val === undefined) continue;
        put(`${cv}.${fname} = ${fieldCode(types.get(fname) || "", val)};`);
      }
    });
  });
  if (refs.length) { put("// odwołania między obiektami: po utworzeniu wszystkich"); refs.forEach(put); }
  const vars = [];
  for (const sv of scene.vars || []) {
    if (!sv.name) continue;
    if (sv.type === "string") vars.push(`s.texts[${csString(sv.name)}] = ${fieldCode("string", sv.init || "")};`);
    else vars.push(`s.nums[${csString(sv.name)}] = ${fieldCode("float", sv.init || "0")};`);
  }
  if (vars.length) { put("// zmienne sceny"); vars.forEach(put); }

  const out = [
    `// Scena „${name}” z edytora sceny. Kod powstaje z JSON-a w ostatniej linii: zmieniaj scenę na karcie Scena.`,
    `class ${cls} : SceneDef {`,
    `    static void Main() { Scenes.Register(new ${cls}(), ${scene.start ? "true" : "false"}); }`,
    "",
    `    public ${cls}() {`,
    `        name = ${csString(name)};`,
    `        bgTop = ${colorCode(scene.bgTop, "0")};`,
    `        bgBottom = ${colorCode(scene.bgBottom, "0")};`,
    "    }",
    "",
    "    public override void Build(Scene s) {",
    ...lines,
    "    }",
    "}",
    "",
    serialize(scene),
    "",
  ];
  return { code: out.join("\n"), warnings, errors };
}

function nextObjectId(scene) {
  let n = 1;
  const ids = new Set((scene.objects || []).map((o) => o.id));
  while (ids.has("o" + n)) n++;
  return "o" + n;
}

// a new component script (code): the hooks to fill in
function scriptTemplate(cls, base) {
  return `// Komponent sceny: podepnij go do obiektu w inspektorze (karta Scena).
// go to obiekt (go.x, go.y, go.name), publiczne pola widać w inspektorze.
class ${cls} : ${base || "Behaviour"} {
    public float speed = 1;

    public override void Start() {
    }

    public override void Update() {
    }

    // wiadomość od innego obiektu: Send(cel, "nazwa", wartość) albo Scenes.Broadcast(...)
    public override void OnEvent(Msg m) {
    }
}
`;
}

root.MSScene = { emptyScene, sceneClass, sceneFile, isSceneText, serialize, extract, classInfo, componentFields, behaviourClasses,
  generate, nextObjectId, scriptTemplate, fieldCode, colorCode, HOOKS };
if (typeof module !== "undefined" && module.exports) module.exports = root.MSScene;
})(typeof window !== "undefined" ? window : globalThis);
