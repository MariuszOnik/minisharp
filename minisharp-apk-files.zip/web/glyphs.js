// Glifów -> PNG. Tekst z bitmapami (jeden znak = jeden piksel) zamienia się w arkusz sprite'ów:
// dla każdego glifu wersje dla stron, błysk, lód i trup, plus plytki z literami. Dzięki temu oddział to
// jedno wywołanie Gfx.ImagePartEx zamiast dziesiątek Gfx.Rect. Działa w przeglądarce, w aplikacji na Androida
// i w Node (testy). PNG koduje się tu samemu (bez canvasa), więc działa wszędzie tak samo.
(function (root) {
"use strict";

const SWEETIE16 = ["#000000", "#1a1c2c", "#b13e53", "#ef7d57", "#ffcd75", "#a7f070", "#38b764", "#4b692f",
                   "#29366f", "#3b5dc9", "#41a6f6", "#73eff7", "#f4f4f4", "#94b0c2", "#566c86", "#333c57"];

const SAMPLE = `// Komentarz zaczyna sie od //. Kolor: numer palety 0..15 (Sweetie 16) albo #rrggbb.

palette
o 0      // obrys
w 12     // bialy

// x = kolor strony, X = jasny kolor strony: po jednej linii na strone (x X)
sides
9 10     // strona 0: niebiescy
2 3      // strona 1: czerwoni

// kolor, na ktory przemalowuje sie wszystko poza obrysem: blysk, lod, trup
tints
12 11 13

outline o

// glyph NAZWA, potem wiersze bitmapy; '.' to nic.
// letter L r1 r2 r3 r4 r5 [kolor] = litera z czcionki 3x5 (kazda liczba to wiersz, najstarszy bit to lewa kolumna)
glyph slime
letter S 3 4 2 1 6
..oooo..
.oxxxxo.
oxXxxxxo
oxwxwxxo
oxxxxxxo
.oooooo.
`;

// Prompt do wklejenia w dowolnym modelu (Claude, Gemini, ChatGPT...): model odpowiada tekstem do tego narzedzia.
// Ostatnia linia to opis zadania, ktory uzytkownik zmienia.
const PROMPT_EXAMPLE_EXTRA = `
// izometryczny kafel 16x8 (romb 2:1: wiersze maja 4, 8, 12, 16, 16, 12, 8, 4 pikseli)
glyph tile
......oooo......
....ooXxxxoo....
..ooXxxxxxxxoo..
ooXxxxxxxxxxxxoo
ooxxxxxxxxxxxxoo
..ooxxxxxxxxoo..
....ooxxxxoo....
......oooo......
`;
const PROMPT = `Jestes generatorem pixel artu zapisanego jako tekst. Odpowiedz WYLACZNIE jednym blokiem tekstu w formacie opisanym nizej (bez wyjasnien przed i po), ktory wkleje do narzedzia "Glify -> PNG" w MiniSharp. Kazdy znak tekstu to jeden piksel obrazka.

FORMAT (sekcje po kolei; komentarz zaczyna sie od //)
palette         linie "znak kolor"; znak to jedna litera lub cyfra (nie . x X), kolor to numer palety 0..15 albo #rrggbb
sides           po jednej linii "kolor jasny_kolor" na kazdy wariant koloru (co najmniej jedna). W bitmapie x = kolor, X = jasny kolor. Warianty to np. dwie druzyny albo trawa/woda/kamien tego samego rysunku
tints           opcjonalnie linia kolorow, na ktore przemalowuje sie caly glif oprocz obrysu (np. blysk, lod, trup)
outline Z       znak obrysu (nie jest przemalowywany)
sheet           opcjonalnie: "cell W H", "columns N", "gap G"
glyph NAZWA     potem wiersze bitmapy. '.' to przezroczysty piksel. Wszystkie wiersze jednego glifu maja DOKLADNIE te sama dlugosc, bez spacji. Wolno uzyc tylko: . x X oraz znakow z palette
letter L r1 r2 r3 r4 r5 [kolor]   opcjonalnie litera 3x5 (liczby 0..7 to wiersze, najstarszy bit to lewa kolumna); pomijaj, jesli o to nie prosze

PALETA 0..15 (Sweetie 16): 0 #000000, 1 #1a1c2c, 2 #b13e53, 3 #ef7d57, 4 #ffcd75, 5 #a7f070, 6 #38b764, 7 #4b692f, 8 #29366f, 9 #3b5dc9, 10 #41a6f6, 11 #73eff7, 12 #f4f4f4, 13 #94b0c2, 14 #566c86, 15 #333c57

ZASADY RYSUNKU
- maly pixel art bez wygladzania, ciemny obrys (znak obrysu), 2-3 odcienie na kolor, swiatlo z lewej gory
- postacie 8x8 albo 16x16, zwrocone w prawo, stoja na dolnej krawedzi bitmapy
- izometryczny kafel to romb 2:1 (np. 32x16: wiersze maja 4, 8, 12, ... 32, 32, ... 12, 8, 4 pikseli, wysrodkowane); klocek to gorny romb plus dwie sciany, razem wysokosc kafla plus wysokosc klocka
- animacja klatkowa, tylko gdy o nia prosze: osobne glify NAZWA_0, NAZWA_1, NAZWA_2 (ta sama postac, ten sam rozmiar i obrys; zmieniaja sie wylacznie ruchome czesci, np. nogi, rece, plomien; reszta pikseli jest identyczna). Cykl chodu to krok szeroki, stoi, krok mijany (trzy glify; kolejnosc 0 1 2 1 ustawia kod gry)
- nie rysuj klatek, ktore da sie zrobic kodem: skok, oddech, odbicie, obrot, trzesienie, miganie. Wystarczy jedna klatka
- przed odpowiedzia sprawdz: kazdy glif ma wiersze o tej samej dlugosci, a kazdy uzyty znak jest w palette albo to . x X

PRZYKLAD FORMATU
${SAMPLE}${PROMPT_EXAMPLE_EXTRA}
ZADANIE (to opis do zmiany)
Narysuj: <TU OPISZ, np. "rycerz, lucznik i smok 8x8, kazdy w dwoch kolorach druzyn, oraz izometryczne kafle 32x16: trawa, woda, kamien">
`;

function parseColor(tok, line) {
  let m;
  if ((m = /^#([0-9a-fA-F]{6})$/.exec(tok)) || (m = /^0x([0-9a-fA-F]{6})$/.exec(tok))) {
    const v = parseInt(m[1], 16);
    return [v >> 16, (v >> 8) & 255, v & 255];
  }
  if (/^\d+$/.test(tok) && +tok < 16) {
    const v = parseInt(SWEETIE16[+tok].slice(1), 16);
    return [v >> 16, (v >> 8) & 255, v & 255];
  }
  throw new Error("linia " + line + ": zły kolor '" + tok + "' (numer 0..15, #rrggbb albo 0xrrggbb)");
}

function parse(text) {
  const pal = {}, sides = [], glyphs = [];
  const sheet = { cellW: 0, cellH: 0, columns: 0, gap: 0 };
  let tints = null, outline = "o", section = "", cur = null;
  const lines = text.split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    const n = i + 1;
    const line = lines[i].replace(/\/\/.*$/, "").trim();
    if (!line) continue;
    const t = line.split(/\s+/);
    if (t[0] === "palette" && t.length === 1) { section = "palette"; cur = null; continue; }
    if (t[0] === "sides" && t.length === 1) { section = "sides"; cur = null; continue; }
    if (t[0] === "tints" && t.length === 1) { section = "tints"; cur = null; continue; }
    if (t[0] === "sheet" && t.length === 1) { section = "sheet"; cur = null; continue; }
    if (t[0] === "outline" && t.length === 2) { outline = t[1]; section = ""; cur = null; continue; }
    if (t[0] === "glyph" && t.length === 2) { cur = { name: t[1], rows: [], letter: null, line: n }; glyphs.push(cur); section = "glyph"; continue; }
    if (section === "palette") {
      if (t.length !== 2 || t[0].length !== 1) throw new Error("linia " + n + ": w palette ma być 'znak kolor'");
      if (t[0] === "." || t[0] === "x" || t[0] === "X") throw new Error("linia " + n + ": znaki . x X są zarezerwowane");
      pal[t[0]] = parseColor(t[1], n);
    } else if (section === "sides") {
      if (t.length !== 2) throw new Error("linia " + n + ": w sides ma być 'kolor jasny_kolor'");
      sides.push([parseColor(t[0], n), parseColor(t[1], n)]);
    } else if (section === "tints") {
      tints = t.map((c) => parseColor(c, n));
    } else if (section === "sheet") {
      const num = (v, lo, what) => { if (!/^\d+$/.test(v) || +v < lo) throw new Error("linia " + n + ": " + what + " ma być liczbą całkowitą >= " + lo); return +v; };
      if (t[0] === "cell" && t.length === 3) { sheet.cellW = num(t[1], 1, "szerokość komórki"); sheet.cellH = num(t[2], 1, "wysokość komórki"); }
      else if (t[0] === "columns" && t.length === 2) sheet.columns = num(t[1], 1, "liczba kolumn");
      else if (t[0] === "gap" && t.length === 2) sheet.gap = num(t[1], 0, "odstęp");
      else throw new Error("linia " + n + ": w sheet jest 'cell W H', 'columns N' albo 'gap G'");
    } else if (section === "glyph" && cur) {
      if (t[0] === "letter") {
        if (t.length < 7 || t[1].length !== 1) throw new Error("linia " + n + ": 'letter L r1 r2 r3 r4 r5 [kolor]'");
        const bits = t.slice(2, 7).map(Number);
        if (bits.some((v) => !(v >= 0 && v <= 7))) throw new Error("linia " + n + ": wiersze litery to liczby 0..7");
        cur.letter = { ch: t[1], bits, color: t.length > 7 ? parseColor(t[7], n) : null };
      } else {
        if (/\s/.test(line)) throw new Error("linia " + n + ": wiersz glifu nie może mieć spacji");
        cur.rows.push({ s: line, n });
      }
    } else {
      throw new Error("linia " + n + ": nie wiem, co to jest: '" + line + "'");
    }
  }
  if (!sides.length) throw new Error("brak sekcji sides (co najmniej jedna strona)");
  if (!glyphs.length) throw new Error("brak glifów (glyph NAZWA)");
  if (!tints) tints = [];
  for (const g of glyphs) {
    if (!g.rows.length) throw new Error("glif " + g.name + " (linia " + g.line + ") nie ma wierszy");
    g.w = g.rows[0].s.length;
    g.h = g.rows.length;
    for (const r of g.rows) {
      if (r.s.length !== g.w) throw new Error("linia " + r.n + ": wiersz ma " + r.s.length + " znaków, a pierwszy wiersz glifu " + g.name + " ma " + g.w);
      for (const ch of r.s) if (ch !== "." && ch !== "x" && ch !== "X" && !pal[ch]) throw new Error("linia " + r.n + ": nieznany znak '" + ch + "' (dodaj go w palette)");
    }
  }
  return { pal, sides, tints, outline, glyphs, sheet };
}

// Układ arkusza. Ramka to jeden wariant jednego glifu: numer n = glif * liczba_wariantów + wariant.
// Domyślnie kolumny to warianty (strona 0, strona 1, ..., blysk, lod, trup), a wiersze to glify w kolejności z tekstu.
// Sekcja `sheet` zmienia to: `cell W H` (rozmiar komórki, domyślnie największy glif), `columns N` (ramki w wierszu,
// kolejne wiersze zawijają się), `gap G` (odstęp między komórkami). Pod bitmapami jest blok liter: plytka 8x12
// (czcionka 3x5 z punktami po 2 piksele i ramką 1 piksel), w tej samej siatce kolumn.
function build(text) {
  const d = parse(text);
  const nSide = d.sides.length, nVar = nSide + d.tints.length, nG = d.glyphs.length;
  const maxW = Math.max(...d.glyphs.map((g) => g.w)), maxH = Math.max(...d.glyphs.map((g) => g.h));
  const CW = d.sheet.cellW || maxW, CH = d.sheet.cellH || maxH;
  if (CW < maxW || CH < maxH) throw new Error("sheet: komórka " + CW + "x" + CH + " jest mniejsza niż największy glif " + maxW + "x" + maxH);
  const GAP = d.sheet.gap, COLS = d.sheet.columns || nVar;
  const LW = 8, LH = 12;
  const hasLetters = d.glyphs.some((g) => g.letter);
  const frames = nG * nVar, ROWS = Math.ceil(frames / COLS);
  const GH = ROWS * (CH + GAP);                              // blok liter zaczyna się na y = GH
  const W = Math.max(COLS * (CW + GAP) - GAP, hasLetters ? COLS * (LW + GAP) - GAP : 0);
  const H = hasLetters ? GH + ROWS * (LH + GAP) - GAP : GH - GAP;
  if (W > 1024 || H > 1024) throw new Error("arkusz ma " + W + "x" + H + ", a MiniSharp wczytuje obrazy do 1024x1024 (zmniejsz sheet cell albo zwiększ columns)");
  const rgba = new Uint8ClampedArray(W * H * 4);
  const put = (x, y, c) => { const o = (y * W + x) * 4; rgba[o] = c[0]; rgba[o + 1] = c[1]; rgba[o + 2] = c[2]; rgba[o + 3] = 255; };
  d.glyphs.forEach((g, gi) => {
    for (let v = 0; v < nVar; v++) {
      const n = gi * nVar + v, col = n % COLS, row = Math.floor(n / COLS);
      const gx = col * (CW + GAP), gy = row * (CH + GAP);
      for (let y = 0; y < g.h; y++) for (let x = 0; x < g.w; x++) {
        const ch = g.rows[y].s[x];
        if (ch === ".") continue;
        let c;
        if (v >= nSide && ch !== d.outline) c = d.tints[v - nSide];
        else if (ch === "x") c = d.sides[Math.min(v, nSide - 1)][0];
        else if (ch === "X") c = d.sides[Math.min(v, nSide - 1)][1];
        else c = d.pal[ch] || [255, 0, 255];
        put(gx + x, gy + y, c);
      }
      if (g.letter) {
        const lc = v >= nSide ? d.tints[v - nSide] : (g.letter.color || d.sides[v][1]);
        const ox = col * (LW + GAP), oy = GH + row * (LH + GAP);
        for (let y = 0; y < LH; y++) for (let x = 0; x < LW; x++) put(ox + x, oy + y, d.pal[d.outline] || [0, 0, 0]);
        for (let r = 0; r < 5; r++) for (let q = 0; q < 3; q++) {
          if (g.letter.bits[r] & (4 >> q)) for (let dy = 0; dy < 2; dy++) for (let dx = 0; dx < 2; dx++) put(ox + 1 + q * 2 + dx, oy + 1 + r * 2 + dy, lc);
        }
      }
    }
  });
  const names = d.glyphs.map((g) => g.name);
  const variants = d.sides.map((_, i) => "strona " + i).concat(d.tints.map((_, i) => ["blysk", "lod", "trup"][i] || "tint " + i));
  const cs = [
    "// arkusz " + W + "x" + H + ". Ramka n = glif * VARS + wariant; wariant: " + variants.map((v, i) => i + " " + v).join(", "),
    "// bitmapa: sx = (n % COLS) * (CW + GAP), sy = (n / COLS) * (CH + GAP), rozmiar gw[glif] x gh[glif]",
    "// litera:  sx = (n % COLS) * (LW + GAP), sy = GH + (n / COLS) * (LH + GAP), rozmiar LW x LH",
    "static int CW = " + CW + ";   // komorka glifu",
    "static int CH = " + CH + ";",
    "static int LW = " + LW + ";   // komorka litery",
    "static int LH = " + LH + ";",
    "static int GAP = " + GAP + ";",
    "static int COLS = " + COLS + ";",
    "static int VARS = " + nVar + ";",
    "static int GH = " + GH + ";   // blok liter zaczyna sie na y = GH",
    "static int[] gw = new int[] { " + d.glyphs.map((g) => g.w).join(", ") + " };   // glify: " + names.join(", "),
    "static int[] gh = new int[] { " + d.glyphs.map((g) => g.h).join(", ") + " };",
  ].join("\n");
  return { w: W, h: H, rgba, cs, names, variants };
}

// ---------------------------------------------------------------- PNG bez zależności (deflate w blokach "stored")
let crcTable = null;
function crc32(buf, start, end) {
  if (!crcTable) {
    crcTable = new Uint32Array(256);
    for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; crcTable[n] = c >>> 0; }
  }
  let c = 0xffffffff;
  for (let i = start; i < end; i++) c = crcTable[(c ^ buf[i]) & 255] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}
function adler32(buf) {
  let a = 1, b = 0;
  for (let i = 0; i < buf.length; i++) { a = (a + buf[i]) % 65521; b = (b + a) % 65521; }
  return ((b << 16) | a) >>> 0;
}

// w, h, rgba (Uint8ClampedArray / Uint8Array) -> Uint8Array z plikiem PNG (8 bit RGBA)
function png(w, h, rgba) {
  const stride = w * 4 + 1;
  const raw = new Uint8Array(stride * h);
  for (let y = 0; y < h; y++) raw.set(rgba.subarray(y * w * 4, (y + 1) * w * 4), y * stride + 1);   // filtr 0
  const blocks = Math.max(1, Math.ceil(raw.length / 65535));
  const z = new Uint8Array(2 + raw.length + blocks * 5 + 4);
  let p = 0;
  z[p++] = 0x78; z[p++] = 0x01;
  for (let b = 0; b < blocks; b++) {
    const start = b * 65535, len = Math.min(65535, raw.length - start);
    z[p++] = b === blocks - 1 ? 1 : 0;
    z[p++] = len & 255; z[p++] = len >> 8; z[p++] = ~len & 255; z[p++] = (~len >> 8) & 255;
    z.set(raw.subarray(start, start + len), p); p += len;
  }
  const ad = adler32(raw);
  z[p++] = ad >>> 24; z[p++] = (ad >>> 16) & 255; z[p++] = (ad >>> 8) & 255; z[p++] = ad & 255;
  const sig = [137, 80, 78, 71, 13, 10, 26, 10];
  const out = new Uint8Array(sig.length + 12 * 3 + 13 + z.length);
  let o = 0;
  out.set(sig, o); o += sig.length;
  const chunk = (type, data) => {
    const dv = new DataView(out.buffer);
    dv.setUint32(o, data.length); o += 4;
    const s = o;
    for (let i = 0; i < 4; i++) out[o++] = type.charCodeAt(i);
    out.set(data, o); o += data.length;
    dv.setUint32(o, crc32(out, s, o)); o += 4;
  };
  const ihdr = new Uint8Array(13), dv = new DataView(ihdr.buffer);
  dv.setUint32(0, w); dv.setUint32(4, h); ihdr[8] = 8; ihdr[9] = 6;
  chunk("IHDR", ihdr);
  chunk("IDAT", z.subarray(0, p));
  chunk("IEND", new Uint8Array(0));
  return out;
}

root.GlyphAtlas = { build, png, SAMPLE, PROMPT };
if (typeof module !== "undefined" && module.exports) module.exports = root.GlyphAtlas;
})(typeof window !== "undefined" ? window : globalThis);
