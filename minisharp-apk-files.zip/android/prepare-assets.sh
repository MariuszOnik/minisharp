#!/bin/sh
# Builds the web version (web/dist) and copies it into the Android app as assets/www.
#   sh android/prepare-assets.sh
# Then build the APK:   gradle -p android assembleDebug   (needs the Android SDK and Gradle 8.9+)
set -e
cd "$(dirname "$0")/.."
sh web/build.sh
rm -rf android/app/src/main/assets/www
mkdir -p android/app/src/main/assets/www
cp -r web/dist/. android/app/src/main/assets/www/
echo "android assets ready: $(du -sk android/app/src/main/assets/www | cut -f1) KB"
