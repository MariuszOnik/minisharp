package pl.mariuszonik.minisharp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;

/**
 * The MiniSharp web page (web/dist, copied to assets/www) in a WebView, plus window.MiniSharpNative
 * (see NativeBridge) so projects can live in real folders on the phone.
 */
public class MainActivity extends Activity implements NativeBridge.Host {
    // The page is served from the APK under a made-up https address. A real origin (instead of file://)
    // is what lets fetch(), WebAssembly and localStorage work like on the real site.
    private static final String HOST = "appassets.androidplatform.net";
    private static final String START = "https://" + HOST + "/index.html";
    private static final int REQ_FILES = 1;
    private static final int REQ_TREE = 2;

    private WebView web;
    private NativeBridge bridge;
    private ValueCallback<Uri[]> fileCallback;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        setContentView(web);
        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true);          // chrome://inspect on a debug build
        }

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);                                // localStorage
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);

        bridge = new NativeBridge(this, this);
        web.addJavascriptInterface(bridge, "MiniSharpNative");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return serve(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;          // our own pages stay in the app
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));  // everything else opens in the browser
                } catch (ActivityNotFoundException ignored) {
                    // no browser installed
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            // Without this the "+ obrazek / dźwięk" button (<input type=file>) does nothing in a WebView.
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE);
                try {
                    startActivityForResult(Intent.createChooser(i, "Wybierz pliki"), REQ_FILES);
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    callback.onReceiveValue(null);
                }
                return true;
            }

            // alert / confirm / prompt of the page (project names, "Usunąć?") as normal dialogs without
            // the "The page at https://appassets... says" title
            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                if (isFinishing()) {
                    result.cancel();
                    return true;
                }
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, (d, w) -> result.confirm())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                if (isFinishing()) {
                    result.cancel();
                    return true;
                }
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton(android.R.string.ok, (d, w) -> result.confirm())
                        .setNegativeButton(android.R.string.cancel, (d, w) -> result.cancel())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView view, String url, String message, String defaultValue,
                                      final JsPromptResult result) {
                if (isFinishing()) {
                    result.cancel();
                    return true;
                }
                final EditText input = new EditText(MainActivity.this);
                input.setInputType(InputType.TYPE_CLASS_TEXT);
                input.setSingleLine(true);
                input.setText(defaultValue == null ? "" : defaultValue);
                input.selectAll();
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setView(input)
                        .setPositiveButton(android.R.string.ok, (d, w) -> result.confirm(input.getText().toString()))
                        .setNegativeButton(android.R.string.cancel, (d, w) -> result.cancel())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }
        });

        web.loadUrl(START);
    }

    // ------------------------------------------------------------------ the page, from the APK

    private WebResourceResponse serve(Uri u) {
        if (!"https".equals(u.getScheme()) || !HOST.equals(u.getHost())) return null;   // not ours: normal loading
        String path = u.getPath();
        if (path == null || path.equals("/")) path = "/index.html";
        String rel = path.substring(1);
        if (!rel.contains("..")) {
            try {
                InputStream in = getAssets().open("www/" + rel);
                String mime = mime(rel);
                return new WebResourceResponse(mime, mime.startsWith("text/") ? "utf-8" : null, in);
            } catch (Exception ignored) {
                // falls through to 404
            }
        }
        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
    }

    private static String mime(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        int dot = n.lastIndexOf('.');
        String ext = dot < 0 ? "" : n.substring(dot + 1);
        switch (ext) {
            case "html":
                return "text/html";
            case "js":
                return "text/javascript";
            case "css":
                return "text/css";
            case "json":
                return "application/json";
            case "webmanifest":
                return "application/manifest+json";
            case "wasm":
                return "application/wasm";                            // WebAssembly.instantiateStreaming needs this
            case "png":
                return "image/png";
            case "jpg":
            case "jpeg":
                return "image/jpeg";
            case "bmp":
                return "image/bmp";
            case "svg":
                return "image/svg+xml";
            case "wav":
                return "audio/wav";
            case "cs":
            case "txt":
                return "text/plain";
            default:
                return "application/octet-stream";
        }
    }

    // ------------------------------------------------------------------ folder picker (NativeBridge.Host)

    @Override
    public void pickFolder() {
        runOnUiThread(() -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                    | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
            try {
                startActivityForResult(i, REQ_TREE);
            } catch (ActivityNotFoundException e) {
                web.evaluateJavascript("alert('Ten telefon nie ma wyboru folderów.')", null);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILES) {
            if (fileCallback != null) {
                Uri[] picked = resultCode == RESULT_OK && data != null
                        ? WebChromeClient.FileChooserParams.parseResult(resultCode, data) : null;
                fileCallback.onReceiveValue(picked);
                fileCallback = null;
            }
        } else if (requestCode == REQ_TREE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri tree = data.getData();
            int flags = data.getFlags()
                    & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            if (flags == 0) flags = Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION;
            try {
                getContentResolver().takePersistableUriPermission(tree, flags);
            } catch (SecurityException e) {
                web.evaluateJavascript("alert('Nie udało się uzyskać dostępu do tego folderu. Wybierz inny, np. Documents/MiniSharp.')", null);
                return;
            }
            bridge.setTree(tree);
            web.evaluateJavascript("window.nativeRootChanged && window.nativeRootChanged()", null);
        }
    }

    // ------------------------------------------------------------------ one-screen games (Gfx.Layout)

    @Override
    public void setOrientation(int mode) {
        runOnUiThread(() -> setRequestedOrientation(
                mode == 1 ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
                        : mode == 2 ? ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                        : ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED));
    }

    @Override
    public void setImmersive(boolean on) {
        runOnUiThread(() -> {
            View d = getWindow().getDecorView();
            int flags = on ? View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION : 0;
            d.setSystemUiVisibility(flags);
        });
    }

    // Back: a running game stops (and comes back to the editor); otherwise the usual behaviour
    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.nativeBack && window.nativeBack()) ? 1 : 0", v -> {
            if ("1".equals(v)) return;
            if (web.canGoBack()) web.goBack();
            else finish();
        });
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
