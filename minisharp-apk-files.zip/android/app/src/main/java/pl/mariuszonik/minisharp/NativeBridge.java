package pl.mariuszonik.minisharp;

import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.UriPermission;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.util.Base64;
import android.webkit.JavascriptInterface;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * window.MiniSharpNative in the web page: files and folders inside ONE folder that the user chose in the
 * system folder picker (Storage Access Framework). No storage permission is needed and the page cannot reach
 * anything outside that folder. Paths are relative to it, with "/" as the separator ("Moja gra/Game.cs").
 * The methods run on a background thread of the WebView, so blocking file I/O is fine here.
 */
public class NativeBridge {
    /** Lets the bridge ask the activity to open the folder picker. */
    public interface Host {
        void pickFolder();

        /** Gfx.Layout: 0 any orientation, 1 portrait, 2 landscape. */
        void setOrientation(int mode);

        /** full screen without the status and navigation bars (one-screen game) */
        void setImmersive(boolean on);
    }

    private static final String PREFS = "minisharp";
    private static final String KEY_TREE = "tree";
    private static final String MIME_DIR = DocumentsContract.Document.MIME_TYPE_DIR;

    private final Context ctx;
    private final Host host;

    public NativeBridge(Context ctx, Host host) {
        this.ctx = ctx;
        this.host = host;
    }

    // ------------------------------------------------------------------ the chosen folder

    private SharedPreferences prefs() {
        return ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private ContentResolver cr() {
        return ctx.getContentResolver();
    }

    private Uri tree() {
        String s = prefs().getString(KEY_TREE, null);
        return s == null ? null : Uri.parse(s);
    }

    /** Called by the activity after the user picked a folder (and the permission was made persistent). */
    void setTree(Uri uri) {
        prefs().edit().putString(KEY_TREE, uri.toString()).apply();
    }

    private String rootId() {
        Uri t = tree();
        return t == null ? null : DocumentsContract.getTreeDocumentId(t);
    }

    private Uri docUri(String docId) {
        return DocumentsContract.buildDocumentUriUsingTree(tree(), docId);
    }

    @JavascriptInterface
    public boolean hasRoot() {
        Uri t = tree();
        if (t == null) return false;
        for (UriPermission p : cr().getPersistedUriPermissions()) {
            if (p.getUri().equals(t) && p.isReadPermission() && p.isWritePermission()) return true;
        }
        return false;
    }

    @JavascriptInterface
    public String rootName() {
        if (!hasRoot()) return "";
        Cursor c = null;
        try {
            c = cr().query(docUri(rootId()), new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception e) {
            // folder gone or provider not available
        } finally {
            if (c != null) c.close();
        }
        return "";
    }

    @JavascriptInterface
    public void pickRoot() {
        host.pickFolder();
    }

    /** Gfx.Layout from the page: turn the screen (0 any, 1 portrait, 2 landscape). */
    @JavascriptInterface
    public void setOrientation(int mode) {
        host.setOrientation(mode);
    }

    @JavascriptInterface
    public void setImmersive(boolean on) {
        host.setImmersive(on);
    }

    // ------------------------------------------------------------------ paths

    private static String[] segs(String path) {
        if (path == null) return null;
        List<String> out = new ArrayList<>();
        for (String s : path.split("/")) {
            if (s.isEmpty() || s.equals(".")) continue;
            if (s.equals("..") || s.indexOf('\\') >= 0 || s.indexOf('\0') >= 0) return null;
            out.add(s);
        }
        return out.toArray(new String[0]);
    }

    /** Document id of the child with this display name, or null. */
    private String child(String parentId, String name) {
        Uri kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree(), parentId);
        Cursor c = null;
        try {
            c = cr().query(kids, new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null);
            if (c == null) return null;
            while (c.moveToNext()) {
                if (name.equals(c.getString(1))) return c.getString(0);
            }
        } catch (Exception e) {
            // treated as "not found"
        } finally {
            if (c != null) c.close();
        }
        return null;
    }

    /** Document id of the item at this path, or null. */
    private String resolve(String path) {
        String[] s = segs(path);
        String id = rootId();
        if (s == null || id == null) return null;
        for (String n : s) {
            id = child(id, n);
            if (id == null) return null;
        }
        return id;
    }

    /** Creates the first `count` folders of the path if they are missing; returns the id of the last one. */
    private String ensureDir(String[] s, int count) {
        String id = rootId();
        if (id == null) return null;
        for (int i = 0; i < count; i++) {
            String next = child(id, s[i]);
            if (next == null) {
                try {
                    Uri u = DocumentsContract.createDocument(cr(), docUri(id), MIME_DIR, s[i]);
                    if (u == null) return null;
                    next = DocumentsContract.getDocumentId(u);
                } catch (Exception e) {
                    return null;
                }
            }
            id = next;
        }
        return id;
    }

    // ------------------------------------------------------------------ folders

    @JavascriptInterface
    public boolean exists(String path) {
        return resolve(path) != null;
    }

    /** JSON: [{"n": name, "d": isFolder, "s": size}, ...], or the string "null" when the path does not exist. */
    @JavascriptInterface
    public String list(String path) {
        String id = resolve(path);
        if (id == null) return "null";
        Uri kids = DocumentsContract.buildChildDocumentsUriUsingTree(tree(), id);
        Cursor c = null;
        try {
            c = cr().query(kids, new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE,
                    DocumentsContract.Document.COLUMN_SIZE}, null, null, null);
            if (c == null) return "null";
            JSONArray arr = new JSONArray();
            while (c.moveToNext()) {
                JSONObject o = new JSONObject();
                o.put("n", c.getString(0));
                o.put("d", MIME_DIR.equals(c.getString(1)));
                o.put("s", c.isNull(2) ? 0L : c.getLong(2));
                arr.put(o);
            }
            return arr.toString();
        } catch (Exception e) {
            return "null";
        } finally {
            if (c != null) c.close();
        }
    }

    /** Creates the folder and every missing folder above it. */
    @JavascriptInterface
    public boolean mkdirs(String path) {
        String[] s = segs(path);
        if (s == null) return false;
        return ensureDir(s, s.length) != null;
    }

    /** Deletes a file or a folder with everything in it. */
    @JavascriptInterface
    public boolean remove(String path) {
        String[] s = segs(path);
        if (s == null || s.length == 0) return false;      // never the chosen folder itself
        String id = resolve(path);
        if (id == null) return false;
        try {
            return DocumentsContract.deleteDocument(cr(), docUri(id));
        } catch (Exception e) {
            return false;
        }
    }

    /** Renames a file or folder in place (newName is a name, not a path). */
    @JavascriptInterface
    public boolean rename(String path, String newName) {
        String[] s = segs(path);
        if (s == null || s.length == 0 || newName == null || newName.isEmpty()
                || newName.indexOf('/') >= 0 || newName.indexOf('\\') >= 0 || newName.equals("..")) return false;
        String id = resolve(path);
        if (id == null) return false;
        try {
            return DocumentsContract.renameDocument(cr(), docUri(id), newName) != null;
        } catch (Exception e) {
            return false;
        }
    }

    // ------------------------------------------------------------------ files

    private byte[] readBytes(String path) {
        String id = resolve(path);
        if (id == null) return null;
        InputStream in = null;
        try {
            in = cr().openInputStream(docUri(id));
            if (in == null) return null;
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            return out.toByteArray();
        } catch (Exception e) {
            return null;
        } finally {
            try {
                if (in != null) in.close();
            } catch (Exception ignored) {
                // nothing to do
            }
        }
    }

    private boolean writeBytes(String path, byte[] data) {
        String[] s = segs(path);
        if (s == null || s.length == 0) return false;
        String parent = ensureDir(s, s.length - 1);
        if (parent == null) return false;
        String name = s[s.length - 1];
        String id = child(parent, name);
        OutputStream out = null;
        try {
            Uri u;
            if (id == null) {
                // octet-stream: with text/plain some providers would add ".txt" to "Game.cs"
                u = DocumentsContract.createDocument(cr(), docUri(parent), "application/octet-stream", name);
                if (u == null) return false;
            } else {
                u = docUri(id);
            }
            out = cr().openOutputStream(u, "wt");            // "wt": truncate, so a shorter file does not keep old bytes
            if (out == null) return false;
            out.write(data);
            out.flush();
            return true;
        } catch (Exception e) {
            return false;
        } finally {
            try {
                if (out != null) out.close();
            } catch (Exception ignored) {
                // nothing to do
            }
        }
    }

    /** UTF-8 text of the file, or null when it cannot be read. */
    @JavascriptInterface
    public String readText(String path) {
        byte[] b = readBytes(path);
        return b == null ? null : new String(b, StandardCharsets.UTF_8);
    }

    @JavascriptInterface
    public boolean writeText(String path, String text) {
        return text != null && writeBytes(path, text.getBytes(StandardCharsets.UTF_8));
    }

    /** Content of the file as base64 (images, sounds), or null when it cannot be read. */
    @JavascriptInterface
    public String readBase64(String path) {
        byte[] b = readBytes(path);
        return b == null ? null : Base64.encodeToString(b, Base64.NO_WRAP);
    }

    @JavascriptInterface
    public boolean writeBase64(String path, String data) {
        if (data == null) return false;
        try {
            return writeBytes(path, Base64.decode(data, Base64.DEFAULT));
        } catch (IllegalArgumentException e) {
            return false;
        }
    }
}
