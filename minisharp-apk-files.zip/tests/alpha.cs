// Gfx.Alpha: bottom screen = shapes over a white background, top screen = Clear ignores alpha
class A {
    static void Main() { }
    static void Update() { }
    static void Draw() {
        Gfx.Screen(Screen.Bottom);
        Gfx.Clear(0xFFFFFF);
        Gfx.Rect(10, 10, 20, 20, 0xFF0000);        // opaque red
        Gfx.Alpha(0.5f);
        Gfx.Rect(40, 10, 20, 20, 0xFF0000);        // red at 50% over white
        Gfx.Rect(70, 10, 20, 20, 0x0000FF);        // blue at 50% over white
        Gfx.Rect(55, 20, 30, 20, 0x00FF00);        // green at 50% over the others where they overlap
        Gfx.Alpha(0.25f);
        Gfx.Circle(120, 30, 12, 0x000000);         // black at 25%
        Gfx.Alpha(0);
        Gfx.Rect(150, 10, 20, 20, 0x000000);       // invisible
        Gfx.Alpha(2);                              // clamped to 1
        Gfx.Rect(180, 10, 20, 20, 0x00FF00);       // opaque green
        Gfx.Alpha(-1);                             // clamped to 0
        Gfx.Rect(210, 10, 20, 20, 0x000000);       // invisible
        Gfx.Alpha(0.5f);
        Gfx.Line(10, 60, 100, 60, 0x000000);       // line at 50%
        Gfx.Alpha(1);

        Gfx.Screen(Screen.Top);
        Gfx.Alpha(0.5f);
        Gfx.Clear(0x000000);                       // Clear ignores the alpha: the screen is plain black
        Gfx.Rect(5, 5, 10, 10, 0xFFFFFF);          // white at 50% over black = grey
        Gfx.Alpha(1);
        Gfx.Rect(20, 5, 10, 10, 0xFFFFFF);         // opaque white
    }
}
