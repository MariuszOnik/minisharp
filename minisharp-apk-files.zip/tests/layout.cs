// Gfx.Layout: one big screen; Gfx.Width/Height follow it; Gfx.Screen does not switch away from it
class L {
    static int frame = 0;
    static void Main() {
        Console.WriteLine("dual top " + Gfx.Width() + "x" + Gfx.Height());
        Gfx.Screen(Screen.Bottom);
        Console.WriteLine("dual bottom " + Gfx.Width() + "x" + Gfx.Height());
        Gfx.Layout(Layout.Portrait);
        Console.WriteLine("portrait " + Gfx.Width() + "x" + Gfx.Height());
        Gfx.Screen(Screen.Top);
        Console.WriteLine("portrait after Gfx.Screen " + Gfx.Width() + "x" + Gfx.Height());
        Gfx.Layout(Layout.Landscape);
        Console.WriteLine("landscape " + Gfx.Width() + "x" + Gfx.Height());
        Gfx.Layout(9);
        Console.WriteLine("bad value = dual " + Gfx.Width() + "x" + Gfx.Height());
        Gfx.Layout(Layout.Landscape);
    }
    static void Update() { frame++; }
    static void Draw() {
        Gfx.Clear(0x102030);
        Gfx.Rect(0, 0, 10, 10, 0xFF0000);                                   // top-left corner
        Gfx.Rect(Gfx.Width() - 10, Gfx.Height() - 10, 10, 10, 0x00FF00);    // bottom-right corner
    }
}
