class PT {
    static int fails = 0;
    static int hits = 0;
    static void Near(string name, float a, float b) {
        if (Mathf.Abs(a - b) > 0.001f) { fails++; Console.WriteLine("FAIL " + name + ": " + a + " != " + b); }
    }
    static void Is(string name, int a, int b) {
        if (a != b) { fails++; Console.WriteLine("FAIL " + name + ": " + a + " != " + b); }
    }
    static void Main() {
        Random.Seed(7);

        // burst: all particles live for `life`, then the emitter is dead
        Emitter e = new Emitter();
        e.life0 = 1;
        e.life1 = 1;
        e.speed0 = 0;
        e.speed1 = 0;
        e.Burst(10);
        Is("burst count", e.Count(), 10);
        e.Update(0.5f);
        Is("alive at 0.5", e.Count(), 10);
        Is("not dead while particles live", e.Dead() ? 1 : 0, 0);
        e.Update(0.6f);
        Is("gone after life", e.Count(), 0);
        Is("dead when empty and not emitting", e.Dead() ? 1 : 0, 1);

        // the limit
        Emitter m = new Emitter();
        m.max = 5;
        m.Burst(10);
        Is("max limits the burst", m.Count(), 5);

        // continuous emission for a limited time
        Emitter r = new Emitter();
        r.rate = 10;
        r.duration = 1;
        r.life0 = 10;
        r.life1 = 10;
        r.Update(0.55f);
        Is("rate 10 for 0.55 s", r.Count(), 5);
        r.Update(0.5f);
        Is("stopped after duration", r.Count(), 5);
        Is("still alive (particles flying)", r.Dead() ? 1 : 0, 0);
        Emitter forever = new Emitter();
        forever.rate = 20;
        forever.life0 = 0.05f;
        forever.life1 = 0.05f;
        for (int i = 0; i < 30; i++) forever.Update(0.1f);
        Is("duration 0 emits as long as rate > 0", forever.Dead() ? 1 : 0, 0);
        forever.Stop();
        for (int i = 0; i < 3; i++) forever.Update(0.1f);
        Is("Stop lets the rest fade", forever.Dead() ? 1 : 0, 1);

        // movement: direction, gravity and drag
        Emitter g = new Emitter();
        g.x = 10;
        g.y = 20;
        g.angle = 0;
        g.spread = 0;
        g.speed0 = 100;
        g.speed1 = 100;
        g.life0 = 5;
        g.life1 = 5;
        g.gy = 100;
        g.Burst(1);
        g.Update(0.1f);
        Particle p = g.At(0);
        Near("x after 0.1 s moving right", p.x, 20);
        Near("vy from gravity", p.vy, 10);
        Near("y after gravity", p.y, 21);
        Emitter d = new Emitter();
        d.angle = 0;
        d.spread = 0;
        d.speed0 = 100;
        d.speed1 = 100;
        d.life0 = 5;
        d.life1 = 5;
        d.drag = 5;
        d.Burst(1);
        d.Update(0.1f);
        Near("drag slows down", d.At(0).vx, 50);

        // radius: particles are born inside the circle
        Emitter c = new Emitter();
        c.x = 100;
        c.y = 100;
        c.radius = 10;
        c.speed0 = 0;
        c.speed1 = 0;
        c.life0 = 5;
        c.life1 = 5;
        c.max = 200;
        c.Burst(100);
        int outside = 0;
        for (int i = 0; i < c.Count(); i++) {
            float dx = c.At(i).x - 100;
            float dy = c.At(i).y - 100;
            if (Mathf.Sqrt(dx * dx + dy * dy) > 10.001f) outside++;
        }
        Is("born inside the radius", outside, 0);

        // colour ramp over life
        Emitter rp = new Emitter();
        rp.ramp = new int[] { 5, 6, 7 };
        Is("ramp at 0", rp.VariantAt(0), 5);
        Is("ramp at 0.5", rp.VariantAt(0.5f), 6);
        Is("ramp at 0.99", rp.VariantAt(0.99f), 7);
        Is("ramp at 1", rp.VariantAt(1), 7);

        // fade: opaque until fadeStart, then down to 0 at the end of life
        Emitter fd = new Emitter();
        Near("no fade by default", fd.AlphaAt(0.9f), 1);
        fd.fadeStart = 0.5f;
        Near("fade: before the start", fd.AlphaAt(0.25f), 1);
        Near("fade: at the start", fd.AlphaAt(0.5f), 1);
        Near("fade: halfway through the fade", fd.AlphaAt(0.75f), 0.5f);
        Near("fade: end of life", fd.AlphaAt(1), 0);

        // drawing every kind of effect must not fail (the sheet is not loaded here, so only lines are drawn)
        Particles.Clear();
        Magic.Lightning(0, 0, 50, 50);
        Magic.Explosion(10, 10);
        Magic.IceBurst(20, 20);
        for (int i = 0; i < 40; i++) {
            Particles.Update(1f / 60);
            Particles.Draw();
        }
        Particles.Clear();

        // the particle pool hands the same object back
        Particle a = Particles.Take();
        Particles.Release(a);
        Particle b = Particles.Take();
        Is("pool reuse", a == b ? 1 : 0, 1);

        // projectile: position, onHit once, dead after the tail faded
        Shot s = new Shot();
        s.x1 = 0;
        s.y1 = 0;
        s.x2 = 100;
        s.y2 = 50;
        s.duration = 1;
        s.arc = 0;
        s.curve = 1;
        s.onHit = () => hits++;
        s.Update(0.5f);
        Near("shot x halfway", s.x, 50);
        Near("shot y halfway", s.y, 25);
        Is("not hit yet", hits, 0);
        s.Update(0.6f);
        Is("hit once", hits, 1);
        Near("ends at the target x", s.x, 100);
        s.Update(0.5f);
        Is("onHit is not called again", hits, 1);
        Is("dead without a tail", s.Dead() ? 1 : 0, 1);
        Shot arc = new Shot();
        arc.x2 = 100;
        arc.y2 = 0;
        arc.duration = 1;
        arc.arc = 30;
        arc.curve = 1;
        arc.Update(0.5f);
        Near("arc lifts the middle", arc.y, -30);

        // lightning keeps its end points
        Bolt bolt = Bolt.Make(10, 20, 110, 220);
        Near("bolt start x", bolt.px[0], 10);
        Near("bolt start y", bolt.py[0], 20);
        Near("bolt end x", bolt.px[bolt.segs], 110);
        Near("bolt end y", bolt.py[bolt.segs], 220);
        Is("bolt points", bolt.px.Length, bolt.segs + 1);
        bolt.Update(0.1f);
        Near("bolt end after reshape", bolt.px[bolt.segs], 110);
        Is("bolt alive", bolt.Dead() ? 1 : 0, 0);
        bolt.Update(0.5f);
        Is("bolt dead after duration", bolt.Dead() ? 1 : 0, 1);

        // the manager removes finished effects; every spell finishes and calls its callback
        Particles.Clear();
        Emitter q = new Emitter();
        q.life0 = 0.1f;
        q.life1 = 0.1f;
        Particles.Add(q);
        q.Burst(3);
        Is("one effect", Particles.Effects(), 1);
        Particles.Update(0.2f);
        Is("finished effect removed", Particles.Effects(), 0);
        hits = 0;
        Magic.Fireball(0, 0, 100, 0, () => { hits++; Magic.Explosion(100, 0); });
        Magic.IceBurst(50, 50);
        Magic.Lightning(0, 0, 50, 50);
        Magic.Heal(20, 20);
        Is("spells started", Particles.Effects() > 5 ? 1 : 0, 1);
        for (int i = 0; i < 300; i++) Particles.Update(1f / 60);
        Is("fireball hit callback ran once", hits, 1);
        Is("all spells finished", Particles.Effects(), 0);
        Emitter aura = Magic.Aura(0, 0, Magic.MagicRamp);
        for (int i = 0; i < 120; i++) Particles.Update(1f / 60);
        Is("aura keeps going", Particles.Effects(), 1);
        Is("aura has particles", aura.Count() > 5 ? 1 : 0, 1);
        aura.Stop();
        for (int i = 0; i < 120; i++) Particles.Update(1f / 60);
        Is("aura ends after Stop", Particles.Effects(), 0);

        Console.WriteLine(fails == 0 ? "particles: all ok" : "particles: " + fails + " failed");
    }
}
