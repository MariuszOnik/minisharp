// Tests of scenes: the scene -> code generator (web/scene.js), graphs as scene components (web/graph.js, "base"),
// and the runtime (web/lib/Scene.cs) through the real compiler.   Run:  node tests/web/scene.test.js
const fs = require("fs"), os = require("os"), path = require("path");
const { execFileSync, spawnSync } = require("child_process");
const root = path.join(__dirname, "..", "..");
const S = require(path.join(root, "web", "scene.js"));
const G = require(path.join(root, "web", "graph.js"));

let pass = 0, fail = 0;
function ok(cond, msg, extra) { (cond ? pass++ : fail++); console.log((cond ? "PASS " : "FAIL ") + msg + (cond ? "" : "  -> " + (typeof extra === "string" ? "\n" + extra : JSON.stringify(extra)))); }

function python() { for (const c of ["python3", "python", "py"]) { const r = spawnSync(c, ["--version"]); if (!r.error && r.status === 0) return c; } throw new Error("no python"); }
const helpFile = path.join(os.tmpdir(), "ms_help_s_" + process.pid + ".json");
execFileSync(python(), [path.join(root, "tools", "gen_help.py"), "--web", helpFile]);
const help = JSON.parse(fs.readFileSync(helpFile, "utf8"));
fs.unlinkSync(helpFile);

const LIB = fs.readFileSync(path.join(root, "web", "lib", "Scene.cs"), "utf8");
const CODE = `// komponenty z kodu
class Licznik : Behaviour {
    public int ile = 0;
    public string napis = "start";
    public float tempo = 1.5f;
    public bool wlaczony = true;
    public GameObject cel = null;
    int ukryte = 3;
    public virtual void Mysl() { Console.WriteLine(go.name + " mysli (kod)"); }
    public void Krzyknij(string co) { Console.WriteLine(go.name + ": " + co); }
    public override void Start() { Console.WriteLine(go.name + " Start " + napis + " cel=" + (cel != null ? cel.name : "null") + " tempo=" + tempo); }
    public override void Update() {
        ile++;
        if (ile == 2 && cel != null) Send(cel, "ping", ile);
        if (ile == 3) Mysl();
    }
}
class Game {
    static int f = 0;
    static void Update() { f++; if (f == 6) { Console.WriteLine("Wolf.ile=" + ((Licznik)Scenes.Find("Wilk").Comp("WilkGraf")).ile); Scenes.Load("Druga"); } if (f == 9) App.Quit(); }
}
`;

// ---------------------------------------------------------------- class info for the inspector
const files0 = [{ name: "Scene.cs", text: LIB }, { name: "Code.cs", text: CODE }];
const info0 = S.classInfo(files0);
ok(info0.classes.get("Licznik").isBehaviour && !info0.classes.get("Scene").isBehaviour && !info0.classes.get("Behaviour").isBehaviour, "classInfo: Behaviour subclasses are components");
const fl = S.componentFields(info0, "Licznik");
ok(fl.map((f) => `${f.name}:${f.type}=${f.init}`).join(" ") === 'ile:int=0 napis:string="start" tempo:float=1.5f wlaczony:bool=true cel:GameObject=null',
  "componentFields: public fields with types and defaults (private ones hidden)", fl);
ok(info0.classes.get("Licznik").methods.find((m) => m.name === "Mysl").isVirtual && !info0.classes.get("Licznik").methods.find((m) => m.name === "Krzyknij").isVirtual, "methods: virtual flag");
ok(S.fieldCode("string", "abc") === '"abc"' && S.fieldCode("float", "2.5") === "2.5f" && S.fieldCode("bool", "1") === "true" && S.fieldCode("int", "Btn.A") === "Btn.A", "fieldCode: strings quoted, floats with f");

// ---------------------------------------------------------------- a graph that inherits from the code class
const baseInfo = (cls) => {
  const fields = [], virtuals = [];
  let c = info0.classes.get(cls);
  while (c) { c.fields.forEach((f) => fields.push(f)); c.methods.filter((m) => m.isVirtual).forEach((m) => virtuals.push(m.name)); c = info0.classes.get(c.chain[0]); }
  return { fields, virtuals };
};
const catalog = G.buildCatalog(help, [...G.sceneNodes(), ...G.baseNodes(info0.classes, "Licznik")]);
ok(catalog.types.has("base.Krzyknij") && catalog.types.has("base.ile.get") && catalog.types.has("base.Send") && !catalog.types.has("base.go.get"),
  "baseNodes: methods and fields of the base and of Behaviour (not go/enabled)");
const g = G.emptyGraph();
g.className = "WilkGraf"; g.base = "Licznik";
g.variables = [{ name: "gniew", type: "int", init: "0" }];
const N = (id, type, data) => g.nodes.push({ id, type, x: 0, y: g.nodes.length * 10, data: data || {} });
const F = (from, out, to, inp) => g.edges.push({ from, out, to, in: inp });
N("st", "event.Main"); N("k1", "base.Krzyknij", { defaults: { co: '"graf startuje"' } }); F("st", "exit", "k1", "enter");
N("ev", "event.OnEvent"); N("if", "if"); N("eq", "cmp.eq", { defaults: { b: '"ping"' } }); F("ev", "exit", "if", "enter"); F("ev", "name", "eq", "a"); F("eq", "result", "if", "cond");
N("sg", "var.set", { name: "gniew" }); N("add", "op.add", { defaults: { b: "1" } }); N("gg", "var.get", { name: "gniew" }); F("gg", "value", "add", "a"); F("add", "result", "sg", "value");
F("if", "true", "sg", "enter");
N("si", "var.set", { name: "ile" }); N("vv", "lit", { value: "(int)m.value - 1" }); F("vv", "value", "si", "value"); F("sg", "exit", "si", "enter");
N("sx", "self.go.x.set", { defaults: { value: "99" } }); F("si", "exit", "sx", "enter");
N("bk", "base.Send"); N("me", "self.go"); N("from", "lit", { value: "m.from" });
F("ev", "from", "bk", "to"); N("nm", "lit", { value: '"pong"' }); F("nm", "value", "bk", "name"); F("ev", "val", "bk", "value_"); F("sx", "exit", "bk", "enter");
N("my", "event.Method", { name: "Mysl" }); N("k2", "base.Krzyknij"); N("wr", "lit", { value: '"mysli (graf), gniew " + gniew' }); F("wr", "value", "k2", "co"); F("my", "exit", "k2", "enter");
const out = G.generate(g, catalog, { embed: false, baseInfo: baseInfo("Licznik") });
ok(!out.errors.length && !out.warnings.length, "graph with a base: no notes", out.errors.concat(out.warnings));
ok(out.code.includes("class WilkGraf : Licznik {") && out.code.includes("    public int gniew = 0;"), "class derives from the code class; graph variables are public (inspector)", out.code);
ok(out.code.includes("    public override void Start() {\n        base.Start();\n        Krzyknij(\"graf startuje\");"), "event Start = override that calls the base first", out.code);
ok(out.code.includes("public override void OnEvent(Msg m) {\n        base.OnEvent(m);\n        if (m.name == \"ping\") {"), "OnEvent(Msg m) with the message's outputs", out.code);
ok(out.code.includes("ile = (int)m.value - 1;") && out.code.includes("go.x = 99;"), "inherited fields are variables; go.x set", out.code);
ok(out.code.includes("    public override void Mysl() {"), "a Method node with the name of a virtual base method overrides it", out.code);
const bad = G.generate({ className: "X", variables: [], nodes: [{ id: "e", type: "event.OnEvent", x: 0, y: 0, data: {} }], edges: [] }, catalog, { embed: false });
ok(bad.errors.length === 1 && /komponentu/.test(bad.errors[0].message), "OnEvent without a base class: an error", bad.errors);

// ---------------------------------------------------------------- the scene generator
const graphFile = { name: "WilkGraf.cs", text: G.generate(g, catalog, { baseInfo: baseInfo("Licznik") }).code };
const files = [...files0, graphFile];
const info = S.classInfo(files);
ok(info.classes.get("WilkGraf").isBehaviour && info.classes.get("WilkGraf").isGraph, "a graph file with a base class is a component class");
ok(S.componentFields(info, "WilkGraf").map((f) => f.name).join() === "gniew,ile,napis,tempo,wlaczony,cel", "inspector fields: the graph's variables, then the inherited ones");
const scene1 = {
  name: "Pierwsza", start: true, bgTop: "#102030", bgBottom: "0x203040", vars: [{ name: "fala", type: "float", init: "2" }, { name: "tytul", type: "string", init: "Las" }],
  objects: [
    { id: "o1", name: "Owca", x: 10, y: 10, comps: [{ cls: "Licznik", fields: { cel: { ref: "Wilk" }, napis: "beee", tempo: "3" } }] },
    { id: "o2", name: "Wilk", x: 50.5, y: 50, tag: "wrog", image: "x.png", frame: [0, 0, 8, 8], scale: 2, flip: true, anchor: 1, layer: 3,
      comps: [{ cls: "WilkGraf", fields: { napis: "auuu" } }] },
  ],
};
const sc = S.generate(scene1, info);
ok(!sc.errors.length && !sc.warnings.length, "scene: no notes", sc.errors.concat(sc.warnings));
ok(sc.code.includes("class Scene_Pierwsza : SceneDef {") && sc.code.includes("Scenes.Register(new Scene_Pierwsza(), true);"), "the scene registers itself (start scene)", sc.code);
ok(sc.code.includes('o1c1.cel = s.Find("Wilk");') && sc.code.indexOf('o1c1.cel = s.Find') > sc.code.indexOf('s.Spawn("Wilk"'), "GameObject fields are set after all objects exist", sc.code);
ok(sc.code.includes('o1c1.napis = "beee";') && sc.code.includes("o1c1.tempo = 3;") && sc.code.includes('o2.tag = "wrog"; o2.layer = 3; o2.image = "x.png"; o2.Frame(0, 0, 8, 8); o2.scale = 2; o2.flip = true; o2.anchor = 1;'),
  "fields and object settings", sc.code);
ok(sc.code.includes('s.nums["fala"] = 2;') && sc.code.includes('s.texts["tytul"] = "Las";'), "scene variables", sc.code);
ok(JSON.stringify(S.extract(sc.code)) === JSON.stringify(scene1), "extract gives the scene back");
const broken = S.generate({ name: "Zla nazwa", objects: [{ id: "o1", name: "A", comps: [{ cls: "Brak" }, { cls: "Game" }] }, { id: "o2", name: "A", comps: [] }] }, info);
ok(broken.errors.length === 3 && broken.warnings.length === 1, "bad scene name, unknown class, not a Behaviour, duplicate names", broken.errors.concat(broken.warnings));

// ---------------------------------------------------------------- through the real compiler
const exe = path.join(root, process.platform === "win32" ? "minisharp.exe" : "minisharp");
if (!fs.existsSync(exe)) console.log("SKIP real-compiler tests: build the PC version first (make -f Makefile.pc)");
else {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "msscene_"));
  for (const f of files) fs.writeFileSync(path.join(tmp, f.name), f.text);
  scene1.objects[1].image = "";                     // no image file in the test
  fs.writeFileSync(path.join(tmp, "Pierwsza.scene.cs"), S.generate(scene1, info).code);
  const scene2 = { name: "Druga", objects: [{ id: "o1", name: "Nowy", comps: [{ cls: "Licznik", fields: { napis: "druga scena, fala=0?" } }] }] };
  fs.writeFileSync(path.join(tmp, "Druga.scene.cs"), S.generate(scene2, info).code);
  const r = spawnSync(exe, [tmp, "--frames", "20"], { encoding: "utf8" });
  const expected = [
    "Owca Start beee cel=Wilk tempo=3",
    "Wilk Start auuu cel=null tempo=1.5",
    "Wilk: graf startuje",
    "Owca mysli (kod)",
    "Wilk: mysli (graf), gniew 1",
    "Wolf.ile=6",
    "Nowy Start druga scena, fala=0? cel=null tempo=1.5",
    "Nowy mysli (kod)",
  ].join("\n");
  ok(r.status === 0 && r.stdout.trim() === expected, "scene + code component + graph component run: messages, override, base call, scene change", r.stdout + r.stderr);
}

console.log(`\nscene: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
