// Gfx.Layout through the real wasm and the real page (web/app.js) in jsdom, with recording canvases and a fake Android bridge.
// Run: npm install && node layout_web.test.js   (needs web/build.sh first)
const { JSDOM } = require("jsdom");
const fs = require("fs");
const path = require("path");
const WEB = path.join(__dirname, "..", "..", "..", "web"), DIST = path.join(WEB, "dist");

function recorder(log, name) {
  const state = { globalAlpha: 1, fillStyle: "#000000", font: "", textBaseline: "" };
  return new Proxy(state, {
    get(t, k) { if (k in t) return t[k]; return (...args) => { log.push({ ctx: name, op: String(k), args, fill: t.fillStyle }); }; },
    set(t, k, v) { t[k] = v; return true; },
  });
}

async function boot(win) {
  const html = fs.readFileSync(path.join(WEB, "index.html"), "utf8").replace(/<script src="[^"]+"><\/script>/g, "");
  const dom = new JSDOM(html, { runScripts: "outside-only", pretendToBeVisual: true, url: "https://appassets.androidplatform.net/index.html" });
  const w = dom.window, log = [], calls = [];
  Object.defineProperty(w, "innerWidth", { value: win[0], configurable: true });
  Object.defineProperty(w, "innerHeight", { value: win[1], configurable: true });
  const ctxs = new Map();
  w.HTMLCanvasElement.prototype.getContext = function () { const id = this.id; if (!ctxs.has(id)) ctxs.set(id, recorder(log, id)); return ctxs.get(id); };
  w.HTMLCanvasElement.prototype.getBoundingClientRect = function () {
    const W = parseFloat(this.style.width) || 400, H = parseFloat(this.style.height) || 240;
    return { left: 0, top: 0, width: W, height: H, right: W, bottom: H };
  };
  w.HTMLCanvasElement.prototype.setPointerCapture = () => {};
  w.ImageData = class { constructor(d, wd, ht) { this.data = d; this.width = wd; this.height = ht; } };
  w.HTMLDialogElement.prototype.showModal = function () { this.setAttribute("open", ""); };
  w.HTMLDialogElement.prototype.close = function () { this.removeAttribute("open"); };
  w.TextEncoder = TextEncoder; w.TextDecoder = TextDecoder; w.WebAssembly = WebAssembly;
  w.alert = () => {}; w.prompt = () => null; w.confirm = () => true;
  w.matchMedia = () => ({ matches: true, addEventListener() {}, addListener() {} });
  w.requestAnimationFrame = (f) => setTimeout(() => f(w.performance.now()), 16);
  w.cancelAnimationFrame = (id) => clearTimeout(id);
  w.AudioContext = undefined;
  // a fake Android bridge: only what Gfx.Layout uses (no folder chosen)
  w.MiniSharpNative = { hasRoot: () => false, setOrientation: (m) => calls.push("orientation " + m), setImmersive: (on) => calls.push("immersive " + on) };
  w.fetch = async (u) => {
    const file = path.join(DIST, String(u));
    if (fs.existsSync(file) && fs.statSync(file).isFile())
      return new Response(fs.readFileSync(file), { status: 200, headers: { "content-type": String(u).endsWith(".wasm") ? "application/wasm" : "text/plain" } });
    return new Response("not found", { status: 404 });
  };
  for (const f of ["complete.js", "graph.js", "grapheditor.js", "native.js", "glyphs.js", "app.js"]) {
    try { w.eval(fs.readFileSync(path.join(WEB, f), "utf8")); } catch (e) { console.log("script error in", f, "->", e.message.split("\n")[0]); }
  }
  const $ = (s) => w.document.querySelector(s);
  for (let i = 0; i < 50 && $("#run").disabled; i++) await new Promise((r) => setTimeout(r, 40));
  if ($("#run").disabled) throw new Error("compiler did not load: " + $("#status").textContent);
  return { w, $, log, calls };
}
async function runProgram(b, program, wait = 350) {
  b.$("#code").value = program;
  b.$("#code").dispatchEvent(new b.w.Event("input"));
  b.log.length = 0;
  b.$("#run").click();
  await new Promise((r) => setTimeout(r, wait));
}
const program = (layout) => `
class G {
    static int tx = -1;
    static int ty = -1;
    static void Main() { Gfx.Layout(${layout}); Console.WriteLine("size " + Gfx.Width() + "x" + Gfx.Height()); }
    static void Update() { if (Input.Touching()) { tx = Input.TouchX(); ty = Input.TouchY(); } }
    static void Draw() {
        Gfx.Screen(Screen.Bottom);
        Gfx.Rect(0, 0, 1, 1, 0x010203);
        Gfx.Rect(Gfx.Width() - 4, Gfx.Height() - 4, 4, 4, 0x00FF00);
        Gfx.Text(10, 10, "touch " + tx + "," + ty, 0xFFFFFF);
    }
}`;

let pass = 0, fail = 0;
const ok = (c, n) => { if (c) pass++; else { fail++; console.log("FAIL:", n); } };

(async () => {
  // a phone held upright: 400 x 860 css pixels
  const b = await boot([400, 860]);
  const body = b.w.document.body;
  ok(!body.classList.contains("single"), "two screens before running");
  await runProgram(b, program("Layout.Portrait"));
  ok(body.classList.contains("single"), "Gfx.Layout(Portrait) switches to one screen");
  ok(/size 240x516/.test(b.$("#out").textContent), "portrait size follows the window (240 x 240*860/400 = 516): " + b.$("#out").textContent.trim());
  const one = b.$("#one");
  ok(one.width === 240 * 3 && one.height === 516 * 3, "canvas resolution 3x the logical size: " + one.width + "x" + one.height);
  ok(parseFloat(one.style.width) === 400 && parseFloat(one.style.height) === 860, "shown over the whole window: " + one.style.width + " x " + one.style.height);
  const onDraws = b.log.filter((e) => e.ctx === "one" && e.op === "fillRect");
  ok(onDraws.some((e) => e.fill === "#010203"), "drawing goes to the one screen even after Gfx.Screen(Bottom)");
  ok(onDraws.some((e) => e.fill === "#00ff00" && e.args[0] === 236 && e.args[1] === 512), "Gfx.Width()/Height() give the corner of the one screen");
  ok(!b.log.some((e) => e.ctx === "bot" && e.fill === "#010203"), "nothing is drawn on the old bottom screen");
  ok(b.calls.includes("orientation 1") && b.calls.includes("immersive true"), "Android: portrait locked and full screen: " + b.calls.join(", "));
  // touch in the one screen's own pixels: the middle of the window is the middle of the screen
  one.dispatchEvent(new b.w.MouseEvent("pointerdown", { clientX: 200, clientY: 430, bubbles: true }));
  await new Promise((r) => setTimeout(r, 120));
  const texts = b.log.filter((e) => e.op === "fillText").map((e) => e.args[0]);
  ok(texts.some((t) => t === "touch 120,258"), "touch maps to one-screen pixels: " + texts.slice(-1)[0]);
  one.dispatchEvent(new b.w.MouseEvent("pointerup", { bubbles: true }));
  // the Android back button stops the game and returns to the two screens
  const handled = b.w.nativeBack();
  ok(handled === true && !body.classList.contains("single"), "back stops the game and returns to two screens");
  ok(b.calls.includes("orientation 0") && b.calls.includes("immersive false"), "Android: orientation freed, bars back: " + b.calls.join(", "));
  ok(b.w.nativeBack() === false, "back with no game running is left to the app");

  // landscape on the same upright phone: long side from the window's proportions, shown letterboxed until turned
  b.calls.length = 0;
  await runProgram(b, program("Layout.Landscape"));
  ok(/size 516x240/.test(b.$("#out").textContent), "landscape size: " + b.$("#out").textContent.trim());
  ok(b.calls.includes("orientation 2"), "Android: landscape locked");
  ok(parseFloat(one.style.width) <= 400, "fits the window while the phone is still upright: " + one.style.width);
  // the stop button on the one screen
  b.w.document.querySelector(".onestop").click();
  ok(!body.classList.contains("single"), "the ■ button on the one screen stops the game");

  // a program without Gfx.Layout keeps the two screens
  b.calls.length = 0;
  await runProgram(b, program("Layout.Dual"));
  ok(!body.classList.contains("single") && /size 400x240/.test(b.$("#out").textContent), "Layout.Dual = the usual two screens: " + b.$("#out").textContent.trim());
  ok(b.calls.length === 0, "no native calls when nothing changes");
  console.log(`\nGfx.Layout in the real wasm + page (jsdom): ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.log("ERROR", e.message); process.exit(1); });
