// Runs the real wasm (web/dist) inside the real page script (web/app.js) in jsdom, with a recording canvas,
// and checks what globalAlpha the canvas had when each shape was drawn.
const { JSDOM } = require("jsdom");
const fs = require("fs");
const path = require("path");
const WEB = path.join(__dirname, "..", "..", "..", "web"), DIST = path.join(WEB, "dist");

function recorder(log, name) {
  const state = { globalAlpha: 1, fillStyle: "#000000", font: "", textBaseline: "" };
  return new Proxy(state, {
    get(t, k) {
      if (k in t) return t[k];
      return (...args) => { log.push({ ctx: name, op: String(k), args, alpha: t.globalAlpha, fill: t.fillStyle }); };
    },
    set(t, k, v) { if (k === "globalAlpha") log.push({ ctx: name, op: "setAlpha", v }); t[k] = v; return true; },
  });
}

async function run(program, wait = 400) {
  const html = fs.readFileSync(path.join(WEB, "index.html"), "utf8").replace(/<script src="[^"]+"><\/script>/g, "");
  const dom = new JSDOM(html, { runScripts: "outside-only", pretendToBeVisual: true, url: "https://appassets.androidplatform.net/index.html" });
  const w = dom.window, log = [];
  const ctxs = new Map();
  w.HTMLCanvasElement.prototype.getContext = function () {
    const id = this.id || "canvas";
    if (!ctxs.has(id)) { const c = recorder(log, id); ctxs.set(id, c); }
    return ctxs.get(id);
  };
  w.ImageData = class { constructor(d, wd, ht) { this.data = d; this.width = wd; this.height = ht; } };
  w.HTMLDialogElement.prototype.showModal = function () { this.setAttribute("open", ""); };
  w.HTMLDialogElement.prototype.close = function () { this.removeAttribute("open"); };
  w.TextEncoder = TextEncoder; w.TextDecoder = TextDecoder; w.WebAssembly = WebAssembly;
  w.alert = () => {}; w.prompt = () => null; w.confirm = () => true;
  w.matchMedia = () => ({ matches: false, addEventListener() {}, addListener() {} });
  w.requestAnimationFrame = (f) => setTimeout(() => f(w.performance.now()), 16);
  w.cancelAnimationFrame = (id) => clearTimeout(id);
  w.AudioContext = undefined;
  w.fetch = async (u) => {
    u = String(u);
    const file = path.join(DIST, u);
    if (fs.existsSync(file) && fs.statSync(file).isFile()) {
      const buf = fs.readFileSync(file);
      return new Response(buf, { status: 200, headers: { "content-type": u.endsWith(".wasm") ? "application/wasm" : u.endsWith(".json") ? "application/json" : "text/plain" } });
    }
    return new Response("not found", { status: 404 });
  };
  for (const f of ["complete.js", "graph.js", "grapheditor.js", "native.js", "glyphs.js", "app.js"]) {
    try { w.eval(fs.readFileSync(path.join(WEB, f), "utf8")); } catch (e) { console.log("script error in", f, "->", e.message.split("\n")[0]); }
  }
  const $ = (s) => w.document.querySelector(s);
  for (let i = 0; i < 50 && $("#run").disabled; i++) await new Promise((r) => setTimeout(r, 40));
  if ($("#run").disabled) throw new Error("compiler did not load: " + $("#status").textContent);
  $("#code").value = program;
  $("#code").dispatchEvent(new w.Event("input"));
  log.length = 0;
  $("#run").click();
  await new Promise((r) => setTimeout(r, wait));
  const status = $("#status").textContent;
  w.close();
  return { log, status };
}

let pass = 0, fail = 0;
const ok = (c, n) => { if (c) pass++; else { fail++; console.log("FAIL:", n); } };

(async () => {
  const program = `
class A {
    static void Main() { }
    static void Update() { }
    static void Draw() {
        Gfx.Screen(Screen.Bottom);
        Gfx.Rect(0, 0, 1, 1, 0x010203);
        Gfx.Clear(0xFFFFFF);
        Gfx.Rect(10, 10, 20, 20, 0xFF0000);
        Gfx.Alpha(0.5f);
        Gfx.Rect(40, 10, 20, 20, 0x00FF00);
        Gfx.Circle(80, 20, 10, 0x0000FF);
        Gfx.Line(10, 50, 90, 50, 0x000000);
        Gfx.Text(10, 60, "ok", 0x000000);
        Gfx.Clear(0x112233);
        Gfx.Rect(100, 10, 5, 5, 0xFF00FF);
        Gfx.Alpha(1);
        Gfx.Rect(110, 10, 5, 5, 0xFFFF00);
    }
}`;
  const { log, status } = await run(program);
  console.log("status:", status.slice(0, 60)); if (process.env.DEBUG) { const c = {}; for (const e of log) { const k = e.ctx + ":" + e.op; c[k] = (c[k] || 0) + 1; } console.log(JSON.stringify(c)); console.log(JSON.stringify(log.slice(0, 14))); }
  const bot = log.filter((e) => e.ctx === "bot");
  // frames are delimited by the marker rect (#010203), the first draw of every frame
  const marks = bot.map((e, i) => (e.op === "fillRect" && e.fill === "#010203" ? i : -1)).filter((i) => i >= 0);
  ok(marks.length >= 3, "several frames ran: " + marks.length);
  const frame = bot.slice(marks[marks.length - 3], marks[marks.length - 2]);       // one complete frame
  const shapes = frame.filter((e) => ["fillRect", "fill", "stroke", "fillText"].includes(e.op));
  const at = (pred) => shapes.find(pred);
  const red = at((e) => e.op === "fillRect" && e.fill === "#ff0000");
  const green = at((e) => e.op === "fillRect" && e.fill === "#00ff00");
  const blue = at((e) => e.op === "fill" && e.fill === "#0000ff");
  const line = at((e) => e.op === "stroke");
  const text = at((e) => e.op === "fillText");
  const clear2 = at((e) => e.op === "fillRect" && e.fill === "#112233");
  const magenta = at((e) => e.op === "fillRect" && e.fill === "#ff00ff");
  const yellow = at((e) => e.op === "fillRect" && e.fill === "#ffff00");
  ok(red && red.alpha === 1, "rect before Gfx.Alpha is opaque: " + JSON.stringify(red && red.alpha));
  ok(green && green.alpha === 0.5, "rect after Gfx.Alpha(0.5): " + JSON.stringify(green && green.alpha));
  ok(blue && blue.alpha === 0.5, "circle at 0.5: " + JSON.stringify(blue && blue.alpha));
  ok(line && line.alpha === 0.5, "line at 0.5: " + JSON.stringify(line && line.alpha));
  ok(text && text.alpha === 0.5, "text at 0.5: " + JSON.stringify(text && text.alpha));
  ok(clear2 && clear2.alpha === 1, "Gfx.Clear is drawn opaque even while alpha is 0.5: " + JSON.stringify(clear2 && clear2.alpha));
  ok(magenta && magenta.alpha === 0.5, "alpha is restored to 0.5 after Clear: " + JSON.stringify(magenta && magenta.alpha));
  ok(yellow && yellow.alpha === 1, "Gfx.Alpha(1) goes back to opaque: " + JSON.stringify(yellow && yellow.alpha));
  // every frame starts at alpha 1 (the previous frame ended on 1 here, so check a program that leaves it at 0.3)
  const leak = await run(`class B { static void Main() {} static void Update() {} static void Draw() { Gfx.Screen(Screen.Bottom); Gfx.Rect(1, 1, 5, 5, 0xAABBCC); Gfx.Alpha(0.3f); } }`, 500);
  const rects = leak.log.filter((e) => e.ctx === "bot" && e.op === "fillRect" && e.fill === "#aabbcc");
  ok(rects.length >= 3, "the program kept running for several frames: " + rects.length);
  ok(rects.every((e) => e.alpha === 1), "every frame starts at alpha 1 although the previous frame ended at 0.3: " + JSON.stringify([...new Set(rects.map((e) => e.alpha))]));
  console.log(`\nGfx.Alpha in the real wasm + page (jsdom): ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.log("ERROR", e.message); process.exit(1); });
