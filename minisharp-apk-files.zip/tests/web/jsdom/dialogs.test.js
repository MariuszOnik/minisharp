const { JSDOM } = require("jsdom");
const fs = require("fs");
const path = require("path");
const WEB = path.join(__dirname, "..", "..", "..", "web");

function noop() {}
function fakeCtx() {
  return new Proxy({ canvas: null, measureText: () => ({ width: 10 }), getImageData: () => ({ data: new Uint8ClampedArray(4) }) }, {
    get: (t, k) => (k in t ? t[k] : noop),
    set: (t, k, v) => { t[k] = v; return true; },
  });
}

// fake MiniSharpNative: a folder tree in memory (same idea as tests/web/native.test.js)
function fakeBridge() {
  const tree = {};
  const segs = (p) => String(p).split("/").filter(Boolean);
  const walk = (p) => { let n = tree; for (const s of segs(p)) { if (!n || Buffer.isBuffer(n) || !(s in n)) return undefined; n = n[s]; } return n; };
  const parent = (p) => { const s = segs(p); const name = s.pop(); return [walk(s.join("/")), name]; };
  return {
    tree,
    hasRoot: () => true, rootName: () => "MiniSharp", pickRoot() {},
    exists: (p) => walk(p) !== undefined,
    list(p) { const d = walk(p); if (!d || Buffer.isBuffer(d)) return "null"; return JSON.stringify(Object.keys(d).map((n) => ({ n, d: !Buffer.isBuffer(d[n]), s: 0 }))); },
    mkdirs(p) { let n = tree; for (const s of segs(p)) { if (!(s in n)) n[s] = {}; n = n[s]; } return true; },
    writeText(p, t) { this.mkdirs(segs(p).slice(0, -1).join("/")); const [d, n] = parent(p); d[n] = Buffer.from(t, "utf8"); return true; },
    writeBase64(p, b) { this.mkdirs(segs(p).slice(0, -1).join("/")); const [d, n] = parent(p); d[n] = Buffer.from(b, "base64"); return true; },
    readText(p) { const f = walk(p); return Buffer.isBuffer(f) ? f.toString("utf8") : null; },
    readBase64(p) { const f = walk(p); return Buffer.isBuffer(f) ? f.toString("base64") : null; },
    remove(p) { const [d, n] = parent(p); if (!d || !(n in d)) return false; delete d[n]; return true; },
    rename(p, nn) { const [d, n] = parent(p); if (!d || !(n in d) || nn in d) return false; d[nn] = d[n]; delete d[n]; return true; },
  };
}

async function boot(native, mobile) {
  const html = fs.readFileSync(path.join(WEB, "index.html"), "utf8").replace(/<script src="[^"]+"><\/script>/g, "");
  const dom = new JSDOM(html, { runScripts: "outside-only", pretendToBeVisual: true, url: "https://appassets.androidplatform.net/index.html" });
  const w = dom.window;
  w.HTMLCanvasElement.prototype.getContext = function () { const c = fakeCtx(); c.canvas = this; return c; };
  w.ImageData = class { constructor(d, wd, ht) { this.data = d; this.width = wd; this.height = ht; } };
  w.HTMLDialogElement.prototype.showModal = function () { this.setAttribute("open", ""); };
  w.HTMLDialogElement.prototype.close = function () { this.removeAttribute("open"); };
  w.fetch = (u) => {
    const m = /^lib\/(.+)$/.exec(String(u));
    if (m && fs.existsSync(path.join(WEB, "lib", m[1]))) { const b = fs.readFileSync(path.join(WEB, "lib", m[1])); return Promise.resolve({ ok: true, status: 200, text: async () => b.toString("utf8"), arrayBuffer: async () => b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength) }); }
    return Promise.reject(new Error("no network in the test"));
  };
  w.TextEncoder = TextEncoder; w.TextDecoder = TextDecoder; w.WebAssembly = WebAssembly;
  w.alert = noop; w.prompt = () => null; w.confirm = () => true;
  w.matchMedia = () => ({ matches: !!mobile, addEventListener: noop, addListener: noop });
  w.requestAnimationFrame = (f) => setTimeout(f, 16);
  w.AudioContext = undefined;
  if (native) w.MiniSharpNative = native;
  for (const f of ["complete.js", "graph.js", "grapheditor.js", "native.js", "glyphs.js", "app.js"]) {
    try { w.eval(fs.readFileSync(path.join(WEB, f), "utf8")); } catch (e) { console.log("script error in", f, "->", e.message.split("\n")[0]); }
  }
  await new Promise((r) => setTimeout(r, 300));
  return w;
}


async function pickLibrary(w, file) {
  const d = w.document;
  d.querySelector("#files .file.add").click();
  const label = file === "Particles.cs" ? "Efekty cząsteczkowe" : "Biblioteka animacji";
  const item = [...d.querySelectorAll("dialog.gdialog .gitem")].find((b) => b.textContent.includes(label));
  if (!item) throw new Error("library entry not found in the menu");
  item.click();
  await new Promise((r) => setTimeout(r, 30));
}

let pass = 0, fail = 0;
const ok = (c, n) => { if (c) pass++; else { fail++; console.log("FAIL:", n); } };

(async () => {
  // ---------------- in a plain browser (no folder): localStorage + project.media
  {
    const w = await boot(null);
    const $ = (s) => w.document.querySelector(s);
    ok(!!$("#glyphBtn") && !!$("#glyphs") && !!$("#glyphText"), "button and dialog exist");
    $("#glyphBtn").click();
    ok($("#glyphs").hasAttribute("open"), "dialog opens");
    ok($("#glyphText").value.includes("glyph slime"), "starts with the sample text");
    ok(/Arkusz 40×18/.test($("#glyphMsg").textContent) && $("#glyphMsg").className.includes("ok"), "sample renders: " + $("#glyphMsg").textContent);
    ok($("#glyphCs").textContent.includes("static int CW = 8;"), "C# constants shown");
    // an error in the text is shown with a line number, and saving is refused
    $("#glyphText").value = $("#glyphText").value.replace("..oooo..", "..ooQo..");
    $("#glyphText").dispatchEvent(new w.Event("input"));
    ok(/linia \d+: nieznany znak 'Q'/.test($("#glyphMsg").textContent) && !$("#glyphMsg").className.includes("ok"), "error shown: " + $("#glyphMsg").textContent);
    $("#glyphSave").click();
    ok(/popraw błędy/i.test($("#glyphMsg").textContent), "save refused while the text is wrong");
    // fix it, save under a name without extension
    $("#glyphText").value = $("#glyphText").value.replace("..ooQo..", "..oooo..");
    $("#glyphText").dispatchEvent(new w.Event("input"));
    $("#glyphName").value = "slimes";
    $("#glyphSave").click();
    ok(/Zapisano slimes\.png/.test($("#glyphMsg").textContent), "saved: " + $("#glyphMsg").textContent);
    const chips = [...w.document.querySelectorAll("#media .asset")].map((e) => e.textContent);
    ok(chips.some((t) => t.startsWith("slimes.png")), "slimes.png appears in the media list: " + chips.join("|"));
    // the text is kept per project: reopen
    $("#glyphsClose").click();
    ok(!$("#glyphs").hasAttribute("open"), "dialog closes");
    $("#glyphText").value = "";
    $("#glyphBtn").click();
    ok($("#glyphText").value.includes("glyph slime"), "text restored from localStorage");
    // the prompt for AI models goes to the clipboard
    let copied = "";
    Object.defineProperty(w.navigator, "clipboard", { value: { writeText: async (t) => { copied = t; } }, configurable: true });
    $("#glyphPrompt").click();
    await new Promise((r) => setTimeout(r, 20));
    ok(copied.includes("FORMAT") && copied.includes("PRZYKLAD FORMATU") && /Skopiowano prompt/.test($("#glyphMsg").textContent), "prompt copied: " + $("#glyphMsg").textContent.slice(0, 40));
    // the animation library from the "+ dodaj" menu
    await pickLibrary(w, "Anim.cs");
    ok([...w.document.querySelectorAll("#files .file")].some((b) => b.textContent.includes("Anim.cs")) && $("#code").value.includes("class Animator"), "Anim.cs is in the project and open in the editor");
    ok(/Dodano Anim\.cs/.test($("#status").textContent), "status says it was added: " + $("#status").textContent);
    const tabs = () => [...w.document.querySelectorAll("#files .file")].filter((b) => b.textContent.includes("Anim.cs")).length;
    await pickLibrary(w, "Anim.cs");
    ok(/już jest/.test($("#status").textContent) && tabs() === 1, "adding twice does not duplicate: " + $("#status").textContent);
    // the particle library brings its sheet along
    await pickLibrary(w, "Particles.cs");
    ok([...w.document.querySelectorAll("#files .file")].some((b) => b.textContent.includes("Particles.cs")) && $("#code").value.includes("class Emitter"), "Particles.cs added and open");
    ok([...w.document.querySelectorAll("#media .asset")].some((e) => e.textContent.startsWith("particles.png")), "particles.png added to the media list");
    ok(/Dodano Particles\.cs i particles\.png/.test($("#status").textContent), "status: " + $("#status").textContent);
    // a bad file name
    $("#glyphName").value = "../x";
    $("#glyphSave").click();
    ok(/Zła nazwa/.test($("#glyphMsg").textContent), "bad name refused");
    w.close();
  }

  // ---------------- inside the Android app (a folder on the phone): glyphs.txt and the PNG land in the project's folder
  {
    const N = fakeBridge();
    const w = await boot(N);
    const $ = (s) => w.document.querySelector(s);
    const dirs = Object.keys(N.tree);
    ok(dirs.length >= 1, "a project folder exists: " + dirs.join(","));
    $("#glyphBtn").click();
    $("#glyphText").value = $("#glyphText").value.replace("glyph slime", "glyph blob");
    $("#glyphText").dispatchEvent(new w.Event("input"));
    $("#glyphName").value = "glyphs.png";
    $("#glyphSave").click();
    const dir = dirs[0];
    const png = N.tree[dir]["glyphs.png"];
    ok(Buffer.isBuffer(png) && png.subarray(1, 4).toString() === "PNG", "glyphs.png is a PNG in the project folder");
    ok(Buffer.isBuffer(N.tree[dir]["glyphs.txt"]) && N.tree[dir]["glyphs.txt"].toString().includes("glyph blob"), "glyphs.txt is in the project folder");
    // reopen: the text comes from the folder file
    N.tree[dir]["glyphs.txt"] = Buffer.from(N.tree[dir]["glyphs.txt"].toString().replace("glyph blob", "glyph edited_outside"));
    $("#glyphText").value = "";
    $("#glyphBtn").click();
    ok($("#glyphText").value.includes("edited_outside"), "text is read from glyphs.txt in the folder");
    await pickLibrary(w, "Anim.cs");
    ok(Buffer.isBuffer(N.tree[dir]["Anim.cs"]) && N.tree[dir]["Anim.cs"].toString().includes("class Sprite"), "Anim.cs lands in the project folder");
    await pickLibrary(w, "Particles.cs");
    const pimg = N.tree[dir]["particles.png"];
    ok(Buffer.isBuffer(pimg) && pimg.subarray(1, 4).toString() === "PNG" && N.tree[dir]["Particles.cs"] && N.tree[dir]["Particles.cs"].toString().includes("interface IEffect"), "Particles.cs and particles.png land in the project folder");
    w.close();
  }
  // ---------------- phone layout: the on-screen buttons can be hidden per project
  {
    const w = await boot(null, true);
    const $ = (s) => w.document.querySelector(s);
    const body = w.document.body;
    ok(body.classList.contains("mobile"), "phone layout is on");
    w.document.querySelector("[data-view-btn=game]").click();
    ok(body.dataset.view === "game", "game view");
    ok(!body.classList.contains("nopad") && $("#padToggle").getAttribute("aria-pressed") === "true", "buttons are shown by default");
    $("#padToggle").click();
    ok(body.classList.contains("nopad") && $("#padToggle").getAttribute("aria-pressed") === "false", "toggle hides the buttons");
    const keys = () => Object.keys(w.localStorage).filter((k) => k.startsWith("ms.nopad."));
    ok(keys().length === 1 && w.localStorage.getItem(keys()[0]) === "1", "remembered for this project: " + keys().join(","));
    w.document.querySelector("[data-view-btn=code]").click();
    w.document.querySelector("[data-view-btn=game]").click();
    ok(body.classList.contains("nopad"), "still hidden after leaving and returning to the game view");
    ok(!!w.document.querySelector(".viewtabs [data-action=run]") && !!w.document.querySelector(".viewtabs [data-action=stop]"), "start and stop exist in the tab bar for when the buttons are hidden");
    $("#padToggle").click();
    ok(!body.classList.contains("nopad") && keys().length === 0, "toggle shows the buttons again and forgets the setting");
    const css = fs.readFileSync(path.join(WEB, "style.css"), "utf8");
    ok(css.includes("body.mobile.nopad .pad { display: none; }") && css.includes("body.mobile.nopad #bot { aspect-ratio: 320 / 240; }"), "styles: buttons hidden, bottom screen in its real 4:3 shape");
    w.close();
  }
  console.log(`\nglyph dialog (jsdom): ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
