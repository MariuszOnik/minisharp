const { JSDOM } = require("jsdom");
const fs = require("fs");
const path = require("path");
const WEB = path.join(__dirname, "..", "..", "..", "web");

function noop() {}
function fakeCtx() {
  return new Proxy({ canvas: null, measureText: () => ({ width: 10 }), getImageData: () => ({ data: new Uint8ClampedArray(4) }) }, {
    get: (t, k) => (k in t ? t[k] : noop),
    set: (t, k, v) => { t[k] = v; return true; },
  });
}

// fake MiniSharpNative: a folder tree in memory (same idea as tests/web/native.test.js)
function fakeBridge() {
  const tree = {};
  const segs = (p) => String(p).split("/").filter(Boolean);
  const walk = (p) => { let n = tree; for (const s of segs(p)) { if (!n || Buffer.isBuffer(n) || !(s in n)) return undefined; n = n[s]; } return n; };
  const parent = (p) => { const s = segs(p); const name = s.pop(); return [walk(s.join("/")), name]; };
  return {
    tree,
    hasRoot: () => true, rootName: () => "MiniSharp", pickRoot() {},
    exists: (p) => walk(p) !== undefined,
    list(p) { const d = walk(p); if (!d || Buffer.isBuffer(d)) return "null"; return JSON.stringify(Object.keys(d).map((n) => ({ n, d: !Buffer.isBuffer(d[n]), s: 0 }))); },
    mkdirs(p) { let n = tree; for (const s of segs(p)) { if (!(s in n)) n[s] = {}; n = n[s]; } return true; },
    writeText(p, t) { this.mkdirs(segs(p).slice(0, -1).join("/")); const [d, n] = parent(p); d[n] = Buffer.from(t, "utf8"); return true; },
    writeBase64(p, b) { this.mkdirs(segs(p).slice(0, -1).join("/")); const [d, n] = parent(p); d[n] = Buffer.from(b, "base64"); return true; },
    readText(p) { const f = walk(p); return Buffer.isBuffer(f) ? f.toString("utf8") : null; },
    readBase64(p) { const f = walk(p); return Buffer.isBuffer(f) ? f.toString("base64") : null; },
    remove(p) { const [d, n] = parent(p); if (!d || !(n in d)) return false; delete d[n]; return true; },
    rename(p, nn) { const [d, n] = parent(p); if (!d || !(n in d) || nn in d) return false; d[nn] = d[n]; delete d[n]; return true; },
  };
}

async function boot(native, mobile) {
  const html = fs.readFileSync(path.join(WEB, "index.html"), "utf8").replace(/<script src="[^"]+"><\/script>/g, "");
  const dom = new JSDOM(html, { runScripts: "outside-only", pretendToBeVisual: true, url: "https://appassets.androidplatform.net/index.html" });
  const w = dom.window;
  w.HTMLCanvasElement.prototype.getContext = function () { const c = fakeCtx(); c.canvas = this; return c; };
  w.ImageData = class { constructor(d, wd, ht) { this.data = d; this.width = wd; this.height = ht; } };
  w.HTMLDialogElement.prototype.showModal = function () { this.setAttribute("open", ""); };
  w.HTMLDialogElement.prototype.close = function () { this.removeAttribute("open"); };
  w.fetch = (u) => {
    const m = /^lib\/(.+)$/.exec(String(u));
    if (m && fs.existsSync(path.join(WEB, "lib", m[1]))) { const b = fs.readFileSync(path.join(WEB, "lib", m[1])); return Promise.resolve({ ok: true, status: 200, text: async () => b.toString("utf8"), arrayBuffer: async () => b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength) }); }
    return Promise.reject(new Error("no network in the test"));
  };
  w.TextEncoder = TextEncoder; w.TextDecoder = TextDecoder; w.WebAssembly = WebAssembly;
  w.alert = noop; w.prompt = () => null; w.confirm = () => true;
  w.matchMedia = () => ({ matches: !!mobile, addEventListener: noop, addListener: noop });
  w.requestAnimationFrame = (f) => setTimeout(f, 16);
  w.AudioContext = undefined;
  if (native) w.MiniSharpNative = native;
  for (const f of ["complete.js", "graph.js", "grapheditor.js", "scene.js", "sceneeditor.js", "native.js", "glyphs.js", "app.js"]) {
    try { w.eval(fs.readFileSync(path.join(WEB, f), "utf8")); } catch (e) { console.log("script error in", f, "->", e.message.split("\n")[0]); }
  }
  await new Promise((r) => setTimeout(r, 300));
  return w;
}



let pass = 0, fail = 0;
const ok = (c, n) => { if (c) pass++; else { fail++; console.log("FAIL:", n); } };
const tick = (ms) => new Promise((r) => setTimeout(r, ms || 30));

// The Scena tab in a plain browser: a new scene, an object, a new script component, a graph inheriting from it, save.
(async () => {
  const w = await boot(null, true);
  const d = w.document, $ = (s) => d.querySelector(s);
  const prompts = [];
  w.prompt = () => prompts.shift() ?? null;
  const item = (text) => [...d.querySelectorAll("dialog[open] .gitem")].find((b) => b.textContent.includes(text));
  const files = () => {                      // the saved project (app.js keeps its state in its own scope)
    const idx = JSON.parse(w.localStorage.getItem("minisharp.index.v2"));
    return JSON.parse(w.localStorage.getItem("minisharp.p." + idx.active)).files;
  };

  ok(!!$('[data-view-btn="scene"]') && !!$("#scenepane"), "Scena tab and pane exist");
  $('[data-view-btn="scene"]').click();
  await tick();
  ok(d.body.dataset.view === "scene" && !$("#sceneempty").hidden, "a project without scenes shows the invitation");
  prompts.push("Start");
  $("#sceneNew").click();
  await tick(80);
  ok(files()["Scene.cs"] !== undefined, "the first scene adds the runtime Scene.cs");
  const sc0 = w.MSScene.extract(files()["Start.scene.cs"]);
  ok(sc0 && sc0.name === "Start" && sc0.start === true, "Start.scene.cs: the first scene is the start scene");
  ok($("#sceneempty").hidden && !!$(".sedit .scv"), "the editor is shown");

  prompts.push("Pilka");
  [...d.querySelectorAll(".stools button")].find((b) => b.textContent === "+ Obiekt").click();
  await tick();
  ok(/Zapisz ●/.test($(".ssave").textContent), "a new object makes the scene unsaved");
  ok([...d.querySelectorAll(".sbody input")].some((i) => i.value === "Pilka"), "the inspector shows the new object");

  [...d.querySelectorAll(".sbody button")].find((b) => b.textContent === "+ Komponent").click();
  await tick();
  prompts.push("Ruch");
  item("Nowy skrypt").click();
  await tick(80);
  ok(/class Ruch : Behaviour/.test(files()["Ruch.cs"] || ""), "new script component: Ruch.cs with a Behaviour class");
  ok(d.querySelector(".scomp .sctitle").textContent.startsWith("Ruch"), "the component card is in the inspector");

  [...d.querySelectorAll(".sbody button")].find((b) => b.textContent === "+ Komponent").click();
  await tick();
  prompts.push("RuchGraf");
  item("Nowy graf").click();
  await tick();
  item("Ruch").click();
  await tick(120);
  const gtext = files()["RuchGraf.cs"] || "";
  ok(/class RuchGraf : Ruch \{/.test(gtext) && /public override void OnEvent\(Msg m\)/.test(gtext), "new graph component inherits from the code class", gtext);
  const inputs = [...d.querySelectorAll(".scomp")].pop().querySelectorAll("input:not([type=checkbox])");
  ok(inputs.length === 1, "the graph component shows the inherited field speed");
  inputs[0].value = "3";
  inputs[0].dispatchEvent(new w.Event("change"));
  await tick();

  [...d.querySelectorAll(".stools button")].find((b) => b.classList.contains("ssave")).click();
  await tick(60);
  const sc = w.MSScene.extract(files()["Start.scene.cs"]);
  ok(sc.objects.length === 1 && sc.objects[0].comps.map((c) => c.cls).join() === "Ruch,RuchGraf" && sc.objects[0].comps[1].fields.speed === "3", "saved: object with both components and the field");
  ok(/RuchGraf o1c2 = \(RuchGraf\)o1\.Add\(new RuchGraf\(\), "RuchGraf"\);/.test(files()["Start.scene.cs"]) && /o1c2\.speed = 3;/.test(files()["Start.scene.cs"]), "the scene code creates the components");
  ok(!/Zapisz ●/.test($(".ssave").textContent), "saved: no unsaved mark");
  ok(d.querySelector("#files .file.scene") !== null, "the scene file has its own mark in the file list");

  // save as + load
  prompts.push("Druga");
  [...d.querySelectorAll(".stools button")].find((b) => b.textContent === "⋯").click();
  await tick();
  item("Zapisz jako").click();
  await tick(80);
  ok(files()["Druga.scene.cs"] !== undefined && w.MSScene.extract(files()["Druga.scene.cs"]).start === false, "save as: a copy that is not the start scene");
  ok($(".sedit .gfile").textContent.includes("Druga"), "save as: the copy is open");
  $(".sedit .gfile").click();
  await tick();
  item("Start").click();
  await tick();
  ok($(".sedit .gfile").textContent.includes("Start"), "load: the other scene in the editor");

  console.log(`\nscene editor (jsdom): ${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
