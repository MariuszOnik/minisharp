// The particle library (web/lib/Particles.cs) and its sheet (web/lib/particles.png, made from particles.txt) must agree.
// Run:  node tests/web/libsheet.test.js
const fs = require("fs");
const path = require("path");
const LIB = path.join(__dirname, "..", "..", "web", "lib");
const G = require(path.join(__dirname, "..", "..", "web", "glyphs.js"));

let pass = 0, fail = 0;
function ok(cond, name) { if (cond) pass++; else { fail++; console.log("FAIL:", name); } }
const eq = (a, b, name) => ok(JSON.stringify(a) === JSON.stringify(b), `${name}: ${JSON.stringify(a)} != ${JSON.stringify(b)}`);

const txt = fs.readFileSync(path.join(LIB, "particles.txt"), "utf8");
const cs = fs.readFileSync(path.join(LIB, "Particles.cs"), "utf8");
const sheet = G.build(txt);

// the committed PNG is exactly what the tool makes from the text
const png = fs.readFileSync(path.join(LIB, "particles.png"));
ok(Buffer.compare(png, Buffer.from(G.png(sheet.w, sheet.h, sheet.rgba))) === 0, "particles.png equals the sheet built from particles.txt");

// constants in Particles.cs (static fields of class Particles) equal the tool's numbers
const num = (name) => { const m = new RegExp("static int " + name + " = (\\d+);").exec(cs); return m ? +m[1] : null; };
const arr = (name) => { const m = new RegExp("static int\\[\\] " + name + " = new int\\[\\] \\{ ([\\d, ]+) \\};").exec(cs); return m ? m[1].split(",").map(Number) : null; };
const fromTool = (name) => +new RegExp("static int " + name + " = (\\d+);").exec(sheet.cs)[1];
const toolArr = (name) => new RegExp("static int\\[\\] " + name + " = new int\\[\\] \\{ ([\\d, ]+) \\}").exec(sheet.cs)[1].split(",").map(Number);
eq(num("cw"), fromTool("CW"), "cell width");
eq(num("ch"), fromTool("CH"), "cell height");
eq(num("cols"), fromTool("COLS"), "columns");
eq(num("gap"), fromTool("GAP"), "gap");
eq(num("vars"), fromTool("VARS"), "variants");
eq(arr("gw"), toolArr("gw"), "glyph widths");
eq(arr("gh"), toolArr("gh"), "glyph heights");

// glyph and variant numbers named in the library match the order in the text
const glyphNames = sheet.names;
for (const [i, n] of glyphNames.entries()) {
  const m = new RegExp("public const int " + n[0].toUpperCase() + n.slice(1) + " = (\\d+);").exec(cs);
  ok(m && +m[1] === i, `glyph ${n} is number ${i} in Particles.cs`);
}
eq(sheet.variants.length, 11, "11 colour variants");
const variantNames = ["FireY", "FireO", "FireR", "SmokeD", "SmokeL", "IceW", "IceC", "IceB", "MagicC", "HealC", "White"];
variantNames.forEach((n, i) => { const m = new RegExp("public const int " + n + " = (\\d+);").exec(cs); ok(m && +m[1] === i, `variant ${n} is number ${i}`); });

console.log(`\nlib sheet: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
