// Tests of the folder store used inside the Android app (web/native.js), over a fake in-memory bridge.
// Run:  node tests/web/native.test.js
const path = require("path");
const root = path.join(__dirname, "..", "..");
const NativeStore = require(path.join(root, "web", "native.js"));

// fake MiniSharpNative: a tree of folders ({}), files hold Buffers
function fakeBridge() {
  const tree = {};
  let hasRoot = true;
  const segs = (p) => String(p).split("/").filter(Boolean);
  const walk = (p) => { let n = tree; for (const s of segs(p)) { if (!n || Buffer.isBuffer(n) || !(s in n)) return undefined; n = n[s]; } return n; };
  const parent = (p) => { const s = segs(p); const name = s.pop(); return [walk(s.join("/")), name]; };
  return {
    tree,
    setRoot(v) { hasRoot = v; },
    hasRoot: () => hasRoot,
    rootName: () => "MiniSharp",
    pickRoot() {},
    exists: (p) => walk(p) !== undefined,
    list(p) {
      const d = walk(p);
      if (!d || Buffer.isBuffer(d)) return "null";
      return JSON.stringify(Object.keys(d).map((n) => ({ n, d: !Buffer.isBuffer(d[n]), s: Buffer.isBuffer(d[n]) ? d[n].length : 0 })));
    },
    mkdirs(p) { let n = tree; for (const s of segs(p)) { if (!(s in n)) n[s] = {}; n = n[s]; } return true; },
    writeText(p, t) { this.mkdirs(segs(p).slice(0, -1).join("/")); const [d, n] = parent(p); d[n] = Buffer.from(t, "utf8"); return true; },
    writeBase64(p, b) { this.mkdirs(segs(p).slice(0, -1).join("/")); const [d, n] = parent(p); d[n] = Buffer.from(b, "base64"); return true; },
    readText(p) { const f = walk(p); return Buffer.isBuffer(f) ? f.toString("utf8") : null; },
    readBase64(p) { const f = walk(p); return Buffer.isBuffer(f) ? f.toString("base64") : null; },
    remove(p) { const [d, n] = parent(p); if (!d || !(n in d)) return false; delete d[n]; return true; },
    rename(p, nn) { const [d, n] = parent(p); if (!d || !(n in d) || nn in d) return false; d[nn] = d[n]; delete d[n]; return true; },
  };
}

let pass = 0, fail = 0;
function ok(cond, name) { if (cond) pass++; else { fail++; console.log("FAIL:", name); } }
const eq = (a, b, name) => ok(JSON.stringify(a) === JSON.stringify(b), `${name}: ${JSON.stringify(a)} != ${JSON.stringify(b)}`);

// without a bridge nothing happens
{
  const S = NativeStore.make(undefined);
  ok(!S.available && !S.active(), "no bridge: inactive");
  ok(S.save({ files: {}, media: {} }, { name: "x" }, []) === true, "no bridge: save is a no-op");
  ok(S.read({ dir: "x" }) === null, "no bridge: read gives null");
}

// save creates the folder and writes files and media
{
  const N = fakeBridge(), S = NativeStore.make(N);
  const metas = [{ id: "a", name: "Moja gra" }];
  const png = new Uint8Array([137, 80, 78, 71, 0, 255, 128]);
  const p = { files: { "Game.cs": "class Game {}\n", "Player.cs": "class Player {}\n" }, media: { "hero.png": png } };
  ok(S.save(p, metas[0], metas), "save ok");
  eq(metas[0].dir, "Moja gra", "folder named after the project");
  eq(Object.keys(N.tree["Moja gra"]).sort(), ["Game.cs", "Player.cs", "hero.png"], "files in the folder");
  eq([...N.tree["Moja gra"]["hero.png"]], [...png], "binary survives");

  // read back
  const back = S.read(metas[0]);
  eq(Object.keys(back.files).sort(), ["Game.cs", "Player.cs"], "read: code files");
  eq([...back.media["hero.png"]], [...png], "read: media");

  // a removed file leaves the folder, a foreign file is kept
  N.writeText("Moja gra/Notes.cs", "// dropped in by hand\n");
  delete p.files["Player.cs"];
  S.save(p, metas[0], metas);
  eq(Object.keys(N.tree["Moja gra"]).sort(), ["Game.cs", "Notes.cs", "hero.png"], "removed file deleted, foreign file kept");

  // rename moves the folder
  metas[0].name = "Nowa nazwa";
  ok(S.rename(metas[0], metas), "rename ok");
  eq(metas[0].dir, "Nowa nazwa", "meta.dir follows");
  ok(N.exists("Nowa nazwa/Game.cs") && !N.exists("Moja gra"), "folder moved");

  // delete removes the folder
  ok(S.remove(metas[0]) && !N.exists("Nowa nazwa"), "folder deleted");
}

// names: unsafe characters, collisions
{
  const N = fakeBridge(), S = NativeStore.make(N);
  const a = { id: "a", name: "a/b:c" }, b = { id: "b", name: "a_b_c" };
  const metas = [a, b], p = { files: { "Game.cs": "x" }, media: {} };
  S.save(p, a, metas); S.save(p, b, metas);
  eq(a.dir, "a_b_c", "unsafe chars replaced");
  eq(b.dir, "a_b_c (2)", "second project gets a different folder");
  N.mkdirs("Stary"); // an unknown folder on the phone with the same name as a new project
  const c = { id: "c", name: "Stary" };
  S.save(p, c, [a, b, c]);
  eq(c.dir, "Stary (2)", "does not write into an unknown folder with the same name");
}

// listProjects: only folders with a .cs file, files at the top are not projects
{
  const N = fakeBridge(), S = NativeStore.make(N);
  N.writeText("Gra1/Game.cs", "x"); N.writeText("Gra2/readme.txt", "x"); N.writeText("luzny.cs", "x"); N.writeText("Gra3/sub/Game.cs", "x");
  N.writeText("Gra4/Dobra nazwa.cs", "x"); N.writeText("Gra4/Game.cs", "x");
  eq(S.listProjects(), ["Gra1", "Gra4"], "listProjects");
  const back = S.read({ dir: "Gra4" });
  eq(Object.keys(back.files), ["Game.cs"], "files with names the compiler would reject are skipped");
}

// images and sounds in subfolders: read under their relative path, written back into the same subfolder
{
  const N = fakeBridge(), S = NativeStore.make(N);
  N.writeText("Gra/Game.cs", "x"); N.writeText("Gra/Ship.cs", "y");
  N.writeBase64("Gra/hero.png", Buffer.from([1, 2, 3]).toString("base64"));
  N.writeBase64("Gra/img/enemy.png", Buffer.from([4, 5]).toString("base64"));
  N.writeBase64("Gra/img/boss/big.png", Buffer.from([6]).toString("base64"));
  N.writeBase64("Gra/sfx/jump.wav", Buffer.from([7, 8]).toString("base64"));
  N.writeBase64("Gra/.thumbs/hidden.png", Buffer.from([9]).toString("base64"));
  N.writeText("Gra/img/Other.cs", "not read: code files are only read from the project folder");
  N.writeText("Gra/img/notes.txt", "ignored");
  const meta = { id: "a", name: "Gra", dir: "Gra" };
  const back = S.read(meta);
  eq(Object.keys(back.files).sort(), ["Game.cs", "Ship.cs"], "subfolder: code only from the project folder");
  eq(Object.keys(back.media).sort(), ["hero.png", "img/boss/big.png", "img/enemy.png", "sfx/jump.wav"], "subfolder: media with relative paths, hidden folders skipped");
  eq([...back.media["img/enemy.png"]], [4, 5], "subfolder: content");

  // a new image under a subfolder path goes into that subfolder, and removing it removes the file
  const p = { files: back.files, media: { ...back.media, "tiles/grass.png": new Uint8Array([10, 11]) } };
  ok(S.save(p, meta, [meta]), "subfolder: save ok");
  eq([...N.tree.Gra.tiles["grass.png"]], [10, 11], "subfolder: written into tiles/");
  delete p.media["img/enemy.png"];
  S.save(p, meta, [meta]);
  ok(!("enemy.png" in N.tree.Gra.img) && "boss" in N.tree.Gra.img, "subfolder: removed file gone, the rest stays");
}

// how deep it looks
{
  const N = fakeBridge(), S = NativeStore.make(N);
  N.writeText("G/Game.cs", "x");
  N.writeBase64("G/a/b/c/d/ok.png", "AQ==");        // depth 4
  N.writeBase64("G/a/b/c/d/e/too-deep.png", "AQ==");  // depth 5
  eq(Object.keys(S.read({ dir: "G" }).media), ["a/b/c/d/ok.png"], "depth limit");
}

// no access (folder not chosen yet): nothing is written
{
  const N = fakeBridge(), S = NativeStore.make(N);
  N.setRoot(false);
  const m = { id: "a", name: "x" };
  ok(S.save({ files: { "Game.cs": "x" }, media: {} }, m, [m]) === true && !N.exists("x"), "inactive store writes nothing");
}

console.log(`\nnative.js: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
