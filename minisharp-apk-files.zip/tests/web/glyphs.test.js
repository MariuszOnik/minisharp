// Tests of web/glyphs.js: glyph text -> sprite sheet -> PNG.   Run:  node tests/web/glyphs.test.js
const path = require("path");
const zlib = require("zlib");
const G = require(path.join(__dirname, "..", "..", "web", "glyphs.js"));

let pass = 0, fail = 0;
function ok(cond, name) { if (cond) pass++; else { fail++; console.log("FAIL:", name); } }
const eq = (a, b, name) => ok(JSON.stringify(a) === JSON.stringify(b), `${name}: ${JSON.stringify(a)} != ${JSON.stringify(b)}`);
const px = (a, x, y) => { const o = (y * a.w + x) * 4; return [a.rgba[o], a.rgba[o + 1], a.rgba[o + 2], a.rgba[o + 3]]; };
const hex = (v) => [v >> 16, (v >> 8) & 255, v & 255, 255];

// decode our own PNG with node's zlib and compare with the pixels
function decode(bytes) {
  const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let o = 8, w = 0, h = 0; const idat = [];
  while (o < bytes.length) {
    const len = dv.getUint32(o), type = String.fromCharCode(...bytes.subarray(o + 4, o + 8));
    if (type === "IHDR") { w = dv.getUint32(o + 8); h = dv.getUint32(o + 12); }
    if (type === "IDAT") idat.push(bytes.subarray(o + 8, o + 8 + len));
    o += 12 + len;
  }
  const raw = zlib.inflateSync(Buffer.concat(idat));
  const out = new Uint8Array(w * h * 4);
  for (let y = 0; y < h; y++) for (let i = 0; i < w * 4; i++) out[y * w * 4 + i] = raw[y * (w * 4 + 1) + 1 + i];
  return { w, h, rgba: out };
}

// the built-in sample
{
  const a = G.build(G.SAMPLE);
  eq([a.w, a.h], [40, 6 + 12], "sample: size (5 variants x 8 wide, 1 glyph 6 high + letter block 12 high)");
  eq(a.names, ["slime"], "sample: names");
  eq(a.variants, ["strona 0", "strona 1", "blysk", "lod", "trup"], "sample: variants");
  eq(px(a, 0, 0), [0, 0, 0, 0], "transparent where the glyph has '.'");
  eq(px(a, 2, 0), hex(0x000000), "outline is palette 0");
  eq(px(a, 1, 1), [0, 0, 0, 255], "outline pixel (row 1 col 1)");
  eq(px(a, 2, 1), hex(0x3b5dc9), "x = body colour of side 0");
  eq(px(a, 8 + 2, 1), hex(0xb13e53), "x = body colour of side 1");
  eq(px(a, 2, 2), hex(0x41a6f6), "X = light colour of side 0");
  eq(px(a, 16 + 2, 1), hex(0xf4f4f4), "flash: everything but the outline is the tint");
  eq(px(a, 16 + 1, 1), [0, 0, 0, 255], "flash: the outline stays");
  eq(px(a, 24 + 2, 1), hex(0x73eff7), "ice tint");
  eq(px(a, 32 + 2, 1), hex(0x94b0c2), "dead tint");
  // the letter plate: black, with the letter in the light colour of the side
  const LY = 6;   // the letter block starts under the glyph block (GH = 6)
  eq(px(a, 0, LY), [0, 0, 0, 255], "letter plate is opaque black");
  eq(px(a, 1, LY + 1), [0, 0, 0, 255], "letter S: top-left dot is empty (bits 011)");
  eq(px(a, 3, LY + 1), hex(0x41a6f6), "letter S: dot in the light colour of side 0");
  eq(px(a, 8 + 3, LY + 1), hex(0xef7d57), "letter S: dot in the light colour of side 1");
  eq(px(a, 16 + 3, LY + 1), hex(0xf4f4f4), "letter S: flash tint");
  ok(a.cs.includes("static int CW = 8;") && a.cs.includes("static int GH = 6;") && a.cs.includes("static int CH = 6;") && a.cs.includes("new int[] { 8 }"), "C# constants");
}

// PNG: our encoder, decoded by node's zlib
{
  const a = G.build(G.SAMPLE);
  const bytes = G.png(a.w, a.h, a.rgba);
  eq(Array.from(bytes.subarray(0, 8)), [137, 80, 78, 71, 13, 10, 26, 10], "png signature");
  const d = decode(bytes);
  eq([d.w, d.h], [a.w, a.h], "png size");
  ok(Buffer.compare(Buffer.from(d.rgba), Buffer.from(a.rgba)) === 0, "png pixels survive the round trip");
  // a sheet larger than one 64 KB deflate block
  const w = 300, h = 120, big = new Uint8ClampedArray(w * h * 4);
  for (let i = 0; i < big.length; i++) big[i] = (i * 7 + (i >> 8)) & 255;
  const d2 = decode(G.png(w, h, big));
  ok(Buffer.compare(Buffer.from(d2.rgba), Buffer.from(big)) === 0, "png with several deflate blocks");
}

// a custom glyph set: hex colours, two sides, no tints, no letters
{
  const a = G.build("palette\nk #102030\nsides\n#ff0000 #ffaaaa\n#00ff00 #aaffaa\nglyph blob\nkkk\nkxk\nkXk\n");
  eq([a.w, a.h], [6, 3], "custom: size");
  eq(px(a, 1, 1), [255, 0, 0, 255], "custom: side 0 colour");
  eq(px(a, 3 + 1, 1), [0, 255, 0, 255], "custom: side 1 colour");
  eq(px(a, 0, 0), [16, 32, 48, 255], "custom: #rrggbb palette entry");
}

// sheet section: cell size, columns that wrap, gap
{
  const body = "palette\nk #102030\nsides\n#ff0000 #ffaaaa\n#00ff00 #aaffaa\n";
  const three = "glyph a\nkk\nkx\nglyph b\nkkk\nkxk\nglyph c\nk\nk\n";     // sizes 2x2, 3x2 and 1x2
  // default: one column per variant (2), one row per glyph (3), cell = the largest glyph (3x2)
  let a = G.build(body + three);
  eq([a.w, a.h], [6, 6], "default layout size");
  ok(a.cs.includes("static int COLS = 2;") && a.cs.includes("static int VARS = 2;") && a.cs.includes("static int GAP = 0;"), "default constants");
  // explicit cell 4x4, 3 columns, gap 1: 6 frames (3 glyphs x 2 variants) -> 2 rows
  a = G.build(body + "sheet\ncell 4 4\ncolumns 3\ngap 1\n" + three);
  eq([a.w, a.h], [3 * 4 + 2, 2 * 4 + 1], "cell/columns/gap: sheet size");
  ok(a.cs.includes("static int CW = 4;") && a.cs.includes("static int COLS = 3;") && a.cs.includes("static int GAP = 1;"), "cell/columns/gap: constants");
  // frame n = glyph * 2 + variant. glyph a variant 1 -> n = 1 -> col 1, row 0 -> x = 1 * (4 + 1) = 5. Its pixel (1,1) is 'x' of side 1
  eq(px(a, 5 + 1, 1), [0, 255, 0, 255], "frame n=1 (a, side 1) at col 1");
  // glyph b variant 0 -> n = 2 -> col 2, row 0 -> x = 10; pixel (1,1) is 'x' of side 0
  eq(px(a, 10 + 1, 1), [255, 0, 0, 255], "frame n=2 (b, side 0) wraps correctly");
  // glyph b variant 1 -> n = 3 -> col 0, row 1 -> y = 1 * (4 + 1) = 5
  eq(px(a, 1, 5 + 1), [0, 255, 0, 255], "frame n=3 (b, side 1) is on the second row");
  eq(px(a, 4, 0), [0, 0, 0, 0], "the gap column is transparent");
  // letters follow the same column grid
  a = G.build(body + "sheet\ncolumns 3\ngap 1\nglyph a\nletter A 2 5 7 5 5\nkk\nkx\n");
  ok(a.cs.includes("static int GH = ") && a.h > 2, "letters with a gap: block below the glyph rows");
  // errors
  const err = (t) => { try { G.build(t); return ""; } catch (e) { return e.message; } };
  ok(/sheet: komórka 2x2 jest mniejsza niż największy glif 3x2/.test(err(body + "sheet\ncell 2 2\n" + three)), "cell smaller than a glyph");
  ok(/linia \d+: w sheet jest/.test(err(body + "sheet\nrows 3\n" + three)), "unknown sheet key");
  ok(/liczba kolumn ma być/.test(err(body + "sheet\ncolumns 0\n" + three)), "columns must be positive");
  ok(/1024x1024/.test(err(body + "sheet\ncell 600 600\ncolumns 2\n" + three)), "sheet larger than 1024");
}

// the prompt for AI models: its example must be valid input for the tool
{
  const P = G.PROMPT;
  ok(typeof P === "string" && P.includes("FORMAT") && P.includes("PALETA 0..15") && P.includes("ZADANIE"), "prompt has its sections");
  const from = P.indexOf("PRZYKLAD FORMATU"), to = P.indexOf("ZADANIE (to opis do zmiany)");
  ok(from > 0 && to > from, "prompt example is delimited");
  const example = P.slice(from + "PRZYKLAD FORMATU".length, to);
  let a = null, msg = "";
  try { a = G.build(example); } catch (e) { msg = e.message; }
  ok(a !== null, "the example in the prompt builds: " + msg);
  if (a) eq(a.names, ["slime", "tile"], "prompt example: glyphs (a character and an isometric tile)");
  if (a) { const t = a.names.indexOf("tile"); ok(a.cs.includes("static int[] gw = new int[] { 8, 16 };"), "tile is 16 wide"); }
  ok(/<TU OPISZ/.test(P), "prompt ends with a placeholder for the task");
  ok(P.includes("NAZWA_0") && P.includes("nie rysuj klatek"), "prompt explains frame animation and what to leave to code");
}

// error messages carry the line number
{
  const err = (t) => { try { G.build(t); return ""; } catch (e) { return e.message; } };
  const base = G.SAMPLE;
  ok(/linia \d+: nieznany znak 'Q'/.test(err(base.replace("..oooo..", "..ooQo.."))), "unknown char");
  ok(/linia \d+: wiersz ma 7 znaków/.test(err(base.replace(".oooooo.", ".oooooo"))), "short row");
  ok(/linia \d+: zły kolor '99'/.test(err(base.replace("w 12", "w 99"))), "bad colour");
  ok(/brak sekcji sides/.test(err(base.replace(/sides[\s\S]*?tints/, "tints"))), "no sides");
  ok(/brak glifów/.test(err("sides\n1 2\n")), "no glyphs");
}

console.log(`\nglyphs.js: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
