class T {
    static int fails = 0;
    static void Near(string name, float a, float b) {
        if (Mathf.Abs(a - b) > 0.0005f) { fails++; Console.WriteLine("FAIL " + name + ": " + a + " != " + b); }
    }
    static void Is(string name, int a, int b) {
        if (a != b) { fails++; Console.WriteLine("FAIL " + name + ": " + a + " != " + b); }
    }
    static void Main() {
        // easing: ends and a few points
        for (int k = 0; k <= 6; k++) { Near("ease" + k + " at 0", Ease.Apply(k, 0), 0); Near("ease" + k + " at 1", Ease.Apply(k, 1), 1); }
        Near("InQuad .5", Ease.Apply(Ease.InQuad, 0.5f), 0.25f);
        Near("OutQuad .5", Ease.Apply(Ease.OutQuad, 0.5f), 0.75f);
        Near("InOutQuad .25", Ease.Apply(Ease.InOutQuad, 0.25f), 0.125f);
        Near("OutCubic .5", Ease.Apply(Ease.OutCubic, 0.5f), 0.875f);
        Near("OutBack .5", Ease.Apply(Ease.OutBack, 0.5f), 1.0876975f);
        Near("OutBounce .5", Ease.Apply(Ease.OutBounce, 0.5f), 0.765625f);
        Near("clamped below", Ease.Apply(Ease.OutQuad, -3), 0);
        Near("clamped above", Ease.Apply(Ease.OutQuad, 9), 1);

        // clips
        Clip loop = Clip.Make(new int[] { 5, 6, 7, 6 }, 10, Clip.Loop);
        Is("loop 0.00", loop.FrameAt(0), 5);
        Is("loop 0.15", loop.FrameAt(0.15f), 6);
        Is("loop 0.35", loop.FrameAt(0.35f), 6);
        Is("loop 0.45", loop.FrameAt(0.45f), 5);
        Clip once = Clip.Range(10, 3, 10, Clip.Once);
        Is("once 0.05", once.FrameAt(0.05f), 10);
        Is("once 0.25", once.FrameAt(0.25f), 12);
        Is("once 9", once.FrameAt(9), 12);
        Is("once not finished", once.Finished(0.29f) ? 1 : 0, 0);
        Is("once finished", once.Finished(0.31f) ? 1 : 0, 1);
        Clip pp = Clip.Range(0, 3, 10, Clip.PingPong);
        int[] expect = new int[] { 0, 1, 2, 1, 0, 1, 2, 1 };
        for (int i = 0; i < 8; i++) Is("pingpong " + i, pp.FrameAt(i * 0.1f + 0.05f), expect[i]);
        Near("pingpong length", pp.Length(), 0.4f);
        Near("loop length", loop.Length(), 0.4f);
        Clip single = Clip.Make(new int[] { 4 }, 8, Clip.Loop);
        Is("single frame", single.FrameAt(12), 4);

        // animator: Play does not restart the same clip
        Animator a = new Animator();
        a.Play(loop);
        a.Update(0.25f);
        Is("animator frame", a.Frame(), 7);
        a.Play(loop);
        Near("same clip keeps time", a.time, 0.25f);
        a.Play(once);
        Near("new clip restarts", a.time, 0);
        a.speed = 2;
        a.Update(0.1f);
        Is("speed 2", a.Frame(), 12);
        a.paused = true;
        a.Update(5);
        Is("paused", a.Frame(), 12);

        // tween
        Tween t = Tween.Make(100, 200, 2, Ease.Linear);
        Near("tween start", t.Value(), 100);
        t.Update(1);
        Near("tween mid", t.Value(), 150);
        Is("not done", t.Done() ? 1 : 0, 0);
        t.Update(1.5f);
        Near("tween end", t.Value(), 200);
        Is("done", t.Done() ? 1 : 0, 1);
        Tween d = Tween.Make(0, 10, 1, Ease.Linear);
        d.delay = 0.5f;
        d.Update(0.25f);
        Near("delay holds the start", d.Value(), 0);
        d.Update(0.75f);
        Near("after delay", d.Value(), 5);
        Tween lp = Tween.Make(0, 10, 1, Ease.Linear);
        lp.loop = true;
        lp.Update(2.25f);
        Near("loop wraps", lp.Value(), 2.5f);
        Is("loop never done", lp.Done() ? 1 : 0, 0);

        // motion
        Near("bob quarter period", Motion.Bob(0.25f, 4, 1), 4);
        Near("hop top", Motion.Hop(0.5f, 12), 12);
        Near("hop ends", Motion.Hop(1, 12), 0);
        Near("hop outside", Motion.Hop(1.5f, 12), 0);
        Near("breathe", Motion.Breathe(0.25f, 0.1f, 1), 1.1f);
        Near("shake starts at zero", Motion.Shake(0, 5, 10, 6), 0);
        Near("shake decays", Mathf.Abs(Motion.Shake(2.025f, 5, 10, 6)), 5 * Mathf.Exp(-6 * 2.025f) * Mathf.Abs(Mathf.Sin(2.025f * 10 * 2 * Mathf.PI)));
        Is("blink on", Motion.Blink(0.05f, 5) ? 1 : 0, 1);
        Is("blink off", Motion.Blink(0.15f, 5) ? 1 : 0, 0);

        // sheet: 8x10 cells, 2 columns, gap 1, 2 variants per glyph. glyph 3 variant 1 -> n = 7 -> col 1, row 3
        Sheet sh = Sheet.Make(0, 8, 10, 2, 1, 2);
        Sprite sp = Sprite.Make(0, 0, 0, 1, 1);
        sh.Apply(sp, 3, 1);
        Is("sheet sx", sp.sx, 9);
        Is("sheet sy", sp.sy, 33);
        Is("sheet sw", sp.sw, 8);
        sh.ApplyWH(sp, 0, 0, 6, 7);
        Is("sheet cropped w", sp.sw, 6);
        Is("sheet cropped h", sp.sh, 7);
        Console.WriteLine(fails == 0 ? "anim: all ok" : "anim: " + fails + " failed");
    }
}
