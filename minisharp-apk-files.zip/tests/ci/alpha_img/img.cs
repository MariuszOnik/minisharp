// Gfx.Alpha with an image that has its own alpha channel: the two multiply
class I {
    static int img;
    static void Main() { img = Gfx.LoadImage("sprite.png"); }
    static void Update() { }
    static void Draw() {
        Gfx.Screen(Screen.Bottom);
        Gfx.Clear(0xFFFFFF);
        Gfx.Image(img, 10, 10);                    // alpha 1: red opaque, blue at its own 50%, bottom rows transparent
        Gfx.Alpha(0.5f);
        Gfx.Image(img, 30, 10);                    // everything at half: red 50%, blue 25%
        Gfx.ImagePartEx(img, 50, 10, 0, 0, 8, 8, 2, 2, 0);   // scaled 2x, also at 50%
        Gfx.Alpha(1);
        Gfx.Image(img, 80, 10);                    // back to opaque
    }
}
